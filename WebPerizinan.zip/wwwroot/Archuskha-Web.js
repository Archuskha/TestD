document.addEventListener('DOMContentLoaded', function() {
    const jenisPeminjaman = document.getElementById('jenisPeminjaman');
    const formDetails = document.getElementById('formDetails');
    const labelTujuan = document.getElementById('labelTujuan');
    const peminjamanForm = document.getElementById('peminjamanForm');
    
    // Variabel untuk elemen Kotak Detail
    const mainFormBox = document.getElementById('mainFormBox');
    const summaryBox = document.getElementById('summaryBox');
    const btnSelesai = document.getElementById('btnSelesai');

    // URL Google Apps Script yang sudah Anda miliki
    const scriptURL = 'https://script.google.com/macros/s/AKfycbytm4m3mv5JU2rs1tjn53MLS76ScduM68RwQaN5h5ODgXMEMyOMx_Bquhf3sV4Uy5Ex/exec';

    // Menangani perubahan dropdown
    jenisPeminjaman.addEventListener('change', function() {
        formDetails.style.display = 'block';

        if (this.value === 'lab') {
            labelTujuan.textContent = 'Tujuan untuk meminjam lab:';
        } else if (this.value === 'lemari') {
            labelTujuan.textContent = 'Tujuan untuk meminjam kunci lemari:';
        }
    });

    // Mengirim data dan menampilkan Kotak Detail
    peminjamanForm.addEventListener('submit', function(e) {
        e.preventDefault(); 

        const submitButton = peminjamanForm.querySelector('button[type="submit"]');
        submitButton.textContent = 'Mengirim Data...';
        submitButton.disabled = true;

        // 1. Simpan data yang diketik sebelum formulir dibersihkan (reset)
        const valJenis = jenisPeminjaman.options[jenisPeminjaman.selectedIndex].text;
        const valNama = document.getElementById('nama').value;
        const valNpm = document.getElementById('npm').value;
        const valEmail = document.getElementById('email').value;
        const valAngkatan = document.getElementById('angkatan').value;
        const valTujuan = document.getElementById('tujuan').value;
        const valTanggal = document.getElementById('tanggal').value;
        const valJamMulai = document.getElementById('jamMulai').value;
        const valJamSelesai = document.getElementById('jamSelesai').value;

        // Mencatat waktu saat itu juga (Real-time System Clock)
        const now = new Date();
        const optionsDate = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        const formatTanggal = now.toLocaleDateString('id-ID', optionsDate);
        const formatJam = now.toLocaleTimeString('id-ID');

        const formData = new FormData(peminjamanForm);

        fetch(scriptURL, { method: 'POST', body: formData })
            .then(response => {
                // 2. Masukkan data ke dalam teks di Kotak Detail
                document.getElementById('sumJenis').textContent = valJenis;
                document.getElementById('sumNama').textContent = valNama;
                document.getElementById('sumNpm').textContent = valNpm;
                document.getElementById('sumEmail').textContent = valEmail;
                document.getElementById('sumAngkatan').textContent = valAngkatan;
                document.getElementById('sumTujuan').textContent = valTujuan;
                document.getElementById('sumTanggal').textContent = valTanggal;
                document.getElementById('sumWaktu').textContent = valJamMulai + ' - ' + valJamSelesai;
                
                // Menampilkan waktu kirim di bawah tombol
                document.getElementById('waktuSubmitText').textContent = 'Dikirim pada: ' + formatTanggal + ' pukul ' + formatJam;

                // 3. Sembunyikan formulir utama, dan tampilkan kotak detail
                mainFormBox.style.display = 'none';
                summaryBox.style.display = 'block';
                
                // 4. Reset formulir secara diam-diam di latar belakang
                peminjamanForm.reset();
                formDetails.style.display = 'none';
                
                // Kembalikan tombol seperti semula
                submitButton.textContent = 'Kirim Pengajuan';
                submitButton.disabled = false;
            })
            .catch(error => {
                console.error('Error!', error.message);
                alert('Terjadi kesalahan saat mengirim data.');
                
                submitButton.textContent = 'Kirim Pengajuan';
                submitButton.disabled = false;
            });
    });

    // Aksi untuk tombol "Selesai & Kembali"
    btnSelesai.addEventListener('click', function() {
        summaryBox.style.display = 'none';
        mainFormBox.style.display = 'block';
    });
});