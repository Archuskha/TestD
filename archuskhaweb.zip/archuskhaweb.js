const backendUrl = '/api-lab/';
const loginUrl = '/api-login/';

let currentUserGoogleName = "";
let currentUserGoogleEmail = ""; // Variabel baru untuk menampung email
let capturedBiometricBase64 = ""; 
let capturedKtmBase64 = "";       

// Variabel Global Biometrik Wajah
let faceTimer = 3; 
let isFaceStable = false;
let faceInterval = null;
let cameraInstance = null;

// Variabel Global Biometrik KTM (OCR-based)
let ktmTimer = 3; 
let isKtmStable = false;
let ktmInterval = null;
let ktmStream = null;
let isOcrProcessing = false;

// Tesseract.js Worker (Pre-loaded)
let tesseractWorker = null;

async function initTesseractWorker() {
    try {
        console.log("[arOS-AI] Memuat Engine Tesseract OCR...");
        tesseractWorker = await Tesseract.createWorker('eng');
        // Optimasi: Hanya cari angka dan huruf untuk kecepatan
        await tesseractWorker.setParameters({
            tessedit_char_whitelist: '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz ',
        });
        console.log("[arOS-AI] Tesseract OCR Engine Ready.");
    } catch (e) {
        console.error("[ERROR] Gagal memuat modul OCR:", e);
        document.getElementById('ktmStatus').innerText = "ERROR: Gagal memuat modul AI OCR.";
    }
}
initTesseractWorker();

function parseJwt(token) {
    try {
        var base64Url = token.split('.')[1];
        var base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
        var jsonPayload = decodeURIComponent(atob(base64).split('').map(function(c) {
            return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
        }).join(''));
        return JSON.parse(jsonPayload);
    } catch (e) {
        return null;
    }
}

window.handleCredentialResponse = function(response) {
    const data = parseJwt(response.credential);
    const loginError = document.getElementById('loginError');

    if (data && data.email && data.email.endsWith("@widyatama.ac.id")) {
        loginError.style.display = 'none';
        currentUserGoogleName = data.name;
        currentUserGoogleEmail = data.email; // Simpan email kampus
        
        fetch(loginUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email: data.email, name: data.name })
        }).catch(err => console.error("Gagal kirim notifikasi", err));

        document.getElementById('loginScreen').classList.remove('active');
        setTimeout(() => {
            document.getElementById('biometricScreen').classList.add('active');
            initBiometricScan(); 
        }, 500);
    } else {
        loginError.style.display = 'block';
    }
};

function initBiometricScan() {
    const videoElement = document.getElementById('webcam');
    const countdownOverlay = document.getElementById('countdownOverlay');
    const statusText = document.getElementById('biometricStatus');

    const faceDetection = new FaceDetection({
        locateFile: (file) => {
            return `https://cdn.jsdelivr.net/npm/@mediapipe/face_detection/${file}`;
        }
    });

    faceDetection.setOptions({
        model: 'short',
        minDetectionConfidence: 0.7
    });

    faceDetection.onResults((results) => {
        if (results.detections.length > 0) {
            if (!isFaceStable) {
                isFaceStable = true;
                faceTimer = 3;
                countdownOverlay.style.display = 'block';
                countdownOverlay.innerText = faceTimer;
                statusText.style.color = '#00ffff';
                statusText.innerText = "Wajah terdeteksi. Pertahankan posisi Anda...";

                faceInterval = setInterval(() => {
                    faceTimer--;
                    if (faceTimer > 0) {
                        countdownOverlay.innerText = faceTimer;
                    } else {
                        clearInterval(faceInterval);
                        captureAndProceedToKTM(videoElement);
                    }
                }, 1000);
            }
        } else {
            if (isFaceStable) {
                isFaceStable = false;
                clearInterval(faceInterval);
                countdownOverlay.style.display = 'none';
                statusText.style.color = '#ff3333';
                statusText.innerText = "Wajah hilang/tidak terdeteksi. Proses diulang...";
            } else {
                statusText.innerText = "Silakan arahkan wajah Anda ke kamera...";
                statusText.style.color = '#ff3333';
            }
        }
    });

    cameraInstance = new Camera(videoElement, {
        onFrame: async () => {
            await faceDetection.send({ image: videoElement });
        },
        width: 640,
        height: 480
    });
    
    cameraInstance.start();
}

function captureAndProceedToKTM(videoElement) {
    const statusText = document.getElementById('biometricStatus');
    statusText.style.color = '#00ff00';
    statusText.innerText = "Verifikasi wajah berhasil. Menyimpan data...";
    
    const canvas = document.createElement('canvas');
    canvas.width = videoElement.videoWidth;
    canvas.height = videoElement.videoHeight;
    const ctx = canvas.getContext('2d');
    
    ctx.translate(canvas.width, 0);
    ctx.scale(-1, 1);
    ctx.drawImage(videoElement, 0, 0, canvas.width, canvas.height);
    
    capturedBiometricBase64 = canvas.toDataURL('image/jpeg', 0.8);

    setTimeout(() => {
        if(cameraInstance) {
            cameraInstance.stop();
        }
        document.getElementById('biometricScreen').classList.remove('active');
        
        setTimeout(() => {
            document.getElementById('ktmScreen').classList.add('active');
            initKtmScan();
        }, 500);
    }, 1000);
}

// ==========================================
// 2. FUNGSI BIOMETRIK KTM (OCR & MATCHING) - DIUBAH TOTAL
// ==========================================
async function initKtmScan() {
    const videoElement = document.getElementById('ktmWebcam');
    const statusText = document.getElementById('ktmStatus');
    const videoContainer = document.getElementById('ktmVideoContainer');
    
    try {
        console.log("[arOS-AI] Meminta akses kamera belakang...");
        ktmStream = await navigator.mediaDevices.getUserMedia({
            video: { 
                facingMode: { ideal: "environment" },
                width: { ideal: 1920 }, // Resolusi Full HD agar teks jelas terbaca OCR
                height: { ideal: 1080 }
            }
        });
        videoElement.srcObject = ktmStream;
    } catch (err) {
        statusText.style.color = '#ff3333';
        statusText.innerText = "Gagal mengakses kamera belakang. Pastikan izin kamera diberikan.";
        return;
    }

    // FUNGSI TAP-TO-FOCUS (Jika didukung perangkat)
    videoContainer.addEventListener('click', async () => {
        const track = ktmStream.getVideoTracks()[0];
        const capabilities = track.getCapabilities();
        
        const scanBox = document.getElementById('scanBox');
        scanBox.style.borderColor = '#ffffff';
        setTimeout(() => scanBox.style.borderColor = '#00ffff', 200);

        if (capabilities.focusMode && capabilities.focusMode.includes('continuous')) {
            try {
                await track.applyConstraints({ advanced: [{ focusMode: "continuous" }] });
                statusText.innerText = "Mencoba memfokuskan lensa...";
            } catch (e) { console.log("Gagal instruksi fokus manual."); }
        }
    });

    statusText.style.color = '#00ffff';
    statusText.innerText = "Menganalisis KTM...";

    const processCanvas = document.createElement('canvas');
    const processCtx = processCanvas.getContext('2d', { willReadFrequently: true });

    // --- PERSIAPAN DATA SUMBER UNTUK COCOK (DATA LOGIN) ---
    // 1. Ambil Nama Depan Google (Case Insensitive)
    const googleFirstName = currentUserGoogleName ? currentUserGoogleName.split(' ')[0].toLowerCase() : "";
    
    // 2. Ambil NPM dari Email Kampus (Hanya Ambil Angka)
    // Misal: 231811003@widyatama.ac.id -> diambil 231811003
    const targetNpmNumbers = currentUserGoogleEmail ? currentUserGoogleEmail.replace(/[^0-9]/g, '') : "";

    console.log(`[arOS-AI] Data Target Cocok: Nama Depan='${googleFirstName}', NPM='${targetNpmNumbers}'`);

    if (!tesseractWorker) {
        statusText.innerText = "ERROR: Modul AI OCR belum siap. Refresh halaman.";
        return;
    }

    const scanLoop = async () => {
        if (!document.getElementById('ktmScreen').classList.contains('active')) return;
        if (isOcrProcessing) { // Jangan tumpuk request OCR
            requestAnimationFrame(scanLoop);
            return;
        }

        if (videoElement.readyState === videoElement.HAVE_ENOUGH_DATA) {
            
            // AREA CROP: Ambil bagian tengah sesuai ScanBox (Lebih lebar dan tinggi untuk teks)
            const boxWidthRatio = 0.8;
            const boxHeightRatio = 0.4;
            
            const cropWidth = videoElement.videoWidth * boxWidthRatio;
            const cropHeight = videoElement.videoHeight * boxHeightRatio;
            
            const startX = (videoElement.videoWidth - cropWidth) / 2;
            const startY = (videoElement.videoHeight - cropHeight) / 2;

            processCanvas.width = cropWidth;
            processCanvas.height = cropHeight;

            processCtx.drawImage(
                videoElement,
                startX, startY, cropWidth, cropHeight, 
                0, 0, cropWidth, cropHeight            
            );

            isOcrProcessing = true;

            try {
                // MENJALANKAN OCR PADA GAMBAR CROP
                const { data: { text } } = await tesseractWorker.recognize(processCanvas);
                isOcrProcessing = false;

                // --- LOGIKA PENCANTUMAN DATA KTM ---
                
                // 1. Bersihkan hasil bacaan teks: huruf kecil, hapus simbol aneh kecuali angka/huruf/spasi
                const scannedTextLower = text.toLowerCase();
                const cleanedScannedText = scannedTextLower.replace(/[^a-z0-9 ]/g, '');

                // DEBUG: Lihat apa yang dibaca AI
                // console.log("[OCR Read Cleaned]:", cleanedScannedText);

                let isMatch = false;
                let failReason = "";

                // A. Verifikasi Logo UTama (Teks 'utama' atau 'widyatama')
                const hasLogoText = cleanedScannedText.includes("utama") || cleanedScannedText.includes("widyatama");

                // B. Verifikasi Nama Depan (Apakah teks bacaan mengandung nama depan Google?)
                const hasNameMatch = googleFirstName !== "" && cleanedScannedText.includes(googleFirstName);

                // C. Verifikasi NPM (Ambil semua angka dari teks bacaan, apakah mengandung NPM email?)
                const scannedNumbersOnly = cleanedScannedText.replace(/[^0-9]/g, '');
                const hasNpmMatch = targetNpmNumbers !== "" && scannedNumbersOnly.includes(targetNpmNumbers);

                // --- EVALUASI HASIL ---
                if (hasLogoText && hasNameMatch && hasNpmMatch) {
                    isMatch = true;
                } else {
                    if (!hasLogoText) failReason = "Teks 'UTama' kurang jelas.";
                    else if (!hasNameMatch) failReason = `Nama depan '${googleFirstName}' tidak terbaca jelas di kartu.`;
                    else if (!hasNpmMatch) failReason = `NPM '${targetNpmNumbers}' tidak terbaca jelas di kartu.`;
                }

                if (isMatch) {
                    startKtmCountdown(videoElement);
                } else {
                    if (isKtmStable) {
                        cancelKtmCountdown();
                    } else {
                        statusText.style.color = '#ff3333';
                        statusText.innerText = failReason;
                    }
                }

            } catch (err) {
                isOcrProcessing = false;
                // console.error("[OCR ERROR]", err);
                if (isKtmStable) cancelKtmCountdown();
            }
        }
        // Atur jeda scan agar tidak terlalu membebani CPU HP (misal 300ms)
        setTimeout(() => requestAnimationFrame(scanLoop), 300);
    };

    scanLoop();
}

function startKtmCountdown(videoElement) {
    if (isKtmStable) return;
    
    isKtmStable = true;
    ktmTimer = 3;

    const countdownOverlay = document.getElementById('ktmCountdownOverlay');
    const statusText = document.getElementById('ktmStatus');
    const scanBox = document.getElementById('scanBox');

    countdownOverlay.style.display = 'block';
    countdownOverlay.innerText = ktmTimer;
    statusText.style.color = '#00ffff';
    statusText.innerText = "Data mahasiswa tervalidasi. Tahan posisi Anda...";
    scanBox.style.borderColor = '#00ff00'; 

    ktmInterval = setInterval(() => {
        ktmTimer--;
        if (ktmTimer > 0) {
            countdownOverlay.innerText = ktmTimer;
        } else {
            clearInterval(ktmInterval);
            captureKtmAndProceed(videoElement);
        }
    }, 1000);
}

function cancelKtmCountdown() {
    isKtmStable = false;
    clearInterval(ktmInterval);
    document.getElementById('ktmCountdownOverlay').style.display = 'none';
    
    const statusText = document.getElementById('ktmStatus');
    const scanBox = document.getElementById('scanBox');
    statusText.style.color = '#ff3333';
    statusText.innerText = "KTM tidak terdeteksi. Silahkan arahkan ke kamera...";
    scanBox.style.borderColor = '#00ffff'; 
}

function captureKtmAndProceed(videoElement) {
    const statusText = document.getElementById('ktmStatus');
    statusText.style.color = '#00ff00';
    statusText.innerText = "Menyimpan foto KTM...";

    const canvas = document.createElement('canvas');
    // Simpan resolusi Full HD asli kamera
    canvas.width = videoElement.videoWidth;
    canvas.height = videoElement.videoHeight;
    const ctx = canvas.getContext('2d');
    
    ctx.drawImage(videoElement, 0, 0, canvas.width, canvas.height);
    
    capturedKtmBase64 = canvas.toDataURL('image/jpeg', 0.8);

    if (ktmStream) {
        ktmStream.getTracks().forEach(track => track.stop());
    }

    setTimeout(() => {
        document.getElementById('ktmScreen').classList.remove('active');
        setTimeout(() => {
            document.getElementById('rulesScreen').classList.add('active');
        }, 500);
    }, 1000);
}

// ==========================================
// FUNGSI ANIMASI PARTIKEL (Dari arOS) - Tetap
// ==========================================
function splitTextToParticles(elementId, baseDelay) {
    const el = document.getElementById(elementId);
    if (!el) return;
    const text = el.innerText;
    el.innerText = ''; 
    for (let i = 0; i < text.length; i++) {
        let span = document.createElement('span');
        span.className = 'letter-particle';
        if (text[i] === ' ') {
            span.innerHTML = '&nbsp;';
            span.classList.add('space-char');
        } else { span.innerHTML = text[i]; }
        let rx = (Math.random() - 0.5) * 2000;
        let ry = (Math.random() - 0.5) * 2000;
        let rz = (Math.random() - 0.5) * 2000;
        span.style.setProperty('--rx', rx);
        span.style.setProperty('--ry', ry);
        span.style.setProperty('--rz', rz);
        if (elementId === 'introTitle') {
            if (i === 0 || i === 1 || i === 12 || i === 13) {
                span.style.setProperty('--target-color', '#00ffff'); 
                span.style.setProperty('--target-shadow', '0 0 15px #00ffff, 0 0 30px #00ffff'); 
            } else {
                span.style.setProperty('--target-color', '#ffffff'); 
                span.style.setProperty('--target-shadow', '0 0 8px rgba(255, 255, 255, 0.6)'); 
            }
        } else if (elementId === 'introSubtitle') {
            span.style.setProperty('--target-color', '#00ffff'); 
            span.style.setProperty('--target-shadow', 'none'); 
        }
        let delay = baseDelay + (i * 0.04); 
        span.style.animation = `assembleLetter 6s cubic-bezier(0.25, 1, 0.3, 1) ${delay}s forwards`;
        el.appendChild(span);
    }
}

function generateParticles() {
    const wrap = document.getElementById('particle-container');
    if (!wrap) return;
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    canvas.width = 700;
    canvas.height = 300;
    ctx.fillStyle = "white";
    ctx.font = "bold 160px 'Varela Round', sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("arOS", canvas.width / 2, canvas.height / 2);
    const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height).data;
    const step = 6; 
    for (let y = 0; y < canvas.height; y += step) {
        for (let x = 0; x < canvas.width; x += step) {
            const alpha = imgData[(y * canvas.width + x) * 4 + 3];
            if (alpha > 128) {
                let div = document.createElement('div');
                div.className = 'c';
                let tx = x - (canvas.width / 2);
                let ty = y - (canvas.height / 2);
                let sx = (Math.random() - 0.5) * 3000;
                let sy = (Math.random() - 0.5) * 3000;
                let sz = (Math.random() - 0.5) * 3000;
                div.style.backgroundColor = '#ffffff';
                div.style.boxShadow = '0 0 8px #ffffff';
                div.style.setProperty('--tx', `${tx}px`);
                div.style.setProperty('--ty', `${ty}px`);
                div.style.setProperty('--sx', `${sx}px`);
                div.style.setProperty('--sy', `${sy}px`);
                div.style.setProperty('--sz', `${sz}px`);
                div.style.animationDelay = `${Math.random() * 1.5}s`;
                wrap.appendChild(div);
            }
        }
    }
}

// ==========================================
// KONTROL ALUR & FUNGSI NLP PERIZINAN LAB
// ==========================================
document.addEventListener("DOMContentLoaded", () => {
    generateParticles();
    
    const particleContainer = document.getElementById('particle-container');
    const introTextContainer = document.getElementById('introTextContainer');

    const introScreen = document.getElementById('introScreen');
    const loginScreen = document.getElementById('loginScreen');
    const rulesScreen = document.getElementById('rulesScreen');
    const mainScreen = document.getElementById('mainScreen');
    const resultScreen = document.getElementById('resultScreen');

    const btnUnderstand = document.getElementById('btn-understand');
    const cliOutput = document.getElementById('cli-output');
    const cliInput = document.getElementById('cli-input');
    const btnSelesai = document.getElementById('btn-selesai');

    setTimeout(() => {
        if (particleContainer) {
            particleContainer.classList.add('destroy-particles');
            setTimeout(() => particleContainer.remove(), 2000); 
        }
    }, 4000); 

    setTimeout(() => {
        if (introTextContainer) {
            introTextContainer.style.display = 'block'; 
            introTextContainer.style.opacity = '1';
        }
        splitTextToParticles('introTitle', 0);
        splitTextToParticles('introSubtitle', 0.3);
    }, 4500); 

    setTimeout(() => {
        if (introTextContainer) introTextContainer.style.display = 'none';
        introScreen.classList.remove('active');
        setTimeout(() => {
            loginScreen.classList.add('active'); 
        }, 500);
    }, 12500); 

    btnUnderstand.addEventListener('click', () => {
        rulesScreen.classList.remove('active');
        setTimeout(() => {
            mainScreen.classList.add('active');
            initCLI();
            cliInput.focus();
        }, 500);
    });

    function printLine(text, className = '') {
        const p = document.createElement('p');
        p.textContent = text;
        if (className) p.className = className;
        else p.className = 'log-system'; 
        
        cliOutput.appendChild(p);
        cliOutput.scrollTop = cliOutput.scrollHeight;
    }

    function initCLI() {
        printLine("[arOS-AI] TERHUBUNG KE EKOSISTEM ARCHUSKHA (arOS-core-0.0.1)", "log-user");
        setTimeout(() => {
            printLine("[arOS-AI]: Halo! Silakan ajukan peminjaman dengan menyebutkan nama, NPM, email, angkatan, tujuan, jam peminjaman, serta kategorinya.", "log-system");
        }, 800);
        setTimeout(() => {
            printLine("Contoh: Saya [Nama Anda] dengan NPM [NPM/NIM Anda] dari angkatan [contoh: 2023] dan email [Email kampus Anda], ingin meminjam lab [dan kunci, jika Anda ingin meminjam alat dari lab itu wajib meminjam kunci lemari juga dan wajib memasukkan nama alatnya] untuk keperluan [Tujuan Anda meminjam fasilitas] dari jam 9 pagi sampai jam 2 siang [Wajib menyebutkan jamnya].", "log-system");
        }, 1300);
    }

    function showResultBox(data) {
        mainScreen.classList.remove('active');
        setTimeout(() => {
            resultScreen.classList.add('active');
        }, 500);

        const kategoriList = data.kategori ? data.kategori.join(' & ') : '-';
        
        document.getElementById('res-jenis').textContent = kategoriList;
        document.getElementById('res-nama').textContent = data.nama || '-';
        document.getElementById('res-npm').textContent = data.npm || '-';
        document.getElementById('res-email').textContent = data.email || '-';
        document.getElementById('res-angkatan').textContent = data.angkatan || '-';
        document.getElementById('res-tujuan').textContent = data.tujuan || '-';
        document.getElementById('res-tanggal').textContent = data.tanggal || '-';
        document.getElementById('res-jam').textContent = `${data.jam_mulai || '-'} - ${data.jam_selesai || '-'}`;

        const now = new Date();
        const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit' };
        document.getElementById('res-timestamp').textContent = `Dikirim pada: ${now.toLocaleDateString('id-ID', options)}`;
    }

    cliInput.addEventListener('keydown', async function(e) {
        if (e.key === 'Enter') {
            const val = this.value.trim();
            if (!val) return;

            printLine(`User > ${val}`, "log-user");
            this.value = '';
            cliInput.disabled = true;

            const loadingMsg = document.createElement('p');
            loadingMsg.textContent = "[arOS-AI] Sistem sedang memproses, harap tunggu...";
            loadingMsg.className = "log-system";
            cliOutput.appendChild(loadingMsg);
            cliOutput.scrollTop = cliOutput.scrollHeight;

            try {
                const response = await fetch(backendUrl, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ 
                        message: val,
                        googleName: currentUserGoogleName,
                        // Pastikan backend menerima field ini
                        imageBase64: capturedBiometricBase64,
                        ktmBase64: capturedKtmBase64
                    })
                });
                
                if (!response.ok) {
                    throw new Error(`HTTP ${response.status} - Nginx gagal meneruskan request. Pastikan Console C# berjalan.`);
                }

                const resultData = await response.json();
                
                loadingMsg.remove();
                printLine(`[arOS-AI]: ${resultData.ai_response}`, "log-system");

                if (resultData.is_booking === true) {
                    setTimeout(() => showResultBox(resultData), 2000); 
                }

            } catch (err) {
                loadingMsg.remove();
                printLine(`[ERROR] ${err.message}`, "log-error");
            }
            
            cliInput.disabled = false;
            cliInput.focus();
        }
    });

    btnSelesai.addEventListener('click', () => {
        location.reload(); 
    });
});