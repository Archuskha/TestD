const backendUrl = '/api-lab/';

// ==========================================
// FUNGSI ANIMASI PARTIKEL (Dari arOS)
// ==========================================
function splitTextToParticles(elementId, baseDelay) {
    const el = document.getElementById(elementId);
    if (!el) return;
    
    const text = el.innerText;
    el.innerText = ''; 
    
    for (let i = 0; i < text.length; i++) {
        let span = document.createElement('span');
        span.className = 'letter-particle';
        
        // PEMBERIAN KELAS KHUSUS PADA SPASI UNTUK RESPONSIVITAS MOBILE
        if (text[i] === ' ') {
            span.innerHTML = '&nbsp;';
            span.classList.add('space-char');
        } else {
            span.innerHTML = text[i];
        }
        
        let rx = (Math.random() - 0.5) * 2000;
        let ry = (Math.random() - 0.5) * 2000;
        let rz = (Math.random() - 0.5) * 2000;
        
        span.style.setProperty('--rx', rx);
        span.style.setProperty('--ry', ry);
        span.style.setProperty('--rz', rz);
        
        if (elementId === 'introTitle') {
            if (i === 0 || i === 1 || i === 12 || i === 13) {
                span.style.setProperty('--target-color', '#00ffff'); 
                span.style.setProperty('--target-shadow', '0 0 15px #00ffff, 0 0 30px #00ffff'); 
            } else {
                span.style.setProperty('--target-color', '#ffffff'); 
                span.style.setProperty('--target-shadow', '0 0 8px rgba(255, 255, 255, 0.6)'); 
            }
        } else if (elementId === 'introSubtitle') {
            span.style.setProperty('--target-color', '#00ffff'); 
            span.style.setProperty('--target-shadow', 'none'); 
        }
        
        let delay = baseDelay + (i * 0.04); 
        span.style.animation = `assembleLetter 6s cubic-bezier(0.25, 1, 0.3, 1) ${delay}s forwards`;
        
        el.appendChild(span);
    }
}

function generateParticles() {
    const wrap = document.getElementById('particle-container');
    if (!wrap) return;

    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    canvas.width = 700;
    canvas.height = 300;

    ctx.fillStyle = "white";
    ctx.font = "bold 160px 'Varela Round', sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("arOS", canvas.width / 2, canvas.height / 2);

    const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height).data;
    const step = 6; 

    for (let y = 0; y < canvas.height; y += step) {
        for (let x = 0; x < canvas.width; x += step) {
            const alpha = imgData[(y * canvas.width + x) * 4 + 3];
            if (alpha > 128) {
                let div = document.createElement('div');
                div.className = 'c';

                let tx = x - (canvas.width / 2);
                let ty = y - (canvas.height / 2);
                
                let sx = (Math.random() - 0.5) * 3000;
                let sy = (Math.random() - 0.5) * 3000;
                let sz = (Math.random() - 0.5) * 3000;

                div.style.backgroundColor = '#ffffff';
                div.style.boxShadow = '0 0 8px #ffffff';

                div.style.setProperty('--tx', `${tx}px`);
                div.style.setProperty('--ty', `${ty}px`);
                div.style.setProperty('--sx', `${sx}px`);
                div.style.setProperty('--sy', `${sy}px`);
                div.style.setProperty('--sz', `${sz}px`);

                div.style.animationDelay = `${Math.random() * 1.5}s`;

                wrap.appendChild(div);
            }
        }
    }
}

// ==========================================
// KONTROL ALUR & FUNGSI NLP PERIZINAN LAB
// ==========================================
document.addEventListener("DOMContentLoaded", () => {
    // Inisialisasi Animasi Intro
    generateParticles();
    
    const particleContainer = document.getElementById('particle-container');
    const introTextContainer = document.getElementById('introTextContainer');

    const introScreen = document.getElementById('introScreen');
    const rulesScreen = document.getElementById('rulesScreen');
    const mainScreen = document.getElementById('mainScreen');
    const resultScreen = document.getElementById('resultScreen');

    const btnUnderstand = document.getElementById('btn-understand');
    const cliOutput = document.getElementById('cli-output');
    const cliInput = document.getElementById('cli-input');
    const btnSelesai = document.getElementById('btn-selesai');

    // Alur Waktu Animasi
    setTimeout(() => {
        if (particleContainer) {
            particleContainer.classList.add('destroy-particles');
            setTimeout(() => particleContainer.remove(), 2000); 
        }
    }, 4000); 

    setTimeout(() => {
        if (introTextContainer) {
            introTextContainer.style.display = 'block'; 
            introTextContainer.style.opacity = '1';
        }
        splitTextToParticles('introTitle', 0);
        splitTextToParticles('introSubtitle', 0.3);
    }, 4500); 

    // Pindah ke layar Tata Tertib setelah animasi selesai
    setTimeout(() => {
        if (introTextContainer) introTextContainer.style.display = 'none';
        introScreen.classList.remove('active');
        setTimeout(() => {
            rulesScreen.classList.add('active');
        }, 500);
    }, 12500); 

    // Alur: Tata Tertib -> Terminal NLP
    btnUnderstand.addEventListener('click', () => {
        rulesScreen.classList.remove('active');
        setTimeout(() => {
            mainScreen.classList.add('active');
            initCLI();
            cliInput.focus();
        }, 500);
    });

    // Fungsi Render Teks Konsol
    function printLine(text, className = '') {
        const p = document.createElement('p');
        p.textContent = text;
        if (className) p.className = className;
        else p.className = 'log-system'; 
        
        cliOutput.appendChild(p);
        cliOutput.scrollTop = cliOutput.scrollHeight;
    }

    function initCLI() {
        printLine("[arOS-AI] TERHUBUNG KE EKOSISTEM ARCHUSKHA (arOS-core-0.0.1)", "log-user");
        setTimeout(() => {
            printLine("[arOS-AI]: Halo! Silakan ajukan peminjaman dengan menyebutkan nama, NPM, email, angkatan, tujuan, jam peminjaman, serta kategorinya.", "log-system");
        }, 800);
        setTimeout(() => {
            printLine("Contoh: Saya [Nama Anda] dengan NPM [NPM/NIM Anda] dari angkatan [contoh: 2023] dan email [Email kampus Anda], ingin meminjam lab [dan kunci, jika Anda ingin meminjam alat dari lab itu wajib meminjam kunci lemari juga dan wajib memasukkan nama alatnya] untuk keperluan [Tujuan Anda meminjam fasilitas] dari jam 9 pagi sampai jam 2 siang [Wajib menyebutkan jamnya].", "log-system");
        }, 1300);
    }

    // Menampilkan Hasil Pengajuan
    function showResultBox(data) {
        mainScreen.classList.remove('active');
        setTimeout(() => {
            resultScreen.classList.add('active');
        }, 500);

        const kategoriList = data.kategori ? data.kategori.join(' & ') : '-';
        
        document.getElementById('res-jenis').textContent = kategoriList;
        document.getElementById('res-nama').textContent = data.nama || '-';
        document.getElementById('res-npm').textContent = data.npm || '-';
        document.getElementById('res-email').textContent = data.email || '-';
        document.getElementById('res-angkatan').textContent = data.angkatan || '-';
        document.getElementById('res-tujuan').textContent = data.tujuan || '-';
        document.getElementById('res-tanggal').textContent = data.tanggal || '-';
        document.getElementById('res-jam').textContent = `${data.jam_mulai || '-'} - ${data.jam_selesai || '-'}`;

        const now = new Date();
        const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit' };
        document.getElementById('res-timestamp').textContent = `Dikirim pada: ${now.toLocaleDateString('id-ID', options)}`;
    }

    // Menangani Input Pengguna
    cliInput.addEventListener('keydown', async function(e) {
        if (e.key === 'Enter') {
            const val = this.value.trim();
            if (!val) return;

            printLine(`User > ${val}`, "log-user");
            this.value = '';
            cliInput.disabled = true;

            const loadingMsg = document.createElement('p');
            loadingMsg.textContent = "[arOS-AI] Sistem sedang memproses...";
            loadingMsg.className = "log-system";
            cliOutput.appendChild(loadingMsg);
            cliOutput.scrollTop = cliOutput.scrollHeight;

            try {
                const response = await fetch(backendUrl, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ message: val })
                });
                
                if (!response.ok) {
                    throw new Error(`HTTP ${response.status} - Nginx gagal meneruskan request. Pastikan Console C# berjalan.`);
                }

                const resultData = await response.json();
                
                loadingMsg.remove();
                printLine(`[arOS-AI]: ${resultData.ai_response}`, "log-system");

                // Jika berhasil *booking*, tampilkan kotak hasil
                if (resultData.is_booking === true) {
                    setTimeout(() => showResultBox(resultData), 2000); 
                }

            } catch (err) {
                loadingMsg.remove();
                printLine(`[ERROR] ${err.message}`, "log-error");
            }
            
            cliInput.disabled = false;
            cliInput.focus();
        }
    });

    // Reset sistem
    btnSelesai.addEventListener('click', () => {
        location.reload(); 
    });
});