const backendUrl = '/api-lab/';
const loginUrl = '/api-login/';

let currentUserGoogleName = "";
let capturedBiometricBase64 = ""; 
let capturedKtmBase64 = "";       

// Variabel Global Biometrik Wajah
let faceTimer = 3; // Diseragamkan 3 detik
let isFaceStable = false;
let faceInterval = null;
let cameraInstance = null;

// Variabel Global Biometrik KTM
let ktmTimer = 3; // Diseragamkan 3 detik
let isKtmStable = false;
let ktmInterval = null;
let ktmStream = null;
let isOcrProcessing = false;

// Inisialisasi AI Scanner
const zxingReader = new ZXing.BrowserMultiFormatReader();
let tesseractWorker = null;

// Memuat Tesseract di memori awal agar tidak lag saat menscan KTM
async function initTesseractWorker() {
    try {
        tesseractWorker = await Tesseract.createWorker('eng');
        console.log("[arOS-AI] Tesseract OCR Engine Ready.");
    } catch (e) {
        console.error("[ERROR] Gagal memuat modul OCR:", e);
    }
}
initTesseractWorker();

// ==========================================
// FUNGSI GOOGLE LOGIN & JWT DECODER
// ==========================================
function parseJwt(token) {
    try {
        var base64Url = token.split('.')[1];
        var base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
        var jsonPayload = decodeURIComponent(atob(base64).split('').map(function(c) {
            return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
        }).join(''));
        return JSON.parse(jsonPayload);
    } catch (e) {
        return null;
    }
}

window.handleCredentialResponse = function(response) {
    const data = parseJwt(response.credential);
    const loginError = document.getElementById('loginError');

    if (data && data.email && data.email.endsWith("@widyatama.ac.id")) {
        loginError.style.display = 'none';
        currentUserGoogleName = data.name;
        
        fetch(loginUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email: data.email, name: data.name })
        }).catch(err => console.error("Gagal kirim notifikasi", err));

        document.getElementById('loginScreen').classList.remove('active');
        setTimeout(() => {
            document.getElementById('biometricScreen').classList.add('active');
            initBiometricScan(); 
        }, 500);
    } else {
        loginError.style.display = 'block';
    }
};

// ==========================================
// 1. FUNGSI BIOMETRIK WAJAH (MediaPipe)
// ==========================================
function initBiometricScan() {
    const videoElement = document.getElementById('webcam');
    const countdownOverlay = document.getElementById('countdownOverlay');
    const statusText = document.getElementById('biometricStatus');

    const faceDetection = new FaceDetection({
        locateFile: (file) => {
            return `https://cdn.jsdelivr.net/npm/@mediapipe/face_detection/${file}`;
        }
    });

    faceDetection.setOptions({
        model: 'short',
        minDetectionConfidence: 0.7
    });

    faceDetection.onResults((results) => {
        if (results.detections.length > 0) {
            if (!isFaceStable) {
                isFaceStable = true;
                faceTimer = 3;
                countdownOverlay.style.display = 'block';
                countdownOverlay.innerText = faceTimer;
                statusText.style.color = '#00ffff';
                statusText.innerText = "Wajah terdeteksi. Pertahankan posisi Anda...";

                faceInterval = setInterval(() => {
                    faceTimer--;
                    if (faceTimer > 0) {
                        countdownOverlay.innerText = faceTimer;
                    } else {
                        clearInterval(faceInterval);
                        captureAndProceedToKTM(videoElement);
                    }
                }, 1000);
            }
        } else {
            if (isFaceStable) {
                isFaceStable = false;
                clearInterval(faceInterval);
                countdownOverlay.style.display = 'none';
                statusText.style.color = '#ff3333';
                statusText.innerText = "Wajah hilang/tidak terdeteksi. Proses diulang...";
            } else {
                statusText.innerText = "Silakan arahkan wajah Anda ke kamera...";
                statusText.style.color = '#ff3333';
            }
        }
    });

    cameraInstance = new Camera(videoElement, {
        onFrame: async () => {
            await faceDetection.send({ image: videoElement });
        },
        width: 640,
        height: 480
    });
    
    cameraInstance.start();
}

function captureAndProceedToKTM(videoElement) {
    const statusText = document.getElementById('biometricStatus');
    statusText.style.color = '#00ff00';
    statusText.innerText = "Verifikasi wajah berhasil.";
    
    const canvas = document.createElement('canvas');
    canvas.width = videoElement.videoWidth;
    canvas.height = videoElement.videoHeight;
    const ctx = canvas.getContext('2d');
    
    ctx.translate(canvas.width, 0);
    ctx.scale(-1, 1);
    ctx.drawImage(videoElement, 0, 0, canvas.width, canvas.height);
    
    capturedBiometricBase64 = canvas.toDataURL('image/jpeg', 0.8);

    setTimeout(() => {
        if(cameraInstance) {
            cameraInstance.stop();
        }
        document.getElementById('biometricScreen').classList.remove('active');
        
        // PINDAH KE LAYAR KTM
        setTimeout(() => {
            document.getElementById('ktmScreen').classList.add('active');
            initKtmScan();
        }, 500);
    }, 1000);
}

// ==========================================
// 2. FUNGSI BIOMETRIK KTM (ZXing & Tesseract)
// ==========================================
async function initKtmScan() {
    const videoElement = document.getElementById('ktmWebcam');
    const statusText = document.getElementById('ktmStatus');
    
    try {
        // Optimasi: Meminta fitur auto-focus jika tersedia pada perangkat
        ktmStream = await navigator.mediaDevices.getUserMedia({
            video: { 
                facingMode: { ideal: "environment" },
                advanced: [{ focusMode: "continuous" }]
            }
        });
        videoElement.srcObject = ktmStream;
    } catch (err) {
        statusText.style.color = '#ff3333';
        statusText.innerText = "Gagal mengakses kamera belakang. Pastikan izin kamera diberikan.";
        return;
    }

    statusText.style.color = '#00ffff';
    statusText.innerText = "Mencari Barcode/QR Code pada KTM...";

    // Kanvas internal untuk proses scanning (Sangat penting agar HP tidak hang)
    const processCanvas = document.createElement('canvas');
    const processCtx = processCanvas.getContext('2d', { willReadFrequently: true });

    const scanLoop = async () => {
        if (!document.getElementById('ktmScreen').classList.contains('active')) return;

        if (videoElement.readyState === videoElement.HAVE_ENOUGH_DATA) {
            // Kompresi resolusi gambar ke max 640px lebar agar AI super cepat mendeteksi
            const MAX_WIDTH = 640;
            const scale = Math.min(MAX_WIDTH / videoElement.videoWidth, 1);
            processCanvas.width = videoElement.videoWidth * scale;
            processCanvas.height = videoElement.videoHeight * scale;
            processCtx.drawImage(videoElement, 0, 0, processCanvas.width, processCanvas.height);

            try {
                // TAHAP 1: Cari Barcode / QR Code pada gambar yang sudah di kompresi
                const result = await zxingReader.decodeFromCanvas(processCanvas);

                if (result) {
                    if (!isOcrProcessing && !isKtmStable) {
                        isOcrProcessing = true;
                        statusText.style.color = '#ffff00';
                        statusText.innerText = "NPM terdeteksi. Menganalisis tingkat lanjut...";

                        try {
                            let textRead = "";
                            // Gunakan Tesseract yang sudah di-preload untuk kecepatan instan
                            if (tesseractWorker) {
                                const ret = await tesseractWorker.recognize(processCanvas);
                                textRead = ret.data.text;
                            } else {
                                const ret = await Tesseract.recognize(processCanvas, 'eng');
                                textRead = ret.data.text;
                            }
                            
                            isOcrProcessing = false;

                            // Hapus semua spasi dan simbol, jadikan huruf kecil untuk deteksi logo
                            const textClean = textRead.toLowerCase().replace(/[^a-z0-9]/g, '');
                            
                            // Toleransi kata kunci
                            if (textClean.includes("utama") || textClean.includes("widyatama") || textClean.includes("mahasiswa") || textClean.includes("teknik") || textClean.includes("elektro")) {
                                startKtmCountdown(videoElement);
                            } else {
                                statusText.style.color = '#ff3333';
                                statusText.innerText = "Tulisan 'UTama' tidak terdeteksi. Tahan posisi atau sesuaikan fokus.";
                            }
                        } catch(ocrErr) {
                            isOcrProcessing = false;
                            console.error("[OCR ERROR]", ocrErr);
                        }
                    } 
                }
            } catch (err) {
                if (isKtmStable) {
                    cancelKtmCountdown();
                }
            }
        }
        requestAnimationFrame(scanLoop);
    };

    scanLoop();
}

function startKtmCountdown(videoElement) {
    if (isKtmStable) return;
    
    isKtmStable = true;
    ktmTimer = 3;

    const countdownOverlay = document.getElementById('ktmCountdownOverlay');
    const statusText = document.getElementById('ktmStatus');

    countdownOverlay.style.display = 'block';
    countdownOverlay.innerText = ktmTimer;
    statusText.style.color = '#00ffff';
    statusText.innerText = "KTM Tervalidasi. Tahan posisi Anda...";

    ktmInterval = setInterval(() => {
        ktmTimer--;
        if (ktmTimer > 0) {
            countdownOverlay.innerText = ktmTimer;
        } else {
            clearInterval(ktmInterval);
            captureKtmAndProceed(videoElement);
        }
    }, 1000);
}

function cancelKtmCountdown() {
    isKtmStable = false;
    clearInterval(ktmInterval);
    document.getElementById('ktmCountdownOverlay').style.display = 'none';
    
    const statusText = document.getElementById('ktmStatus');
    statusText.style.color = '#ff3333';
    statusText.innerText = "Posisi KTM berubah atau terhalang. Fokus ulang...";
}

function captureKtmAndProceed(videoElement) {
    const statusText = document.getElementById('ktmStatus');
    statusText.style.color = '#00ff00';
    statusText.innerText = "Verifikasi KTM telah berhasil.";

    const canvas = document.createElement('canvas');
    canvas.width = videoElement.videoWidth;
    canvas.height = videoElement.videoHeight;
    const ctx = canvas.getContext('2d');
    
    ctx.drawImage(videoElement, 0, 0, canvas.width, canvas.height);
    
    capturedKtmBase64 = canvas.toDataURL('image/jpeg', 0.8);

    if (ktmStream) {
        ktmStream.getTracks().forEach(track => track.stop());
    }

    setTimeout(() => {
        document.getElementById('ktmScreen').classList.remove('active');
        setTimeout(() => {
            document.getElementById('rulesScreen').classList.add('active');
        }, 500);
    }, 1000);
}

// ==========================================
// FUNGSI ANIMASI PARTIKEL (Dari arOS)
// ==========================================
function splitTextToParticles(elementId, baseDelay) {
    const el = document.getElementById(elementId);
    if (!el) return;
    const text = el.innerText;
    el.innerText = ''; 
    for (let i = 0; i < text.length; i++) {
        let span = document.createElement('span');
        span.className = 'letter-particle';
        if (text[i] === ' ') {
            span.innerHTML = '&nbsp;';
            span.classList.add('space-char');
        } else { span.innerHTML = text[i]; }
        let rx = (Math.random() - 0.5) * 2000;
        let ry = (Math.random() - 0.5) * 2000;
        let rz = (Math.random() - 0.5) * 2000;
        span.style.setProperty('--rx', rx);
        span.style.setProperty('--ry', ry);
        span.style.setProperty('--rz', rz);
        if (elementId === 'introTitle') {
            if (i === 0 || i === 1 || i === 12 || i === 13) {
                span.style.setProperty('--target-color', '#00ffff'); 
                span.style.setProperty('--target-shadow', '0 0 15px #00ffff, 0 0 30px #00ffff'); 
            } else {
                span.style.setProperty('--target-color', '#ffffff'); 
                span.style.setProperty('--target-shadow', '0 0 8px rgba(255, 255, 255, 0.6)'); 
            }
        } else if (elementId === 'introSubtitle') {
            span.style.setProperty('--target-color', '#00ffff'); 
            span.style.setProperty('--target-shadow', 'none'); 
        }
        let delay = baseDelay + (i * 0.04); 
        span.style.animation = `assembleLetter 6s cubic-bezier(0.25, 1, 0.3, 1) ${delay}s forwards`;
        el.appendChild(span);
    }
}

function generateParticles() {
    const wrap = document.getElementById('particle-container');
    if (!wrap) return;
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    canvas.width = 700;
    canvas.height = 300;
    ctx.fillStyle = "white";
    ctx.font = "bold 160px 'Varela Round', sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("arOS", canvas.width / 2, canvas.height / 2);
    const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height).data;
    const step = 6; 
    for (let y = 0; y < canvas.height; y += step) {
        for (let x = 0; x < canvas.width; x += step) {
            const alpha = imgData[(y * canvas.width + x) * 4 + 3];
            if (alpha > 128) {
                let div = document.createElement('div');
                div.className = 'c';
                let tx = x - (canvas.width / 2);
                let ty = y - (canvas.height / 2);
                let sx = (Math.random() - 0.5) * 3000;
                let sy = (Math.random() - 0.5) * 3000;
                let sz = (Math.random() - 0.5) * 3000;
                div.style.backgroundColor = '#ffffff';
                div.style.boxShadow = '0 0 8px #ffffff';
                div.style.setProperty('--tx', `${tx}px`);
                div.style.setProperty('--ty', `${ty}px`);
                div.style.setProperty('--sx', `${sx}px`);
                div.style.setProperty('--sy', `${sy}px`);
                div.style.setProperty('--sz', `${sz}px`);
                div.style.animationDelay = `${Math.random() * 1.5}s`;
                wrap.appendChild(div);
            }
        }
    }
}

// ==========================================
// KONTROL ALUR & FUNGSI NLP PERIZINAN LAB
// ==========================================
document.addEventListener("DOMContentLoaded", () => {
    generateParticles();
    
    const particleContainer = document.getElementById('particle-container');
    const introTextContainer = document.getElementById('introTextContainer');

    const introScreen = document.getElementById('introScreen');
    const loginScreen = document.getElementById('loginScreen');
    const rulesScreen = document.getElementById('rulesScreen');
    const mainScreen = document.getElementById('mainScreen');
    const resultScreen = document.getElementById('resultScreen');

    const btnUnderstand = document.getElementById('btn-understand');
    const cliOutput = document.getElementById('cli-output');
    const cliInput = document.getElementById('cli-input');
    const btnSelesai = document.getElementById('btn-selesai');

    setTimeout(() => {
        if (particleContainer) {
            particleContainer.classList.add('destroy-particles');
            setTimeout(() => particleContainer.remove(), 2000); 
        }
    }, 4000); 

    setTimeout(() => {
        if (introTextContainer) {
            introTextContainer.style.display = 'block'; 
            introTextContainer.style.opacity = '1';
        }
        splitTextToParticles('introTitle', 0);
        splitTextToParticles('introSubtitle', 0.3);
    }, 4500); 

    setTimeout(() => {
        if (introTextContainer) introTextContainer.style.display = 'none';
        introScreen.classList.remove('active');
        setTimeout(() => {
            loginScreen.classList.add('active'); 
        }, 500);
    }, 12500); 

    btnUnderstand.addEventListener('click', () => {
        rulesScreen.classList.remove('active');
        setTimeout(() => {
            mainScreen.classList.add('active');
            initCLI();
            cliInput.focus();
        }, 500);
    });

    function printLine(text, className = '') {
        const p = document.createElement('p');
        p.textContent = text;
        if (className) p.className = className;
        else p.className = 'log-system'; 
        
        cliOutput.appendChild(p);
        cliOutput.scrollTop = cliOutput.scrollHeight;
    }

    function initCLI() {
        printLine("[arOS-AI] TERHUBUNG KE EKOSISTEM ARCHUSKHA (arOS-core-0.0.1)", "log-user");
        setTimeout(() => {
            printLine("[arOS-AI]: Halo! Silakan ajukan peminjaman dengan menyebutkan nama, NPM, email, angkatan, tujuan, jam peminjaman, serta kategorinya.", "log-system");
        }, 800);
        setTimeout(() => {
            printLine("Contoh: Saya [Nama Anda] dengan NPM [NPM/NIM Anda] dari angkatan [contoh: 2023] dan email [Email kampus Anda], ingin meminjam lab [dan kunci, jika Anda ingin meminjam alat dari lab itu wajib meminjam kunci lemari juga dan wajib memasukkan nama alatnya] untuk keperluan [Tujuan Anda meminjam fasilitas] dari jam 9 pagi sampai jam 2 siang [Wajib menyebutkan jamnya].", "log-system");
        }, 1300);
    }

    function showResultBox(data) {
        mainScreen.classList.remove('active');
        setTimeout(() => {
            resultScreen.classList.add('active');
        }, 500);

        const kategoriList = data.kategori ? data.kategori.join(' & ') : '-';
        
        document.getElementById('res-jenis').textContent = kategoriList;
        document.getElementById('res-nama').textContent = data.nama || '-';
        document.getElementById('res-npm').textContent = data.npm || '-';
        document.getElementById('res-email').textContent = data.email || '-';
        document.getElementById('res-angkatan').textContent = data.angkatan || '-';
        document.getElementById('res-tujuan').textContent = data.tujuan || '-';
        document.getElementById('res-tanggal').textContent = data.tanggal || '-';
        document.getElementById('res-jam').textContent = `${data.jam_mulai || '-'} - ${data.jam_selesai || '-'}`;

        const now = new Date();
        const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit' };
        document.getElementById('res-timestamp').textContent = `Dikirim pada: ${now.toLocaleDateString('id-ID', options)}`;
    }

    cliInput.addEventListener('keydown', async function(e) {
        if (e.key === 'Enter') {
            const val = this.value.trim();
            if (!val) return;

            printLine(`User > ${val}`, "log-user");
            this.value = '';
            cliInput.disabled = true;

            const loadingMsg = document.createElement('p');
            loadingMsg.textContent = "[arOS-AI] Sistem sedang memproses, harap tunggu...";
            loadingMsg.className = "log-system";
            cliOutput.appendChild(loadingMsg);
            cliOutput.scrollTop = cliOutput.scrollHeight;

            try {
                const response = await fetch(backendUrl, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ 
                        message: val,
                        googleName: currentUserGoogleName,
                        imageBase64: capturedBiometricBase64,
                        ktmBase64: capturedKtmBase64
                    })
                });
                
                if (!response.ok) {
                    throw new Error(`HTTP ${response.status} - Nginx gagal meneruskan request. Pastikan Console C# berjalan.`);
                }

                const resultData = await response.json();
                
                loadingMsg.remove();
                printLine(`[arOS-AI]: ${resultData.ai_response}`, "log-system");

                if (resultData.is_booking === true) {
                    setTimeout(() => showResultBox(resultData), 2000); 
                }

            } catch (err) {
                loadingMsg.remove();
                printLine(`[ERROR] ${err.message}`, "log-error");
            }
            
            cliInput.disabled = false;
            cliInput.focus();
        }
    });

    btnSelesai.addEventListener('click', () => {
        location.reload(); 
    });
});