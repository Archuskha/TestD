document.addEventListener('DOMContentLoaded', () => {
    const rulesOverlay = document.getElementById('rules-overlay');
    const btnUnderstand = document.getElementById('btn-understand');
    const mainContent = document.getElementById('main-content');

    const cliContainer = document.getElementById('cli-container');
    const cliOutput = document.getElementById('cli-output');
    const cliInput = document.getElementById('cli-input');

    const resultBox = document.getElementById('result-box');
    const btnSelesai = document.getElementById('btn-selesai');

    const backendUrl = 'http://103.150.117.90:6000/api/chat/';

    btnUnderstand.addEventListener('click', () => {
        rulesOverlay.style.opacity = '0';
        
        setTimeout(() => {
            rulesOverlay.classList.add('hidden');
            mainContent.classList.remove('hidden');
            
            initCLI();
            cliInput.focus();
        }, 500); 
    });

    // PENTING: Scroll sekarang terjadi di dalam elemen cliOutput
    function printLine(text, className = '') {
        const p = document.createElement('p');
        p.textContent = text;
        if (className) p.className = className;
        cliOutput.appendChild(p);
        
        // Auto-scroll ke paling bawah di dalam kotak
        cliOutput.scrollTop = cliOutput.scrollHeight;
    }

    function initCLI() {
        printLine("=== SISTEM PERIZINAN LABORATORIUM ELEKTRO ===", "system-msg bold");
        printLine("Memuat modul Archuskha NLP...", "system-msg");
        
        setTimeout(() => {
            printLine("Archuskha: Halo! Silakan ajukan peminjaman dengan menyebutkan nama, NPM, tujuan, jam peminjaman, serta kategori (Lab/Kunci/Pinjam Alat/Kembali Alat).", "success-msg bold");
        }, 800);
    }

    function showResultBox(data) {
        cliContainer.classList.add('hidden');
        resultBox.classList.remove('hidden');

        const kategoriList = data.kategori ? data.kategori.join(' & ') : '-';
        
        document.getElementById('res-jenis').textContent = kategoriList;
        document.getElementById('res-nama').textContent = data.nama || '-';
        document.getElementById('res-npm').textContent = data.npm || '-';
        document.getElementById('res-email').textContent = data.email || '-';
        document.getElementById('res-angkatan').textContent = data.angkatan || '-';
        document.getElementById('res-tujuan').textContent = data.tujuan || '-';
        document.getElementById('res-tanggal').textContent = data.tanggal || '-';
        document.getElementById('res-jam').textContent = `${data.jam_mulai || '-'} - ${data.jam_selesai || '-'}`;

        const now = new Date();
        const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit' };
        document.getElementById('res-timestamp').textContent = `Dikirim pada: ${now.toLocaleDateString('id-ID', options)}`;
    }

    cliInput.addEventListener('keydown', async function(e) {
        if (e.key === 'Enter') {
            const val = this.value.trim();
            if (!val) return;

            printLine(`User > ${val}`, "bold");
            this.value = '';
            cliInput.disabled = true;

            const loadingMsg = document.createElement('p');
            loadingMsg.textContent = "Archuskha sedang memproses NLP...";
            loadingMsg.className = "system-msg";
            cliOutput.appendChild(loadingMsg);
            cliOutput.scrollTop = cliOutput.scrollHeight;

            try {
                const response = await fetch(backendUrl, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ message: val })
                });
                
                const resultData = await response.json();
                
                loadingMsg.remove();
                printLine(`Archuskha: ${resultData.ai_response}`, "success-msg");

                if (resultData.is_booking === true) {
                    setTimeout(() => showResultBox(resultData), 1500); 
                }

            } catch (err) {
                loadingMsg.remove();
                printLine(`[ERROR] Gagal menghubungi server backend: ${err.message}`, "error-msg");
                printLine("Sistem: Pastikan Console App C# sedang berjalan di Linux dan port 6000 terbuka.", "system-msg");
            }
            
            cliInput.disabled = false;
            cliInput.focus();
        }
    });

    btnSelesai.addEventListener('click', () => {
        location.reload(); 
    });
});