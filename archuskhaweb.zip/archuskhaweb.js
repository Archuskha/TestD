const backendUrl = '/api-lab/';
const guiBackendUrl = '/api-lab-gui/';
const loginUrl = '/api-login/';

let currentUserGoogleName = "";
let currentUserGoogleEmail = ""; 
let extractedNpmNumber = "";     // Global penampung NPM yang didapat
let capturedBiometricBase64 = ""; 
let capturedKtmBase64 = "";       

// Variabel Global Biometrik Wajah
let faceTimer = 3; 
let isFaceStable = false;
let faceInterval = null;
let cameraInstance = null;

// Variabel Global Biometrik KTM
let isKtmStable = false; 
let ktmStream = null;
let isOcrProcessing = false;

let tesseractWorker = null;

async function initTesseractWorker() {
    try {
        console.log("[arOS-AI] Memuat Engine Tesseract OCR...");
        tesseractWorker = await Tesseract.createWorker('eng');
        await tesseractWorker.setParameters({
            tessedit_char_whitelist: '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz ',
        });
        console.log("[arOS-AI] Tesseract OCR Engine Ready.");
    } catch (e) { console.error("[ERROR] Gagal memuat modul OCR:", e); }
}
initTesseractWorker();

function parseJwt(token) {
    try {
        var base64Url = token.split('.')[1];
        var base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
        var jsonPayload = decodeURIComponent(atob(base64).split('').map(function(c) {
            return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
        }).join(''));
        return JSON.parse(jsonPayload);
    } catch (e) { return null; }
}

window.handleCredentialResponse = function(response) {
    const data = parseJwt(response.credential);
    const loginError = document.getElementById('loginError');

    if (data && data.email && data.email.endsWith("@widyatama.ac.id")) {
        loginError.style.display = 'none';
        currentUserGoogleName = data.name;
        currentUserGoogleEmail = data.email; 
        
        // Coba ekstrak NPM dari nama atau email saat login sukses
        const matchNumber = currentUserGoogleName.match(/\d{5,}/);
        if (matchNumber) extractedNpmNumber = matchNumber[0];
        else extractedNpmNumber = currentUserGoogleEmail.replace(/[^0-9]/g, '');

        fetch(loginUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email: data.email, name: data.name })
        }).catch(err => console.error("Gagal kirim notifikasi", err));

        document.getElementById('loginScreen').classList.remove('active');
        setTimeout(() => {
            document.getElementById('biometricScreen').classList.add('active');
            initBiometricScan(); 
        }, 500);
    } else { loginError.style.display = 'block'; }
};

function initBiometricScan() {
    const videoElement = document.getElementById('webcam');
    const countdownOverlay = document.getElementById('countdownOverlay');
    const statusText = document.getElementById('biometricStatus');

    const faceDetection = new FaceDetection({ locateFile: (file) => `https://cdn.jsdelivr.net/npm/@mediapipe/face_detection/${file}` });
    faceDetection.setOptions({ model: 'short', minDetectionConfidence: 0.7 });

    faceDetection.onResults((results) => {
        if (results.detections.length > 0) {
            if (!isFaceStable) {
                isFaceStable = true;
                faceTimer = 3;
                countdownOverlay.style.display = 'block';
                countdownOverlay.innerText = faceTimer;
                statusText.style.color = '#00ffff';
                statusText.innerText = "Wajah terdeteksi. Pertahankan posisi Anda...";

                faceInterval = setInterval(() => {
                    faceTimer--;
                    if (faceTimer > 0) countdownOverlay.innerText = faceTimer;
                    else { clearInterval(faceInterval); captureAndProceedToKTM(videoElement); }
                }, 1000);
            }
        } else {
            if (isFaceStable) {
                isFaceStable = false;
                clearInterval(faceInterval);
                countdownOverlay.style.display = 'none';
                statusText.style.color = '#ff3333';
                statusText.innerText = "Wajah hilang/tidak terdeteksi. Proses diulang...";
            } else {
                statusText.innerText = "Silakan arahkan wajah Anda ke kamera...";
                statusText.style.color = '#ff3333';
            }
        }
    });

    cameraInstance = new Camera(videoElement, { onFrame: async () => { await faceDetection.send({ image: videoElement }); }, width: 640, height: 480 });
    cameraInstance.start();
}

function captureAndProceedToKTM(videoElement) {
    const statusText = document.getElementById('biometricStatus');
    statusText.style.color = '#00ff00';
    statusText.innerText = "Verifikasi wajah berhasil. Menyimpan data...";
    
    const canvas = document.createElement('canvas');
    canvas.width = videoElement.videoWidth; canvas.height = videoElement.videoHeight;
    const ctx = canvas.getContext('2d');
    ctx.translate(canvas.width, 0); ctx.scale(-1, 1);
    ctx.drawImage(videoElement, 0, 0, canvas.width, canvas.height);
    capturedBiometricBase64 = canvas.toDataURL('image/jpeg', 0.8);

    setTimeout(() => {
        if(cameraInstance) cameraInstance.stop();
        document.getElementById('biometricScreen').classList.remove('active');
        setTimeout(() => { document.getElementById('ktmScreen').classList.add('active'); initKtmScan(); }, 500);
    }, 1000);
}

// ==========================================
// 2. FUNGSI BIOMETRIK KTM (INSTAN CAPTURE)
// ==========================================
async function initKtmScan() {
    const videoElement = document.getElementById('ktmWebcam');
    const statusText = document.getElementById('ktmStatus');
    
    try {
        ktmStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: "environment" }, width: { ideal: 1280 }, height: { ideal: 720 } } });
        videoElement.srcObject = ktmStream;
    } catch (err) { statusText.style.color = '#ff3333'; statusText.innerText = "Gagal mengakses kamera belakang."; return; }

    const processCanvas = document.createElement('canvas');
    const processCtx = processCanvas.getContext('2d', { willReadFrequently: true });

    let nameKeywords = [];
    if (currentUserGoogleName) {
        let rawNamePart = currentUserGoogleName;
        if (currentUserGoogleName.includes('/')) {
            const parts = currentUserGoogleName.split('/');
            rawNamePart = parts[parts.length - 1]; 
        }
        nameKeywords = rawNamePart.toLowerCase().replace(/[^a-z ]/g, '').split(' ').filter(w => w.length > 2);
    }

    console.log(`[arOS-AI] Target Pencarian -> NPM: ${extractedNpmNumber}, Nama:`, nameKeywords);
    statusText.style.color = '#00ffff';
    statusText.innerText = "Sistem OCR aktif. Arahkan KTM ke kamera...";

    const scanLoop = async () => {
        if (!document.getElementById('ktmScreen').classList.contains('active')) return;
        if (isOcrProcessing) { requestAnimationFrame(scanLoop); return; }

        if (videoElement.readyState === videoElement.HAVE_ENOUGH_DATA) {
            processCanvas.width = videoElement.videoWidth; processCanvas.height = videoElement.videoHeight;
            processCtx.drawImage(videoElement, 0, 0, processCanvas.width, processCanvas.height);
            isOcrProcessing = true;

            try {
                const { data: { text } } = await tesseractWorker.recognize(processCanvas);
                isOcrProcessing = false;
                const textCleanNoSpace = text.toLowerCase().replace(/[^a-z0-9]/g, '');

                const foundLogo = textCleanNoSpace.includes("utama") || textCleanNoSpace.includes("widyatama");
                const foundNpm = extractedNpmNumber !== "" && textCleanNoSpace.includes(extractedNpmNumber);
                let foundName = nameKeywords.length > 0 ? nameKeywords.some(word => textCleanNoSpace.includes(word)) : true;

                if (foundLogo && foundName && foundNpm) {
                    if (!isKtmStable) {
                        isKtmStable = true;
                        statusText.style.color = '#00ff00';
                        statusText.innerText = "Semua data cocok! Mengambil foto...";
                        captureKtmAndProceed(videoElement);
                    }
                } else {
                    if (!isKtmStable) {
                        let missing = [];
                        if (!foundLogo) missing.push("Logo Kampus");
                        if (!foundName) missing.push("Nama");
                        if (!foundNpm) missing.push("NPM");
                        statusText.style.color = '#ff3333';
                        statusText.innerText = `Belum terbaca: ${missing.join(", ")}`;
                    }
                }
            } catch (err) { isOcrProcessing = false; }
        }
        setTimeout(() => requestAnimationFrame(scanLoop), 300);
    };
    scanLoop();
}

function captureKtmAndProceed(videoElement) {
    const statusText = document.getElementById('ktmStatus');
    statusText.style.color = '#00ff00';
    statusText.innerText = "Foto KTM Berhasil Diambil.";

    const canvas = document.createElement('canvas');
    canvas.width = videoElement.videoWidth; canvas.height = videoElement.videoHeight;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(videoElement, 0, 0, canvas.width, canvas.height);
    capturedKtmBase64 = canvas.toDataURL('image/jpeg', 0.8);

    if (ktmStream) ktmStream.getTracks().forEach(track => track.stop());

    setTimeout(() => {
        document.getElementById('ktmScreen').classList.remove('active');
        setTimeout(() => { document.getElementById('rulesScreen').classList.add('active'); }, 500);
    }, 1000);
}

// ==========================================
// FUNGSI ANIMASI PARTIKEL
// ==========================================
function splitTextToParticles(elementId, baseDelay) {
    const el = document.getElementById(elementId);
    if (!el) return;
    const text = el.innerText;
    el.innerText = ''; 
    for (let i = 0; i < text.length; i++) {
        let span = document.createElement('span');
        span.className = 'letter-particle';
        if (text[i] === ' ') { span.innerHTML = '&nbsp;'; span.classList.add('space-char'); } 
        else { span.innerHTML = text[i]; }
        let rx = (Math.random() - 0.5) * 2000; let ry = (Math.random() - 0.5) * 2000; let rz = (Math.random() - 0.5) * 2000;
        span.style.setProperty('--rx', rx); span.style.setProperty('--ry', ry); span.style.setProperty('--rz', rz);
        if (elementId === 'introTitle') {
            if (i === 0 || i === 1 || i === 12 || i === 13) { span.style.setProperty('--target-color', '#00ffff'); span.style.setProperty('--target-shadow', '0 0 15px #00ffff, 0 0 30px #00ffff'); } 
            else { span.style.setProperty('--target-color', '#ffffff'); span.style.setProperty('--target-shadow', '0 0 8px rgba(255, 255, 255, 0.6)'); }
        } else if (elementId === 'introSubtitle') { span.style.setProperty('--target-color', '#00ffff'); span.style.setProperty('--target-shadow', 'none'); }
        span.style.animation = `assembleLetter 6s cubic-bezier(0.25, 1, 0.3, 1) ${baseDelay + (i * 0.04)}s forwards`;
        el.appendChild(span);
    }
}

function generateParticles() {
    const wrap = document.getElementById('particle-container');
    if (!wrap) return;
    const canvas = document.createElement('canvas'); const ctx = canvas.getContext('2d');
    canvas.width = 700; canvas.height = 300; ctx.fillStyle = "white"; ctx.font = "bold 160px 'Varela Round', sans-serif";
    ctx.textAlign = "center"; ctx.textBaseline = "middle"; ctx.fillText("arOS", canvas.width / 2, canvas.height / 2);
    const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height).data; const step = 6; 
    for (let y = 0; y < canvas.height; y += step) {
        for (let x = 0; x < canvas.width; x += step) {
            if (imgData[(y * canvas.width + x) * 4 + 3] > 128) {
                let div = document.createElement('div'); div.className = 'c';
                div.style.backgroundColor = '#ffffff'; div.style.boxShadow = '0 0 8px #ffffff';
                div.style.setProperty('--tx', `${x - (canvas.width / 2)}px`); div.style.setProperty('--ty', `${y - (canvas.height / 2)}px`);
                div.style.setProperty('--sx', `${(Math.random() - 0.5) * 3000}px`); div.style.setProperty('--sy', `${(Math.random() - 0.5) * 3000}px`); div.style.setProperty('--sz', `${(Math.random() - 0.5) * 3000}px`);
                div.style.animationDelay = `${Math.random() * 1.5}s`; wrap.appendChild(div);
            }
        }
    }
}

document.addEventListener("DOMContentLoaded", () => {
    generateParticles();
    
    const particleContainer = document.getElementById('particle-container');
    const introTextContainer = document.getElementById('introTextContainer');

    const introScreen = document.getElementById('introScreen');
    const disclaimerScreen = document.getElementById('disclaimerScreen'); 
    const loginScreen = document.getElementById('loginScreen');
    const rulesScreen = document.getElementById('rulesScreen');
    const choiceScreen = document.getElementById('choiceScreen'); // Layar Pilihan Baru
    const guiScreen = document.getElementById('guiScreen');       // Layar GUI Baru
    const mainScreen = document.getElementById('mainScreen');     // CLI
    const resultScreen = document.getElementById('resultScreen');

    setTimeout(() => { if (particleContainer) { particleContainer.classList.add('destroy-particles'); setTimeout(() => particleContainer.remove(), 2000); } }, 4000); 
    setTimeout(() => { if (introTextContainer) { introTextContainer.style.display = 'block'; introTextContainer.style.opacity = '1'; } splitTextToParticles('introTitle', 0); splitTextToParticles('introSubtitle', 0.3); }, 4500); 
    setTimeout(() => { if (introTextContainer) introTextContainer.style.display = 'none'; introScreen.classList.remove('active'); setTimeout(() => { disclaimerScreen.classList.add('active'); }, 500); }, 12500); 

    if (document.getElementById('btn-agree-disclaimer')) {
        document.getElementById('btn-agree-disclaimer').addEventListener('click', () => {
            disclaimerScreen.classList.remove('active');
            setTimeout(() => { loginScreen.classList.add('active'); }, 500);
        });
    }

    // Pindah ke Menu Pilihan (Choice Screen) setelah baca Rules
    document.getElementById('btn-understand').addEventListener('click', () => {
        rulesScreen.classList.remove('active');
        setTimeout(() => { choiceScreen.classList.add('active'); }, 500);
    });

    // Pilihan Mode CLI
    document.getElementById('btn-mode-cli').addEventListener('click', () => {
        choiceScreen.classList.remove('active');
        setTimeout(() => { mainScreen.classList.add('active'); initCLI(); document.getElementById('cli-input').focus(); }, 500);
    });

    // Pilihan Mode GUI
    document.getElementById('btn-mode-gui').addEventListener('click', () => {
        choiceScreen.classList.remove('active');
        
        // Auto-fill data identitas di GUI
        let rawName = currentUserGoogleName;
        if(rawName.includes('/')) rawName = rawName.split('/').pop().trim();
        
        document.getElementById('gui-nama').value = rawName;
        document.getElementById('gui-npm').value = extractedNpmNumber;
        document.getElementById('gui-email').value = currentUserGoogleEmail;

        setTimeout(() => { guiScreen.classList.add('active'); }, 500);
    });

    // Toggle Input Alat di GUI
    document.getElementById('gui-cat-kunci').addEventListener('change', function() {
        document.getElementById('gui-alat-group').style.display = this.checked ? 'block' : 'none';
        if(!this.checked) document.getElementById('gui-alat').value = ""; // Bersihkan jika uncheck
    });

    // Handler Submit Formulir GUI
    document.getElementById('btn-submit-gui').addEventListener('click', async () => {
        const formValid = document.getElementById('gui-form').checkValidity();
        if (!formValid) {
            document.getElementById('gui-form').reportValidity();
            return;
        }

        const btnSubmit = document.getElementById('btn-submit-gui');
        const statusLoad = document.getElementById('gui-loading-status');
        btnSubmit.style.pointerEvents = 'none'; btnSubmit.style.opacity = '0.5';
        statusLoad.style.display = 'block';

        // Susun Kategori
        let katArr = [];
        if(document.getElementById('gui-cat-lab').checked) katArr.push("Lab");
        if(document.getElementById('gui-cat-kunci').checked) katArr.push("Kunci");

        const payload = {
            nama: document.getElementById('gui-nama').value,
            npm: document.getElementById('gui-npm').value,
            email: document.getElementById('gui-email').value,
            angkatan: document.getElementById('gui-angkatan').value,
            tujuan: document.getElementById('gui-tujuan').value,
            alat: document.getElementById('gui-alat').value,
            tanggal: document.getElementById('gui-tanggal').value,
            jam_mulai: document.getElementById('gui-jam-mulai').value,
            jam_selesai: document.getElementById('gui-jam-selesai').value,
            kategori: katArr,
            googleName: currentUserGoogleName,
            imageBase64: capturedBiometricBase64,
            ktmBase64: capturedKtmBase64
        };

        try {
            const response = await fetch(guiBackendUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });
            const resultData = await response.json();
            
            if (resultData.is_booking) {
                guiScreen.classList.remove('active');
                setTimeout(() => showResultBox(resultData), 500);
            } else {
                alert("Pengajuan Ditolak: \n" + resultData.ai_response);
                btnSubmit.style.pointerEvents = 'auto'; btnSubmit.style.opacity = '1';
                statusLoad.style.display = 'none';
            }
        } catch (err) {
            alert("Terjadi kesalahan jaringan.");
            btnSubmit.style.pointerEvents = 'auto'; btnSubmit.style.opacity = '1';
            statusLoad.style.display = 'none';
        }
    });

    // ----------------------------------------------------
    // FUNGSI CLI MODE LAMA (TETAP DIPERTAHANKAN)
    // ----------------------------------------------------
    const cliOutput = document.getElementById('cli-output');
    const cliInput = document.getElementById('cli-input');
    
    function printLine(text, className = '') {
        const p = document.createElement('p'); p.textContent = text; p.className = className || 'log-system'; 
        cliOutput.appendChild(p); cliOutput.scrollTop = cliOutput.scrollHeight;
    }

    function initCLI() {
        printLine("[arOS-AI] TERHUBUNG KE EKOSISTEM ARCHUSKHA (arOS-core-0.0.1)", "log-user");
        setTimeout(() => { printLine("[arOS-AI]: Halo! Silakan ajukan peminjaman dengan menyebutkan nama, NPM, email, angkatan, tujuan, jam peminjaman, serta kategorinya.", "log-system"); }, 800);
    }

    function showResultBox(data) {
        document.getElementById('mainScreen').classList.remove('active'); // Pastikan CLI ditutup jika aktif
        
        setTimeout(() => { resultScreen.classList.add('active'); }, 500);

        document.getElementById('res-jenis').textContent = data.kategori ? data.kategori.join(' & ') : '-';
        document.getElementById('res-nama').textContent = data.nama || '-';
        document.getElementById('res-npm').textContent = data.npm || '-';
        document.getElementById('res-email').textContent = data.email || '-';
        document.getElementById('res-angkatan').textContent = data.angkatan || '-';
        document.getElementById('res-tujuan').textContent = data.tujuan || '-';
        document.getElementById('res-tanggal').textContent = data.tanggal || '-';
        document.getElementById('res-jam').textContent = `${data.jam_mulai || '-'} - ${data.jam_selesai || '-'}`;

        const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit' };
        document.getElementById('res-timestamp').textContent = `Dikirim pada: ${new Date().toLocaleDateString('id-ID', options)}`;
    }

    cliInput.addEventListener('keydown', async function(e) {
        if (e.key === 'Enter') {
            const val = this.value.trim();
            if (!val) return;

            printLine(`User > ${val}`, "log-user"); this.value = ''; cliInput.disabled = true;

            const loadingMsg = document.createElement('p'); loadingMsg.textContent = "[arOS-AI] Sistem sedang memproses, harap tunggu...";
            loadingMsg.className = "log-system"; cliOutput.appendChild(loadingMsg); cliOutput.scrollTop = cliOutput.scrollHeight;

            try {
                const response = await fetch(backendUrl, {
                    method: 'POST', headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ message: val, googleName: currentUserGoogleName, imageBase64: capturedBiometricBase64, ktmBase64: capturedKtmBase64 })
                });
                
                const resultData = await response.json();
                loadingMsg.remove(); printLine(`[arOS-AI]: ${resultData.ai_response}`, "log-system");
                if (resultData.is_booking) setTimeout(() => showResultBox(resultData), 2000); 

            } catch (err) { loadingMsg.remove(); printLine(`[ERROR] ${err.message}`, "log-error"); }
            
            cliInput.disabled = false; cliInput.focus();
        }
    });

    document.getElementById('btn-selesai').addEventListener('click', () => { location.reload(); });
});