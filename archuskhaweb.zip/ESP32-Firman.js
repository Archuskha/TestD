const projectTokenKey = 'esp32ProjectToken';
const telemetryUrl = '/api-esp32/telemetry?deviceId=ESP32-Firman';
const validateUrl = '/api-esp32/auth/validate';
const logoutUrl = '/api-esp32/auth/logout';
const controlUrl = '/api-esp32/control';
const controlStatusUrl = '/api-esp32/control/status';
const pollIntervalMs = 2000;
const commandPollIntervalMs = 500;
const commandClientTimeoutMs = 10000;
const relayNumbers = [1, 2, 3, 4, 5, 7];

let projectToken = sessionStorage.getItem(projectTokenKey) || '';
let pollTimer = null;
let deviceOnline = false;
let deviceOverload = false;
let commandInFlight = false;

function redirectToGateway() {
    sessionStorage.removeItem(projectTokenKey);
    window.location.replace('archuskhaweb.html');
}

async function authorizedFetch(url, options = {}) {
    const headers = new Headers(options.headers || {});
    headers.set('Authorization', `Bearer ${projectToken}`);
    const response = await fetch(url, { ...options, headers });
    if (response.status === 401 || response.status === 403) {
        redirectToGateway();
        throw new Error('Sesi project telah berakhir.');
    }
    return response;
}

function formatMetric(value, digits) {
    return Number.isFinite(value) ? Number(value).toFixed(digits) : '--';
}

function setText(id, value) {
    document.getElementById(id).textContent = value;
}

function renderOffline(lastUpdate = null) {
    if (deviceOnline) console.warn('[ESP32 UI] Device OFFLINE');
    deviceOnline = false;
    deviceOverload = false;
    const banner = document.getElementById('connection-banner');
    banner.classList.remove('online');
    banner.classList.add('offline');
    setText('connection-title', 'ESP32 OFFLINE');
    setText('connection-copy', 'Backend tidak menerima telemetry perangkat dalam 10 detik terakhir.');
    setText('device-status', 'OFFLINE');
    document.getElementById('device-status').classList.remove('online');
    ['voltage', 'current', 'power', 'energy', 'frequency', 'power-factor'].forEach(metric => setText(`metric-${metric}`, '--'));
    setText('last-update', lastUpdate ? new Date(lastUpdate).toLocaleString('id-ID') : '--');
    setText('pir-mode', '--');
    setText('pir-detected', '--');
    setText('light-mode', '--');
    setText('power-limit', '-- W');
    setText('overload-status', '--');
    renderRelays(null);
    updateControlAvailability();
}

function renderTelemetry(payload) {
    const telemetry = payload.telemetry;
    if (!payload.online || !telemetry) {
        renderOffline(payload.lastUpdate);
        return;
    }

    const wasOnline = deviceOnline;
    deviceOnline = true;
    deviceOverload = Boolean(telemetry.overload);
    if (!wasOnline) console.info('[ESP32 UI] Device ONLINE');
    const banner = document.getElementById('connection-banner');
    banner.classList.add('online');
    banner.classList.remove('offline');
    setText('connection-title', 'ESP32 ONLINE');
    setText('connection-copy', 'Telemetry aktual diterima dari perangkat melalui backend Archuskha.');
    const deviceStatus = document.getElementById('device-status');
    deviceStatus.textContent = 'ONLINE';
    deviceStatus.classList.add('online');

    setText('metric-voltage', formatMetric(telemetry.voltage, 1));
    setText('metric-current', formatMetric(telemetry.current, 2));
    setText('metric-power', formatMetric(telemetry.power, 1));
    setText('metric-energy', formatMetric(telemetry.energy, 3));
    setText('metric-frequency', formatMetric(telemetry.frequency, 1));
    setText('metric-power-factor', formatMetric(telemetry.powerFactor, 2));
    setText('device-id', telemetry.deviceId || payload.deviceId || 'ESP32-Firman');
    setText('last-update', new Date(payload.lastUpdate).toLocaleString('id-ID'));
    setText('pir-mode', telemetry.pirMode || '--');
    setText('pir-detected', telemetry.pirDetected ? 'TERDETEKSI' : 'TIDAK TERDETEKSI');
    setText('light-mode', telemetry.lightMode || '--');
    setText('power-limit', `${telemetry.powerLimit ?? '--'} W`);
    document.getElementById('power-limit-input').value = telemetry.powerLimit ?? '';
    setText('overload-status', telemetry.overload ? 'OVERLOAD' : 'NORMAL');
    renderRelays(telemetry);
    updateControlAvailability();
}

function renderRelays(telemetry) {
    relayNumbers.forEach(relay => {
        const row = document.querySelector(`[data-relay-row="${relay}"]`);
        if (row.classList.contains('pending')) return;
        const stateElement = row.querySelector('.relay-state');
        const state = telemetry ? Boolean(telemetry[`relay${relay}`]) : null;
        stateElement.textContent = state === null ? '--' : (state ? 'ON' : 'OFF');
        stateElement.classList.toggle('on', state === true);
    });
}

function updateControlAvailability() {
    document.querySelectorAll('.relay-actions button').forEach(button => {
        const requestsOn = button.dataset.state === 'true';
        button.disabled = commandInFlight || !deviceOnline || (deviceOverload && requestsOn);
    });
    document.getElementById('power-limit-input').disabled = commandInFlight || !deviceOnline;
    document.querySelector('#limit-control-form button').disabled = commandInFlight || !deviceOnline;
}

async function fetchTelemetry() {
    try {
        console.debug('[ESP32 UI] Fetching telemetry');
        const response = await authorizedFetch(telemetryUrl);
        if (!response.ok) throw new Error(`Backend merespons HTTP ${response.status}.`);
        const payload = await response.json();
        console.debug(`[ESP32 UI] Telemetry received; online=${Boolean(payload.online)}`);
        renderTelemetry(payload);
    } catch (error) {
        console.error('[ESP32 UI] Telemetry request failed', error.message || error);
        if (projectToken) {
            renderOffline();
            setText('connection-copy', error.message || 'Backend tidak dapat dihubungi.');
        }
    }
}

function sleep(ms) {
    return new Promise(resolve => window.setTimeout(resolve, ms));
}

function setControlMessage(text, isError = false) {
    const message = document.getElementById('control-message');
    message.classList.toggle('error', isError);
    message.textContent = text;
}

function setRelayPending(relay, state) {
    if (!relay) return;
    const row = document.querySelector(`[data-relay-row="${relay}"]`);
    row.classList.remove('failed', 'confirmed');
    row.classList.add('pending');
    row.querySelector('.relay-state').textContent = `PENDING ${state ? 'ON' : 'OFF'}`;
}

function finishRelayVisual(relay, status, actualState = null) {
    if (!relay) return;
    const row = document.querySelector(`[data-relay-row="${relay}"]`);
    const stateElement = row.querySelector('.relay-state');
    row.classList.remove('pending', 'failed', 'confirmed');
    if (status === 'COMPLETED') {
        row.classList.add('confirmed');
        if (actualState !== null) {
            stateElement.textContent = actualState ? 'ON' : 'OFF';
            stateElement.classList.toggle('on', actualState);
        }
    } else {
        row.classList.add('failed');
    }
    window.setTimeout(() => row.classList.remove('confirmed', 'failed'), 2500);
}

async function waitForCommand(command, description) {
    const deadline = Date.now() + commandClientTimeoutMs;
    const query = `?deviceId=${encodeURIComponent(command.deviceId)}&commandId=${encodeURIComponent(command.commandId)}`;
    console.info(`[ESP32 UI][CONTROL] Waiting ESP32 acknowledgement ID=${command.commandId}`);

    while (Date.now() < deadline) {
        const response = await authorizedFetch(`${controlStatusUrl}${query}`);
        const result = await response.json();
        if (!response.ok || !result.success) throw new Error(result.message || result.error || `HTTP ${response.status}`);

        const tracked = result.command;
        if (tracked.status === 'COMPLETED') {
            console.info(`[ESP32 UI][CONTROL] Command completed ID=${tracked.commandId}`);
            setControlMessage(`${description} CONFIRMED oleh ESP32.`);
            finishRelayVisual(tracked.relay, tracked.status, tracked.actualState ?? tracked.state ?? null);
            return tracked;
        }
        if (tracked.status === 'FAILED') {
            const reason = tracked.error || tracked.message || 'DEVICE_REJECTED';
            throw new Error(`${description} ditolak ESP32: ${reason}`);
        }
        if (tracked.status === 'TIMEOUT') {
            throw new Error('Command timeout - ESP32 tidak merespons.');
        }
        await sleep(commandPollIntervalMs);
    }

    throw new Error('Command timeout - status backend tidak selesai.');
}

async function submitControl(payload, description) {
    if (!deviceOnline) {
        setControlMessage('ESP32 OFFLINE. Control unavailable.', true);
        return;
    }

    commandInFlight = true;
    updateControlAvailability();
    setRelayPending(payload.relay, payload.state);
    setControlMessage(`${description} PENDING...`);
    console.info(`[ESP32 UI][CONTROL] ${description}`);
    console.info('[ESP32 UI][CONTROL] Sending command...');

    try {
        const response = await authorizedFetch(controlUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ deviceId: 'ESP32-Firman', ...payload })
        });
        const result = await response.json();
        if (!response.ok || !result.success) throw new Error(result.message || result.error || `HTTP ${response.status}`);
        if (!result.command?.commandId) throw new Error('Backend tidak mengembalikan commandId.');
        console.info(`[ESP32 UI][CONTROL] Backend accepted command ID=${result.command.commandId}`);
        console.info(`[ESP32 UI][CONTROL] PENDING ID=${result.command.commandId}`);
        await waitForCommand(result.command, description);
        console.info(`[ESP32 UI][CONTROL] CONFIRMED ID=${result.command.commandId} ${description}`);
    } catch (error) {
        const errorMessage = error.message || String(error);
        if (errorMessage.startsWith('Command timeout')) console.error('[ESP32 UI][CONTROL] TIMEOUT', errorMessage);
        else console.error('[ESP32 UI][CONTROL] Command failed', errorMessage);
        finishRelayVisual(payload.relay, 'FAILED');
        setControlMessage(errorMessage || 'Command gagal dikirim.', true);
    } finally {
        commandInFlight = false;
        updateControlAvailability();
        await fetchTelemetry();
    }
}

async function sendRelayCommand(relay, state) {
    await submitControl({ relay, state }, `Relay ${relay} -> ${state ? 'ON' : 'OFF'}`);
}

async function sendPowerLimit(powerLimit) {
    await submitControl({ powerLimit }, `Power limit -> ${powerLimit} W`);
}

async function initializeDashboard() {
    if (!projectToken) {
        redirectToGateway();
        return;
    }

    try {
        const response = await authorizedFetch(validateUrl);
        if (!response.ok) throw new Error('Sesi project tidak valid.');
        await fetchTelemetry();
        pollTimer = window.setInterval(fetchTelemetry, pollIntervalMs);
    } catch {
        redirectToGateway();
    }
}

document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.relay-actions button').forEach(button => {
        button.addEventListener('click', () => sendRelayCommand(Number(button.dataset.relay), button.dataset.state === 'true'));
    });

    document.getElementById('limit-control-form').addEventListener('submit', event => {
        event.preventDefault();
        const input = document.getElementById('power-limit-input');
        if (!input.checkValidity()) {
            input.reportValidity();
            return;
        }
        sendPowerLimit(Number(input.value));
    });

    document.getElementById('logout-project').addEventListener('click', async () => {
        if (pollTimer) window.clearInterval(pollTimer);
        try { await authorizedFetch(logoutUrl, { method: 'POST' }); } catch { }
        redirectToGateway();
    });

    initializeDashboard();
});
