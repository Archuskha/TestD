import hashlib
import base64

class KuznyechikCipher:
    Pi = [
        0xFC, 0xEE, 0xDD, 0x11, 0xCF, 0x6E, 0x31, 0x16, 0xFB, 0xC4, 0xFA, 0xDA, 0x23, 0xC5, 0x04, 0x4D,
        0xE9, 0x77, 0xF0, 0xDB, 0x93, 0x2E, 0x99, 0xBD, 0x17, 0x32, 0xE5, 0x77, 0x09, 0xFE, 0xAA, 0x40,
        0xA3, 0x5F, 0xB6, 0xFD, 0x38, 0xD5, 0x63, 0x0C, 0xA9, 0x53, 0x2A, 0x3B, 0x2D, 0xA8, 0x3F, 0xB7,
        0x8D, 0x1D, 0xA4, 0x88, 0x08, 0x29, 0x36, 0x72, 0x4F, 0x71, 0x58, 0x4E, 0x91, 0xF2, 0x30, 0x54,
        0x9F, 0x4C, 0xA1, 0x61, 0x79, 0x28, 0xD1, 0x10, 0x07, 0x5B, 0xBC, 0x96, 0xEA, 0x89, 0x1B, 0x67,
        0x9B, 0x1E, 0x8E, 0x20, 0x80, 0xC0, 0x6B, 0x7B, 0x5C, 0x06, 0x35, 0xD7, 0x4B, 0x5D, 0x0E, 0x21,
        0xC1, 0x1A, 0x25, 0x62, 0x82, 0x02, 0xD4, 0xF6, 0x0F, 0x48, 0x42, 0xD3, 0x68, 0x94, 0xE0, 0x3D,
        0xC2, 0xD2, 0x66, 0x69, 0x0D, 0xC7, 0x2F, 0xC6, 0x1C, 0xAB, 0x52, 0x12, 0xDE, 0x6C, 0x26, 0x95,
        0x15, 0x44, 0x5A, 0xB0, 0xE7, 0x14, 0xD6, 0x8C, 0xCD, 0x22, 0x70, 0x51, 0x03, 0x9C, 0x92, 0x13,
        0x19, 0x05, 0x6D, 0x8F, 0xA0, 0x59, 0x60, 0x01, 0x18, 0x87, 0x46, 0x50, 0xBD, 0x41, 0x6F, 0x7C,
        0x76, 0x86, 0xB9, 0x64, 0xE4, 0x27, 0x98, 0x81, 0x7F, 0xE3, 0xE2, 0x56, 0xC8, 0xC3, 0xE6, 0x57,
        0x8B, 0x33, 0x85, 0x2B, 0xB5, 0x43, 0x55, 0x45, 0x75, 0x2C, 0x84, 0x8A, 0x65, 0x3A, 0x6A, 0x0A,
        0xB8, 0x39, 0x0B, 0x9A, 0x7D, 0xCC, 0x73, 0x00, 0x5E, 0x90, 0x7E, 0x4A, 0x74, 0xA6, 0x3E, 0x7A,
        0x97, 0x24, 0xB2, 0xA2, 0x47, 0xAC, 0x37, 0x83, 0x34, 0xB4, 0xDF, 0xF9, 0xBF, 0xF5, 0xEC, 0x5F,
        0x9E, 0xAF, 0xB1, 0x9D, 0xCE, 0xD0, 0xE1, 0xED, 0xEB, 0xEF, 0xA7, 0xAD, 0xCB, 0xF1, 0xF8, 0xF4,
        0xF3, 0xF7, 0xD8, 0xD9, 0xC9, 0xCA, 0xE8, 0xB3, 0x78, 0xFF, 0xA5, 0xFD, 0xBB, 0xDA, 0x49, 0x1F
    ]

    L_Vec = [148, 32, 133, 16, 194, 192, 1, 251, 1, 192, 194, 16, 133, 32, 148, 1]
    C_Const = []

    @staticmethod
    def _mul_gf(a, b):
        p = 0
        for i in range(8):
            if (b & 1) == 1:
                p ^= a
            hi_bit = a & 0x80
            a = (a << 1) & 0xFF
            if hi_bit != 0:
                a ^= 0xC3
            b >>= 1
        return p

    @classmethod
    def _generate_constants(cls):
        if cls.C_Const: return
        for i in range(32):
            block = bytearray(16)
            block[15] = i + 1
            cls.C_Const.append(cls._l_static(block))

    @classmethod
    def _l_static(cls, state):
        temp = bytearray(state)
        for j in range(16):
            r = 0
            for k in range(16):
                r ^= cls._mul_gf(temp[k], cls.L_Vec[k])
            for k in range(15, 0, -1):
                temp[k] = temp[k - 1]
            temp[0] = r
        return bytes(temp)

    def __init__(self, key):
        if len(key) != 32:
            raise ValueError("Kunci harus 32 bytes")
        self._generate_constants()
        self.RoundKeys = [bytearray(16) for _ in range(10)]
        self._expand_key(key)

    def _x(self, a, b):
        return bytes(x ^ y for x, y in zip(a, b))

    def _s(self, state):
        return bytes(self.Pi[b] for b in state)

    def _l(self, state):
        temp = bytearray(state)
        for j in range(16):
            r = 0
            for k in range(16):
                r ^= self._mul_gf(temp[k], self.L_Vec[k])
            for k in range(15, 0, -1):
                temp[k] = temp[k - 1]
            temp[0] = r
        return bytes(temp)

    def _lsx(self, state, key):
        return self._l(self._s(self._x(state, key)))

    def _expand_key(self, master_key):
        self.RoundKeys[0] = master_key[0:16]
        self.RoundKeys[1] = master_key[16:32]
        
        for i in range(4):
            k1 = self.RoundKeys[2 * i]
            k2 = self.RoundKeys[2 * i + 1]
            
            for j in range(8):
                temp = self._l(self._s(self._x(k1, self.C_Const[8 * i + j])))
                next_k = self._x(temp, k2)
                k2 = k1
                k1 = next_k
                
            self.RoundKeys[2 * i + 2] = k1
            self.RoundKeys[2 * i + 3] = k2

    def encrypt_block(self, input_block):
        state = input_block
        for i in range(9):
            state = self._lsx(state, self.RoundKeys[i])
        state = self._x(state, self.RoundKeys[9])
        return state

class ArchuskhaGOST:
    SALT = bytes([15, 20, 31, 43, 55, 63, 78, 87, 82, 92, 99, 15, 86, 23, 18, 52, 95, 55, 69])
    
    @staticmethod
    def increment_counter(counter):
        for i in range(16):
            counter[i] = (counter[i] + 1) & 0xFF
            if counter[i] != 0:
                break

    @staticmethod
    def process_ctr(input_data, key, iv):
        engine = KuznyechikCipher(key)
        output = bytearray(len(input_data))
        counter = bytearray(iv)
        
        input_offset = 0
        while input_offset < len(input_data):
            keystream = engine.encrypt_block(counter)
            block_size = min(16, len(input_data) - input_offset)
            
            for i in range(block_size):
                output[input_offset + i] = input_data[input_offset + i] ^ keystream[i]
                
            ArchuskhaGOST.increment_counter(counter)
            input_offset += 16
            
        return bytes(output)

    @staticmethod
    def dekripsi_pesan(base64_cipher, password):
        try:
            cipher_bytes = base64.b64decode(base64_cipher)
            
            # Cocokkan iterasi PBKDF2 dengan C# (2500 iterations)
            derived = hashlib.pbkdf2_hmac('sha1', password.encode('utf-8'), ArchuskhaGOST.SALT, 2500, 48)
            key = derived[0:32]
            iv = derived[32:48]
            
            decrypted_bytes = ArchuskhaGOST.process_ctr(cipher_bytes, key, iv)
            return decrypted_bytes.decode('utf-8')
        except Exception as e:
            return f"[GOST ERROR] Gagal Dekripsi: {e}"