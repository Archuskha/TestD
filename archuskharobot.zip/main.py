import socket
import time
import sys
import threading
from archuskha_gpio import setup_gpio, eksekusi_perintah, mulai_thread_sensor, bersihkan_gpio
from archuskha_gost import ArchuskhaGOST
from archuskha_camera import mulai_thread_kamera, hentikan_kamera

# ==========================================
# KONFIGURASI JARINGAN (VPS BRIDGE)
# ==========================================
BRIDGE_IP = "103.150.117.90"
BRIDGE_PORT = 6001
KUNCI_GOST = "Endministrator"

client_socket = None
is_running = True

def kirim_ke_server(pesan):
    """Fungsi ini akan dilempar ke modul GPIO agar sensor bisa mengirim data balik"""
    global client_socket
    if client_socket:
        try:
            client_socket.sendall((pesan + "\n").encode('utf-8'))
        except:
            pass

def thread_jaringan():
    global client_socket
    while is_running:
        try:
            print(f"[NET] Mencoba terhubung ke {BRIDGE_IP}:{BRIDGE_PORT}...")
            client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            client_socket.settimeout(10) 
            client_socket.connect((BRIDGE_IP, BRIDGE_PORT))
            client_socket.settimeout(None) 
            
            print("[NET] Berhasil terhubung ke Linux VPS Bridge!")
            client_socket.sendall(b"PI3_READY\n")

            while is_running:
                data = client_socket.recv(4096)
                if not data:
                    break 
                
                pesan = data.decode('utf-8').strip()
                if pesan:
                    if pesan.startswith("/ENC:"):
                        base64_cipher = pesan[5:].strip()
                        print("[NET] Menerima Perintah Terenkripsi (GOST). Memulai Dekripsi...")
                        
                        plain_text = ArchuskhaGOST.dekripsi_pesan(base64_cipher, KUNCI_GOST)
                        
                        if "[GOST ERROR]" not in plain_text:
                            eksekusi_perintah(plain_text)
                        else:
                            print(plain_text)
                    else:
                        eksekusi_perintah(pesan)
                        
        except Exception as e:
            print(f"[NET ERROR] {e}. Mengulang koneksi dalam 5 detik...")
            if client_socket:
                client_socket.close()
                client_socket = None
            time.sleep(5)

if __name__ == "__main__":
    print("=========================================================")
    print("=== ARCHUSKHA-AMR (NODE UTAMA RASPBERRY PI 3)         ===")
    print("=== Modul Kamera, Modular & Kriptografi GOST Aktif    ===")
    print("=========================================================")
    
    # 1. Mulai Perangkat Keras Mekanis
    setup_gpio(kirim_ke_server)
    mulai_thread_sensor()

    # 2. Mulai Streaming Kamera ke Web
    mulai_thread_kamera()

    # 3. Mulai Jaringan TCP Kontrol
    t_jaringan = threading.Thread(target=thread_jaringan, daemon=True)
    t_jaringan.start()

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n[SISTEM] Sinyal penghentian diterima. Mematikan sistem...")
        is_running = False
        if client_socket:
            client_socket.close()
        hentikan_kamera() # Matikan Kamera
        bersihkan_gpio()
        sys.exit(0)