import RPi.GPIO as GPIO
import threading
import time

# ==========================================
# KONFIGURASI PIN BCM RASPBERRY PI
# ==========================================
IN1 = 17
IN2 = 27
ENA = 12

IN3 = 5
IN4 = 6
ENB = 13

SENSOR_TENGAH = 23
SENSOR_KIRI = 24
SENSOR_KANAN = 25

pwm_a = None
pwm_b = None
is_running = True
jaringan_callback = None
last_obstacle_state = None
last_heartbeat = 0

def setup_gpio(callback_fungsi):
    global pwm_a, pwm_b, jaringan_callback
    jaringan_callback = callback_fungsi

    GPIO.setmode(GPIO.BCM)
    GPIO.setwarnings(False)

    motor_pins = [IN1, IN2, ENA, IN3, IN4, ENB]
    for pin in motor_pins:
        GPIO.setup(pin, GPIO.OUT)
        GPIO.output(pin, GPIO.LOW)

    pwm_a = GPIO.PWM(ENA, 1000)
    pwm_b = GPIO.PWM(ENB, 1000)
    pwm_a.start(0)
    pwm_b.start(0)

    sensor_pins = [SENSOR_TENGAH, SENSOR_KIRI, SENSOR_KANAN]
    for pin in sensor_pins:
        GPIO.setup(pin, GPIO.IN, pull_up_down=GPIO.PUD_UP)

def kendali_motor(arah, kecepatan=50):
    if arah == "maju":
        GPIO.output(IN1, GPIO.HIGH); GPIO.output(IN2, GPIO.LOW)
        GPIO.output(IN3, GPIO.HIGH); GPIO.output(IN4, GPIO.LOW)
        pwm_a.ChangeDutyCycle(kecepatan); pwm_b.ChangeDutyCycle(kecepatan)
    elif arah == "mundur":
        GPIO.output(IN1, GPIO.LOW); GPIO.output(IN2, GPIO.HIGH)
        GPIO.output(IN3, GPIO.LOW); GPIO.output(IN4, GPIO.HIGH)
        pwm_a.ChangeDutyCycle(kecepatan); pwm_b.ChangeDutyCycle(kecepatan)
    elif arah == "kiri":
        GPIO.output(IN1, GPIO.LOW); GPIO.output(IN2, GPIO.HIGH)
        GPIO.output(IN3, GPIO.HIGH); GPIO.output(IN4, GPIO.LOW)
        pwm_a.ChangeDutyCycle(kecepatan); pwm_b.ChangeDutyCycle(kecepatan)
    elif arah == "kanan":
        GPIO.output(IN1, GPIO.HIGH); GPIO.output(IN2, GPIO.LOW)
        GPIO.output(IN3, GPIO.LOW); GPIO.output(IN4, GPIO.HIGH)
        pwm_a.ChangeDutyCycle(kecepatan); pwm_b.ChangeDutyCycle(kecepatan)
    elif arah == "berhenti":
        GPIO.output(IN1, GPIO.LOW); GPIO.output(IN2, GPIO.LOW)
        GPIO.output(IN3, GPIO.LOW); GPIO.output(IN4, GPIO.LOW)
        pwm_a.ChangeDutyCycle(0); pwm_b.ChangeDutyCycle(0)

def eksekusi_perintah(perintah):
    print(f"[HARDWARE] Mengeksekusi: {perintah}")

    if "/maju" in perintah:
        kendali_motor("maju", 60)
    elif "/mundur" in perintah:
        kendali_motor("mundur", 60)
    elif "/kiri" in perintah:
        kendali_motor("kiri", 50)
    elif "/kanan" in perintah:
        kendali_motor("kanan", 50)
    elif "/berhenti" in perintah or "/stop" in perintah:
        kendali_motor("berhenti")

def kirim_telemetry(obstacle, pesan):
    if jaringan_callback:
        status = "OBSTACLE" if obstacle else "AMAN"
        jaringan_callback(f'[ROBOT_TELEMETRY] {{"status":"{status}","obstacle":{str(obstacle).lower()},"message":"{pesan}"}}')

def _loop_pemantauan_sensor():
    global last_obstacle_state, last_heartbeat

    while is_running:
        tengah_nabrak = (GPIO.input(SENSOR_TENGAH) == GPIO.LOW)
        kiri_nabrak = (GPIO.input(SENSOR_KIRI) == GPIO.LOW)
        kanan_nabrak = (GPIO.input(SENSOR_KANAN) == GPIO.LOW)
        obstacle = tengah_nabrak or kiri_nabrak or kanan_nabrak
        now = time.time()

        if obstacle:
            kendali_motor("berhenti")
            peringatan = "Rintangan terdeteksi! Sistem pengereman aktif."
            print(f"[HARDWARE REPORT] {peringatan}")

            if last_obstacle_state is not True or now - last_heartbeat >= 1:
                kirim_telemetry(True, peringatan)
                last_heartbeat = now
        else:
            if last_obstacle_state is not False or now - last_heartbeat >= 2:
                kirim_telemetry(False, "Aman")
                last_heartbeat = now

        last_obstacle_state = obstacle
        time.sleep(0.05)

def mulai_thread_sensor():
    t_sensor = threading.Thread(target=_loop_pemantauan_sensor, daemon=True)
    t_sensor.start()

def bersihkan_gpio():
    global is_running
    is_running = False
    kendali_motor("berhenti")
    GPIO.cleanup()
