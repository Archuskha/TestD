import RPi.GPIO as GPIO
import threading
import time

# ==========================================
# KONFIGURASI PIN BCM RASPBERRY PI
# ==========================================
IN1 = 17
IN2 = 27
ENA = 12

IN3 = 5
IN4 = 6
ENB = 13

SENSOR_TENGAH = 23
SENSOR_KIRI = 24
SENSOR_KANAN = 25

pwm_a = None
pwm_b = None
is_running = True
jaringan_callback = None # Fungsi untuk mengirim data ke server utama

def setup_gpio(callback_fungsi):
    global pwm_a, pwm_b, jaringan_callback
    jaringan_callback = callback_fungsi
    
    GPIO.setmode(GPIO.BCM)
    GPIO.setwarnings(False)

    motor_pins = [IN1, IN2, ENA, IN3, IN4, ENB]
    for pin in motor_pins:
        GPIO.setup(pin, GPIO.OUT)
        GPIO.output(pin, GPIO.LOW)

    pwm_a = GPIO.PWM(ENA, 1000)
    pwm_b = GPIO.PWM(ENB, 1000)
    pwm_a.start(0)
    pwm_b.start(0)

    sensor_pins = [SENSOR_TENGAH, SENSOR_KIRI, SENSOR_KANAN]
    for pin in sensor_pins:
        GPIO.setup(pin, GPIO.IN, pull_up_down=GPIO.PUD_UP)

def kendali_motor(arah, kecepatan=50):
    if arah == "maju":
        GPIO.output(IN1, GPIO.HIGH); GPIO.output(IN2, GPIO.LOW)
        GPIO.output(IN3, GPIO.HIGH); GPIO.output(IN4, GPIO.LOW)
        pwm_a.ChangeDutyCycle(kecepatan); pwm_b.ChangeDutyCycle(kecepatan)
    elif arah == "mundur":
        GPIO.output(IN1, GPIO.LOW); GPIO.output(IN2, GPIO.HIGH)
        GPIO.output(IN3, GPIO.LOW); GPIO.output(IN4, GPIO.HIGH)
        pwm_a.ChangeDutyCycle(kecepatan); pwm_b.ChangeDutyCycle(kecepatan)
    elif arah == "kiri":
        GPIO.output(IN1, GPIO.LOW); GPIO.output(IN2, GPIO.HIGH)
        GPIO.output(IN3, GPIO.HIGH); GPIO.output(IN4, GPIO.LOW)
        pwm_a.ChangeDutyCycle(kecepatan); pwm_b.ChangeDutyCycle(kecepatan)
    elif arah == "kanan":
        GPIO.output(IN1, GPIO.HIGH); GPIO.output(IN2, GPIO.LOW)
        GPIO.output(IN3, GPIO.LOW); GPIO.output(IN4, GPIO.HIGH)
        pwm_a.ChangeDutyCycle(kecepatan); pwm_b.ChangeDutyCycle(kecepatan)
    elif arah == "berhenti":
        GPIO.output(IN1, GPIO.LOW); GPIO.output(IN2, GPIO.LOW)
        GPIO.output(IN3, GPIO.LOW); GPIO.output(IN4, GPIO.LOW)
        pwm_a.ChangeDutyCycle(0); pwm_b.ChangeDutyCycle(0)

def eksekusi_perintah(perintah):
    print(f"[HARDWARE] Mengeksekusi: {perintah}")
    
    if "/maju" in perintah:
        kendali_motor("maju", 60)
    elif "/mundur" in perintah:
        kendali_motor("mundur", 60)
    elif "/kiri" in perintah:
        kendali_motor("kiri", 50)
    elif "/kanan" in perintah:
        kendali_motor("kanan", 50)
    elif "/berhenti" in perintah or "/stop" in perintah:
        kendali_motor("berhenti")

def _loop_pemantauan_sensor():
    while is_running:
        tengah_nabrak = (GPIO.input(SENSOR_TENGAH) == GPIO.LOW)
        kiri_nabrak = (GPIO.input(SENSOR_KIRI) == GPIO.LOW)
        kanan_nabrak = (GPIO.input(SENSOR_KANAN) == GPIO.LOW)

        if tengah_nabrak or kiri_nabrak or kanan_nabrak:
            kendali_motor("berhenti")
            peringatan = "[HARDWARE REPORT] Rintangan terdeteksi! Sistem pengereman aktif."
            print(peringatan)
            
            if jaringan_callback:
                jaringan_callback(peringatan)
            
            time.sleep(1) # Delay anti-spam jaringan
        
        time.sleep(0.05)

def mulai_thread_sensor():
    t_sensor = threading.Thread(target=_loop_pemantauan_sensor, daemon=True)
    t_sensor.start()

def bersihkan_gpio():
    global is_running
    is_running = False
    kendali_motor("berhenti")
    GPIO.cleanup()