import cv2
import socket
import struct
import time
import threading

try:
    from picamera2 import Picamera2
except Exception as e:
    Picamera2 = None
    PICAMERA2_IMPORT_ERROR = e
else:
    PICAMERA2_IMPORT_ERROR = None

BACKEND_HOST = "103.150.117.90"
BACKEND_VIDEO_PORT = 6002
is_streaming = True

def _konversi_ke_bgr(frame, format_name=""):
    if frame is None:
        raise ValueError("Frame kamera kosong.")

    if len(frame.shape) == 2:
        return cv2.cvtColor(frame, cv2.COLOR_GRAY2BGR)

    if len(frame.shape) != 3:
        raise ValueError(f"Format frame tidak dikenal: shape={frame.shape}")

    channels = frame.shape[2]

    if channels == 3:
        fmt = (format_name or "").upper()
        if "RGB" in fmt and "BGR" not in fmt:
            return cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)
        return frame

    if channels == 4:
        fmt = (format_name or "").upper()
        if "BGRA" in fmt or "XBGR" in fmt:
            return cv2.cvtColor(frame, cv2.COLOR_BGRA2BGR)
        return cv2.cvtColor(frame, cv2.COLOR_RGBA2BGR)

    raise ValueError(f"Jumlah channel frame tidak didukung: {channels}")

def _buat_kamera():
    if Picamera2 is None:
        raise RuntimeError(f"Picamera2 gagal diimport: {PICAMERA2_IMPORT_ERROR}")

    picam2 = Picamera2()
    config = picam2.create_video_configuration(
        main={"size": (640, 480), "format": "RGB888"},
        controls={"FrameRate": 12}
    )
    picam2.configure(config)
    picam2.start()
    time.sleep(1)
    return picam2

def _loop_kamera():
    picam2 = None
    format_name = "RGB888"

    try:
        print("[KAMERA] Menginisialisasi Picamera2 untuk Raspberry Pi Camera Module 3 / IMX708...")
        picam2 = _buat_kamera()
        try:
            camera_config = picam2.camera_configuration()
            format_name = camera_config.get("main", {}).get("format", format_name)
        except Exception:
            pass
        print(f"[KAMERA] Picamera2 aktif. Format frame: {format_name}")
    except Exception as e:
        print(f"[KAMERA FATAL] Picamera2 gagal start: {e}")
        return

    while is_streaming:
        client_socket = None
        try:
            print(f"[KAMERA] Mencoba terhubung ke Program.cs backend {BACKEND_HOST}:{BACKEND_VIDEO_PORT}...")
            client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            client_socket.connect((BACKEND_HOST, BACKEND_VIDEO_PORT))
            print("[KAMERA] Streaming FPV aktif.")

            while is_streaming:
                try:
                    frame = picam2.capture_array()
                except Exception as e:
                    print(f"[KAMERA ERROR] Gagal capture frame dari Picamera2: {e}")
                    time.sleep(0.1)
                    continue

                try:
                    frame_bgr = _konversi_ke_bgr(frame, format_name)
                except Exception as e:
                    print(f"[KAMERA ERROR] Gagal konversi frame ke BGR: {e}")
                    time.sleep(0.1)
                    continue

                result, encoded_frame = cv2.imencode('.jpg', frame_bgr, [int(cv2.IMWRITE_JPEG_QUALITY), 50])
                if not result:
                    print("[KAMERA ERROR] cv2.imencode gagal membuat JPEG.")
                    time.sleep(0.1)
                    continue

                data = encoded_frame.tobytes()
                client_socket.sendall(struct.pack("<L", len(data)) + data)
                time.sleep(0.08)

        except Exception as e:
            print(f"[KAMERA ERROR] Koneksi/streaming gagal: {e}. Mengulang koneksi dalam 3 detik...")
            if client_socket:
                try:
                    client_socket.close()
                except:
                    pass
            time.sleep(3)

    if picam2:
        try:
            picam2.stop()
        except Exception as e:
            print(f"[KAMERA WARNING] Picamera2 gagal stop bersih: {e}")

def mulai_thread_kamera():
    t_kamera = threading.Thread(target=_loop_kamera, daemon=True)
    t_kamera.start()

def hentikan_kamera():
    global is_streaming
    is_streaming = False
