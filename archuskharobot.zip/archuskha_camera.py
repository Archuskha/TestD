import cv2
import socket
import struct
import time
import threading

BRIDGE_IP = "103.150.117.90"
BRIDGE_VIDEO_PORT = 6002
is_streaming = True

def _loop_kamera():
    # Bypass Bug GStreamer: Memaksa OpenCV menggunakan backend V4L2 murni
    cap = cv2.VideoCapture(0, cv2.CAP_V4L2)
    
    if not cap.isOpened():
        print("[KAMERA ERROR] Tidak dapat membuka perangkat /dev/video0")
        return

    # Memaksa kompresi perangkat keras (MJPG) agar beban RAM sangat ringan
    cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*'MJPG'))
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 480)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 360)
    cap.set(cv2.CAP_PROP_FPS, 15)
    
    while is_streaming:
        try:
            print(f"[KAMERA] Mencoba terhubung ke {BRIDGE_IP}:{BRIDGE_VIDEO_PORT}...")
            client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            client_socket.connect((BRIDGE_IP, BRIDGE_VIDEO_PORT))
            print("[KAMERA] Berhasil terhubung ke VPS Bridge!")

            while is_streaming:
                ret, frame = cap.read()
                if not ret:
                    time.sleep(0.1)
                    continue

                # Encode gambar ke JPG dengan kualitas 60%
                result, encoded_frame = cv2.imencode('.jpg', frame, [int(cv2.IMWRITE_JPEG_QUALITY), 60])
                if not result:
                    continue
                    
                data = encoded_frame.tobytes()

                # Kirim panjang bytes (4 byte) lalu diikuti biner gambarnya
                client_socket.sendall(struct.pack("<L", len(data)) + data)
                
                # Batasi ~20 FPS agar VPS dan Jaringan tidak jebol
                time.sleep(0.05) 

        except Exception as e:
            print(f"[KAMERA ERROR] Sambungan terputus: {e}. Mengulang dalam 5 detik...")
            if 'client_socket' in locals():
                client_socket.close()
            time.sleep(5)
            
    cap.release()

def mulai_thread_kamera():
    t_kamera = threading.Thread(target=_loop_kamera, daemon=True)
    t_kamera.start()

def hentikan_kamera():
    global is_streaming
    is_streaming = False