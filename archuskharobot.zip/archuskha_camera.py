import cv2
import os
import socket
import struct
import time
import threading

BACKEND_HOST = os.getenv("ARCHUSKHA_BACKEND_HOST", "localhost")
BACKEND_VIDEO_PORT = 6002
is_streaming = True

def _loop_kamera():
    cap = cv2.VideoCapture(0, cv2.CAP_V4L2)

    if not cap.isOpened():
        print("[KAMERA ERROR] Kamera gagal diakses oleh sistem.")
        return

    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 320)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 240)

    while is_streaming:
        client_socket = None
        try:
            print(f"[KAMERA] Mencoba terhubung ke Program.cs backend {BACKEND_HOST}:{BACKEND_VIDEO_PORT}...")
            client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            client_socket.connect((BACKEND_HOST, BACKEND_VIDEO_PORT))
            print("[KAMERA] Streaming FPV aktif.")

            while is_streaming:
                ret, frame = cap.read()
                if not ret:
                    time.sleep(0.1)
                    continue

                result, encoded_frame = cv2.imencode('.jpg', frame, [int(cv2.IMWRITE_JPEG_QUALITY), 50])
                if not result:
                    continue

                data = encoded_frame.tobytes()
                client_socket.sendall(struct.pack("<L", len(data)) + data)
                time.sleep(0.08)

        except Exception as e:
            print(f"[KAMERA ERROR] {e}. Mengulang koneksi dalam 3 detik...")
            if client_socket:
                try:
                    client_socket.close()
                except:
                    pass
            time.sleep(3)

    cap.release()

def mulai_thread_kamera():
    t_kamera = threading.Thread(target=_loop_kamera, daemon=True)
    t_kamera.start()

def hentikan_kamera():
    global is_streaming
    is_streaming = False
