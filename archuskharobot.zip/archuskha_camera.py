import cv2
import socket
import struct
import time
import threading

BRIDGE_IP = "103.150.117.90"
BRIDGE_VIDEO_PORT = 6002
is_streaming = True

def _loop_kamera():
    # Mode Paling Aman: V4L2 murni tanpa paksaan kompresi Hardware
    cap = cv2.VideoCapture(0, cv2.CAP_V4L2)
    
    if not cap.isOpened():
        print("[KAMERA ERROR] Kamera gagal diakses oleh sistem.")
        return

    # Resolusi super ringan (320x240) agar Raspberry Pi tidak kehabisan RAM/Crash
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 320)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 240)
    
    while is_streaming:
        try:
            client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            client_socket.connect((BRIDGE_IP, BRIDGE_VIDEO_PORT))

            while is_streaming:
                ret, frame = cap.read()
                if not ret:
                    time.sleep(0.1)
                    continue

                # Encode gambar ke JPG dengan kualitas sedang (50%)
                result, encoded_frame = cv2.imencode('.jpg', frame, [int(cv2.IMWRITE_JPEG_QUALITY), 50])
                if not result:
                    continue
                    
                data = encoded_frame.tobytes()

                # Kirim ukuran buffer (4 byte) diikuti datanya
                client_socket.sendall(struct.pack("<L", len(data)) + data)
                time.sleep(0.08) # Batasi FPS agar jaringan tidak spam

        except Exception as e:
            if 'client_socket' in locals() and client_socket:
                try: client_socket.close()
                except: pass
            time.sleep(3)
            
    cap.release()

def mulai_thread_kamera():
    t_kamera = threading.Thread(target=_loop_kamera, daemon=True)
    t_kamera.start()

def hentikan_kamera():
    global is_streaming
    is_streaming = False