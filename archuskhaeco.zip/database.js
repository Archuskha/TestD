const TABLES = {
    telemetry: {
        action: "database_telemetry",
        headers: ["Timestamp Lokal", "Timestamp UTC", "Sector", "Suhu", "pH", "mS/cm", "NTU", "mg/L", "mV", "Status", "Source"],
        row: (item) => [
            formatDate(item.timestampUtc),
            item.timestampUtc || "",
            item.sector || "",
            value(item.suhu),
            value(item.ph),
            value(item.mScm ?? item.mscm),
            value(item.ntu),
            value(item.mgL ?? item.mgl),
            value(item.mv),
            item.status || item.deviceStatus || "",
            item.source || ""
        ]
    },
    login: {
        action: "database_login",
        headers: ["Waktu", "Email", "Display name", "Role", "Action", "IP", "User agent", "Result"],
        row: (item) => [
            formatDate(item.timestampUtc),
            item.email || "",
            item.displayName || "",
            item.role || "",
            item.action || "",
            item.ipAddress || "",
            item.userAgent || "",
            item.result || ""
        ]
    },
    audit: {
        action: "database_audit",
        headers: ["Waktu", "Actor", "Role Actor", "Action", "Target Email", "Result", "Details"],
        row: (item) => [
            formatDate(item.timestampUtc),
            item.actorEmail || "",
            item.actorRole || "",
            item.action || "",
            item.targetEmail || "",
            item.result || "",
            item.details || ""
        ]
    }
};

let activeTab = "telemetry";
let page = 1;
let total = 0;

document.addEventListener("DOMContentLoaded", async () => {
    renderSidebar("database");
    document.getElementById("mobileMenuBtn")?.addEventListener("click", toggleMobileMenu);
    document.getElementById("logoutBtn")?.addEventListener("click", logoutAction);
    document.getElementById("refreshBtn")?.addEventListener("click", () => { page = 1; loadTable(); });
    document.getElementById("prevPageBtn")?.addEventListener("click", () => { if (page > 1) { page -= 1; loadTable(); } });
    document.getElementById("nextPageBtn")?.addEventListener("click", () => {
        const size = Number(document.getElementById("filterPageSize").value) || 50;
        if (page * size < total) { page += 1; loadTable(); }
    });
    document.querySelectorAll("[data-tab]").forEach((button) => {
        button.addEventListener("click", () => switchTab(button.dataset.tab));
    });

    const session = await requireAuth(["OWNER", "ADMIN"], "cirata.html");
    if (!session) return;
    updateFiltersForTab();
    await loadTable();
});

function switchTab(tab) {
    if (!TABLES[tab]) return;
    activeTab = tab;
    page = 1;
    document.querySelectorAll("[data-tab]").forEach((button) => {
        button.classList.toggle("active", button.dataset.tab === tab);
    });
    updateFiltersForTab();
    loadTable();
}

function updateFiltersForTab() {
    document.querySelector(".telemetry-filter").style.display = activeTab === "telemetry" ? "" : "none";
}

async function loadTable() {
    const status = document.getElementById("tableStatus");
    const table = document.getElementById("dataTable");
    status.textContent = "Memuat data...";
    table.replaceChildren();

    try {
        const size = Number(document.getElementById("filterPageSize").value) || 50;
        const params = new URLSearchParams({
            action: TABLES[activeTab].action,
            page: String(page),
            pageSize: String(size),
            sector: document.getElementById("filterSector").value,
            email: document.getElementById("filterEmail").value,
            role: document.getElementById("filterRole").value,
            actionFilter: document.getElementById("filterAction").value,
            search: document.getElementById("filterSearch").value,
            from: document.getElementById("filterFrom").value,
            to: document.getElementById("filterTo").value
        });
        const payload = await arOSApiFetch(params.toString());
        const result = payload.data || { items: [], total: 0, page, pageSize: size };
        total = result.total || 0;
        renderTable(TABLES[activeTab], result.items || []);
        status.textContent = result.items?.length ? `${result.items.length} baris ditampilkan.` : "Data kosong.";
        document.getElementById("pageInfo").textContent = `Page ${page}`;
    } catch (error) {
        status.textContent = error.message || "Gagal memuat data.";
    }
}

function renderTable(definition, items) {
    const table = document.getElementById("dataTable");
    const thead = document.createElement("thead");
    const headerRow = document.createElement("tr");
    definition.headers.forEach((header) => {
        const th = document.createElement("th");
        th.textContent = header;
        headerRow.appendChild(th);
    });
    thead.appendChild(headerRow);

    const tbody = document.createElement("tbody");
    items.forEach((item) => {
        const tr = document.createElement("tr");
        definition.row(item).forEach((cell) => {
            const td = document.createElement("td");
            td.textContent = cell == null ? "" : String(cell);
            tr.appendChild(td);
        });
        tbody.appendChild(tr);
    });

    table.append(thead, tbody);
}

function formatDate(utc) {
    if (!utc) return "";
    const date = new Date(utc);
    if (Number.isNaN(date.getTime())) return utc;
    return date.toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });
}

function value(input) {
    return input == null ? "" : String(input);
}
