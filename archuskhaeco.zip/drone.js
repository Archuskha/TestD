let droneInterval = null;
let isFlying = false;
let altitude = 0;

function logoutAction() {
    sessionStorage.removeItem("arOSToken");
    window.location.href = 'archuskha.html';
}

function logDrone(msg, type='system') {
    const box = document.getElementById('droneLog');
    if(!box) return;
    const p = document.createElement('p'); 
    p.textContent = msg; 
    p.className = `log-${type}`;
    if (type === 'error') p.style.color = '#ff3333';
    box.appendChild(p); box.scrollTop = box.scrollHeight;
}

function droneCommand(cmd) {
    logDrone(`[PILOT] Eksekusi instruksi: ${cmd}`, 'user');
    
    if (cmd === 'TAKEOFF') {
        if(isFlying) { logDrone("[UAV] Drone sudah mengudara.", 'error'); return; }
        isFlying = true;
        document.getElementById('camOverlay').textContent = "[ FPV AKTIF - PENGINTAIAN DIMULAI ]";
        document.getElementById('camOverlay').style.color = "#00ffff";
        logDrone("[UAV] Mesin dihidupkan. Lepas landas...");
    } 
    else if (cmd === 'LAND' || cmd === 'RTH') {
        isFlying = false;
        document.getElementById('camOverlay').textContent = "[ FPV STANBY - DRONE MENDARAT ]";
        document.getElementById('camOverlay').style.color = "var(--text-muted)";
        logDrone("[UAV] Mendarat darurat sesuai prosedur.");
    }
    else if (cmd === 'KILL') {
        isFlying = false; altitude = 0;
        document.getElementById('camOverlay').textContent = "[ KONEKSI TERPUTUS ]";
        document.getElementById('camOverlay').style.color = "#ff3333";
        logDrone("[FATAL] Mesin dimatikan paksa di udara!", 'error');
    }
}

// Loop simulasi pergerakan drone
document.addEventListener("DOMContentLoaded", () => {
    droneInterval = setInterval(() => {
        if (isFlying) {
            // Simulasi ketinggian naik sampai stabil di 120m
            if (altitude < 120) altitude += 5;
            document.getElementById('droneAlt').textContent = `${altitude} m`;
            document.getElementById('droneSpd').textContent = `${(15 + Math.random() * 5).toFixed(1)} km/h`;
            document.getElementById('droneBat').textContent = `${(98 - (altitude/200)).toFixed(0)}%`;
        } else {
            if (altitude > 0) altitude -= 10;
            if (altitude < 0) altitude = 0;
            document.getElementById('droneAlt').textContent = `${altitude} m`;
            document.getElementById('droneSpd').textContent = `0.0 km/h`;
        }
    }, 1000);
});