let droneInterval = null;
let isFlying = false;
let altitude = 0;
const AROS_THEME_KEY = "arOSTheme";

function applyArOSTheme(theme) {
    const mode = theme === "light" ? "light" : "dark";
    document.body.classList.toggle("light-mode", mode === "light");
    document.body.classList.toggle("dark-mode", mode === "dark");

    const label = document.getElementById("themeLabel");
    const toggle = document.getElementById("themeToggle");
    if (label) label.textContent = mode === "light" ? "Light Mode" : "Dark Mode";
    if (toggle) toggle.setAttribute("aria-pressed", String(mode === "light"));
}

function initArOSTheme() {
    const savedTheme = localStorage.getItem(AROS_THEME_KEY) || localStorage.getItem("cianjurTheme") || "dark";
    applyArOSTheme(savedTheme);

    const toggle = document.getElementById("themeToggle");
    if (!toggle) return;
    toggle.addEventListener("click", () => {
        const nextTheme = document.body.classList.contains("light-mode") ? "dark" : "light";
        localStorage.setItem(AROS_THEME_KEY, nextTheme);
        localStorage.setItem("cianjurTheme", nextTheme);
        applyArOSTheme(nextTheme);
    });
}

function enforceProtectedPageAccess() {
    if (!sessionStorage.getItem("arOSToken")) {
        window.location.href = "archuskha.html";
        return false;
    }

    if (sessionStorage.getItem("arOSRole") === "MINECRAFT_ONLY") {
        sessionStorage.setItem("arOSAccessDenied", "Robot hanya tersedia untuk admin/operator.");
        window.location.href = "archuskha.html";
        return false;
    }

    return true;
}

function logoutAction() {
    sessionStorage.removeItem("arOSToken");
    window.location.href = 'archuskha.html';
}

function logDrone(msg, type='system') {
    const box = document.getElementById('droneLog');
    if(!box) return;
    const p = document.createElement('p'); 
    p.textContent = msg; 
    p.className = `log-${type}`;
    if (type === 'error') p.style.color = '#ff3333';
    box.appendChild(p); box.scrollTop = box.scrollHeight;
}

function droneCommand(cmd) {
    logDrone(`[PILOT] Eksekusi instruksi: ${cmd}`, 'user');
    
    if (cmd === 'TAKEOFF') {
        if(isFlying) { logDrone("[UAV] Drone sudah mengudara.", 'error'); return; }
        isFlying = true;
        document.getElementById('camOverlay').textContent = "[ FPV AKTIF - PENGINTAIAN DIMULAI ]";
        document.getElementById('camOverlay').style.color = "#00ffff";
        logDrone("[UAV] Mesin dihidupkan. Lepas landas...");
    } 
    else if (cmd === 'LAND' || cmd === 'RTH') {
        isFlying = false;
        document.getElementById('camOverlay').textContent = "[ FPV STANBY - DRONE MENDARAT ]";
        document.getElementById('camOverlay').style.color = "var(--text-muted)";
        logDrone("[UAV] Mendarat darurat sesuai prosedur.");
    }
    else if (cmd === 'KILL') {
        isFlying = false; altitude = 0;
        document.getElementById('camOverlay').textContent = "[ KONEKSI TERPUTUS ]";
        document.getElementById('camOverlay').style.color = "#ff3333";
        logDrone("[FATAL] Mesin dimatikan paksa di udara!", 'error');
    }
}

// Loop simulasi pergerakan drone
document.addEventListener("DOMContentLoaded", () => {
    initArOSTheme();
    if (!enforceProtectedPageAccess()) return;

    droneInterval = setInterval(() => {
        if (isFlying) {
            // Simulasi ketinggian naik sampai stabil di 120m
            if (altitude < 120) altitude += 5;
            document.getElementById('droneAlt').textContent = `${altitude} m`;
            document.getElementById('droneSpd').textContent = `${(15 + Math.random() * 5).toFixed(1)} km/h`;
            document.getElementById('droneBat').textContent = `${(98 - (altitude/200)).toFixed(0)}%`;
        } else {
            if (altitude > 0) altitude -= 10;
            if (altitude < 0) altitude = 0;
            document.getElementById('droneAlt').textContent = `${altitude} m`;
            document.getElementById('droneSpd').textContent = `0.0 km/h`;
        }
    }, 1000);
});

function toggleMobileMenu() {
    const sidebar = document.querySelector('.sidebar');
    if (sidebar) {
        sidebar.classList.toggle('open');
    }
}
