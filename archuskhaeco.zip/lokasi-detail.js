const DETAIL_SECTORS = {
    A: {
        id: "A",
        name: "Cirata Sektor A",
        latitude: -6.8246388889,
        longitude: 107.1393333333,
        dms: "6\u00b049'28.7\"S 107\u00b008'21.6\"E",
        imageCandidates: ["images/StA.jpeg", "images/StA.jpg", "images/StA.png"],
        color: "#ff3333",
        summary: "Sektor A merupakan titik utama pemantauan kualitas air Cirata sesuai koordinat referensi BRIN."
    },
    B: {
        id: "B",
        name: "Cirata Sektor B",
        latitude: -6.8219,
        longitude: 107.1452,
        dms: "Sekitar Sektor A",
        imageCandidates: ["images/StB.jpeg", "images/StB.jpg", "images/StB.png"],
        color: "#00ffff",
        summary: "Sektor B berada di sekitar Sektor A sebagai titik pembanding telemetry kualitas air."
    }
};

let activeSector = null;

document.addEventListener("DOMContentLoaded", async () => {
    renderSidebar("lokasi");
    document.getElementById("mobileMenuBtn")?.addEventListener("click", toggleMobileMenu);
    document.getElementById("backMapBtn")?.addEventListener("click", () => { window.location.href = "lokasi.html"; });

    const params = new URLSearchParams(window.location.search);
    const sectorId = (params.get("sector") || "").toUpperCase();
    activeSector = DETAIL_SECTORS[sectorId];
    if (!activeSector) {
        showAccessDenied("Parameter sektor tidak valid.");
        setTimeout(() => { window.location.href = "lokasi.html"; }, 1200);
        return;
    }

    const session = await requireAuth(["OWNER", "ADMIN", "GUEST"], "archuskha.html");
    if (!session) return;

    renderStaticDetails(activeSector);
    loadSectorImage(activeSector);
    initDetailMap(activeSector);
    await loadLatestTelemetry(activeSector.id);
});

function renderStaticDetails(sector) {
    setText("sectorName", sector.name);
    setText("coordDms", sector.dms);
    setText("coordDecimal", `${sector.latitude}, ${sector.longitude}`);
    setText("sectorSummary", sector.summary);
}

function loadSectorImage(sector) {
    const img = document.getElementById("sectorImage");
    const placeholder = document.getElementById("imagePlaceholder");
    if (!img || !placeholder) return;

    let candidateIndex = 0;
    img.onerror = () => {
        candidateIndex += 1;
        if (candidateIndex < sector.imageCandidates.length) {
            img.src = sector.imageCandidates[candidateIndex];
            return;
        }
        img.hidden = true;
        placeholder.hidden = false;
    };
    img.onload = () => {
        img.hidden = false;
        placeholder.hidden = true;
    };
    img.src = sector.imageCandidates[candidateIndex];
}

function initDetailMap(sector) {
    const map = L.map("detailMap", {
        zoomControl: false
    }).setView([sector.latitude, sector.longitude], 15);
    L.tileLayer("https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png", {
        attribution: "&copy; OpenStreetMap"
    }).addTo(map);
    L.circleMarker([sector.latitude, sector.longitude], {
        color: sector.color,
        fillColor: sector.color,
        fillOpacity: 0.9,
        radius: 11
    }).addTo(map).bindPopup(sector.name);
}

async function loadLatestTelemetry(sector) {
    try {
        const payload = await arOSApiFetch(`action=telemetry_latest&sector=${encodeURIComponent(sector)}`);
        const data = payload.data || {};
        setText("deviceStatus", data.deviceStatus || "UNKNOWN");
        setText("lastUpdated", data.timestampLocal || "Data belum tersedia");
        setText("tSuhu", data.suhu == null ? "--" : `${fmt(data.suhu)} \u00b0C`);
        setText("tPh", data.ph == null ? "--" : fmt(data.ph));
        setText("tMscm", data.mscm == null ? "--" : `${fmt(data.mscm)} mS/cm`);
        setText("tNtu", data.ntu == null ? "--" : fmt(data.ntu));
        setText("tMgl", data.mgl == null ? "--" : `${fmt(data.mgl)} mg/L`);
        setText("tMv", data.mv == null ? "--" : fmt(data.mv));
    } catch {
        setText("deviceStatus", "Data belum tersedia");
    }
}

function setText(id, text) {
    const el = document.getElementById(id);
    if (el) el.textContent = text;
}

function fmt(value) {
    return Number(value).toLocaleString("id-ID", { maximumFractionDigits: 2 });
}
