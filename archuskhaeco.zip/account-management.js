let accountRole = "GUEST";

document.addEventListener("DOMContentLoaded", async () => {
    renderSidebar("account");
    document.getElementById("mobileMenuBtn")?.addEventListener("click", toggleMobileMenu);
    document.getElementById("logoutBtn")?.addEventListener("click", logoutAction);
    document.getElementById("refreshAdminsBtn")?.addEventListener("click", loadAdmins);
    document.getElementById("adminForm")?.addEventListener("submit", handleAddAdmin);
    document.getElementById("externalModuleForm")?.addEventListener("submit", saveExternalModule);
    document.getElementById("testModuleBtn")?.addEventListener("click", testExternalModule);
    document.getElementById("testAiBtn")?.addEventListener("click", testAiService);

    const session = await requireAuth(["OWNER", "ADMIN"], "cirata.html");
    if (!session) return;
    accountRole = session.role || "GUEST";
    setServiceControlsReadOnly(accountRole !== "OWNER");
    await Promise.all([
        accountRole === "OWNER" ? loadAdmins() : Promise.resolve(),
        loadExternalModuleStatus(),
        loadAiServiceStatus()
    ]);
});

async function loadAdmins() {
    const list = document.getElementById("adminList");
    if (!list) return;
    list.textContent = "Memuat daftar admin...";
    try {
        const payload = await arOSApiFetch("action=admins");
        document.getElementById("ownerEmail").textContent = payload.owner?.email || "mikojemmisaputra@gmail.com";
        list.replaceChildren();
        const admins = payload.admins || [];
        if (admins.length === 0) {
            const empty = document.createElement("p");
            empty.className = "form-message";
            empty.textContent = "Belum ada Admin terdaftar.";
            list.appendChild(empty);
            return;
        }

        admins.forEach((admin) => list.appendChild(renderAdminRow(admin)));
    } catch (error) {
        list.textContent = error.message || "Gagal memuat daftar admin.";
    }
}

function renderAdminRow(admin) {
    const row = document.createElement("div");
    row.className = "admin-row";

    const meta = document.createElement("div");
    meta.className = "admin-meta";
    const email = document.createElement("strong");
    email.textContent = admin.email || "";
    const name = document.createElement("span");
    name.textContent = admin.displayName ? `Nama: ${admin.displayName}` : "Nama: -";
    const date = document.createElement("span");
    date.textContent = `Ditambahkan: ${formatJakarta(admin.addedAtUtc)}`;
    const by = document.createElement("span");
    by.textContent = `Oleh: ${admin.addedBy || "-"}`;
    meta.append(email, name, date, by);

    const remove = document.createElement("button");
    remove.type = "button";
    remove.className = "tab-btn admin-remove-btn";
    remove.textContent = "Remove";
    remove.addEventListener("click", () => removeAdmin(admin.email));

    row.append(meta, remove);
    return row;
}

async function handleAddAdmin(event) {
    event.preventDefault();
    const button = document.getElementById("addAdminBtn");
    const message = document.getElementById("formMessage");
    const email = document.getElementById("adminEmail").value.trim().toLowerCase();
    const displayName = document.getElementById("adminDisplayName").value.trim();

    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
        message.style.color = "#ff3333";
        message.textContent = "Format email tidak valid.";
        return;
    }

    button.disabled = true;
    message.style.color = "var(--text-muted)";
    message.textContent = "Menyimpan admin...";
    try {
        await arOSApiFetch("action=admin_add", {
            method: "POST",
            body: JSON.stringify({ email, displayName })
        });
        message.style.color = "#00ffff";
        message.textContent = "Admin berhasil ditambahkan.";
        event.target.reset();
        await loadAdmins();
    } catch (error) {
        message.style.color = "#ff3333";
        message.textContent = error.message || "Gagal menambah admin.";
    } finally {
        button.disabled = false;
    }
}

async function removeAdmin(email) {
    if (!email || !confirm(`Hapus Admin ${email}?`)) return;
    try {
        await arOSApiFetch("action=admin_remove", {
            method: "POST",
            body: JSON.stringify({ email })
        });
        await loadAdmins();
    } catch (error) {
        alert(error.message || "Gagal menghapus Admin.");
    }
}

function formatJakarta(utc) {
    if (!utc) return "-";
    const date = new Date(utc);
    if (Number.isNaN(date.getTime())) return "-";
    return date.toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });
}

async function loadExternalModuleStatus() {
    setStatusBadge("moduleConnection", "Memuat...", "neutral");
    try {
        const payload = await arOSApiFetch("action=external_module_status&module=cianjur");
        renderExternalModuleStatus(payload.data || {});
    } catch (error) {
        setStatusBadge("moduleConnection", "ERROR", "warn");
        setText("moduleLastError", error.message || "Status module tidak tersedia.");
    }
}

function renderExternalModuleStatus(data) {
    const connection = data.connection || "UNKNOWN";
    setStatusBadge("moduleConnection", connection, connection === "ONLINE" ? "ok" : connection === "DISABLED" ? "neutral" : "warn");
    setText("moduleInstalled", data.installed ? (data.enabled ? "ENABLED" : "DISABLED") : "NOT INSTALLED");
    setText("moduleCurrentSource", data.currentSource || "-");
    setText("moduleLastFetch", formatJakarta(data.lastFetchUtc));
    setText("moduleLastSuccess", formatJakarta(data.lastSuccessUtc));
    setText("moduleLastError", data.lastErrorCode ? `${data.lastErrorCode}: ${data.lastError || "-"}` : "-");

    const sourceUrl = document.getElementById("moduleSourceUrl");
    const enabled = document.getElementById("moduleEnabled");
    const interval = document.getElementById("modulePollInterval");
    const sector = document.getElementById("moduleTargetSector");
    const fallback = document.getElementById("moduleFallback");
    if (sourceUrl) sourceUrl.value = data.sourceUrl || "";
    if (enabled) enabled.checked = Boolean(data.enabled);
    if (interval) interval.value = String(data.pollIntervalMinutes || 5);
    if (sector) sector.value = data.targetSector === "B" ? "B" : "A";
    if (fallback) fallback.checked = Boolean(data.fallbackToSimulationWhenUnavailable);
}

async function saveExternalModule(event) {
    event.preventDefault();
    if (accountRole !== "OWNER") return;
    const button = document.getElementById("saveModuleBtn");
    const message = document.getElementById("moduleMessage");
    const interval = Number(document.getElementById("modulePollInterval")?.value);
    if (!Number.isInteger(interval) || interval < 1 || interval > 1440) {
        showServiceMessage(message, "Poll interval harus bilangan bulat 1 sampai 1440 menit.", true);
        return;
    }

    button.disabled = true;
    showServiceMessage(message, "Menyimpan konfigurasi module...");
    try {
        const payload = await arOSApiFetch("action=external_module_config&module=cianjur", {
            method: "POST",
            body: JSON.stringify({
                enabled: Boolean(document.getElementById("moduleEnabled")?.checked),
                pollIntervalMinutes: interval,
                targetSector: document.getElementById("moduleTargetSector")?.value || "A",
                fallbackToSimulationWhenUnavailable: Boolean(document.getElementById("moduleFallback")?.checked)
            })
        });
        renderExternalModuleStatus(payload.data || {});
        showServiceMessage(message, payload.message || "Konfigurasi module tersimpan.");
    } catch (error) {
        showServiceMessage(message, formatApiError(error), true);
    } finally {
        button.disabled = false;
    }
}

async function testExternalModule() {
    if (accountRole !== "OWNER") return;
    const button = document.getElementById("testModuleBtn");
    const message = document.getElementById("moduleMessage");
    button.disabled = true;
    showServiceMessage(message, "Menguji koneksi source Cianjur...");
    try {
        const payload = await arOSApiFetch("action=external_module_test&module=cianjur", { method: "POST" });
        renderExternalModuleStatus(payload.data || {});
        showServiceMessage(message, payload.message || "Koneksi source berhasil.");
    } catch (error) {
        showServiceMessage(message, formatApiError(error), true);
        await loadExternalModuleStatus();
    } finally {
        button.disabled = false;
    }
}

async function loadAiServiceStatus() {
    setStatusBadge("aiProviderStatus", "Memuat...", "neutral");
    try {
        const payload = await arOSApiFetch("action=ai_status");
        renderAiServiceStatus(payload.data || {});
    } catch (error) {
        setStatusBadge("aiProviderStatus", "ERROR", "warn");
        setText("aiLastError", formatApiError(error));
    }
}

function renderAiServiceStatus(data) {
    const status = data.providerStatus || "UNKNOWN";
    setStatusBadge("aiProviderStatus", status, status === "ONLINE" ? "ok" : status === "NOT_TESTED" ? "neutral" : "warn");
    setText("aiEnabled", data.enabled ? "YES" : "NO");
    setText("aiConfigured", data.configured ? "YES" : "NO");
    setText("aiModel", data.model || "-");
    setText("aiLastSuccess", formatJakarta(data.lastSuccessUtc));
    setText("aiLastError", data.lastErrorCode || "-");
}

async function testAiService() {
    if (accountRole !== "OWNER") return;
    const button = document.getElementById("testAiBtn");
    const message = document.getElementById("aiTestMessage");
    button.disabled = true;
    showServiceMessage(message, "Menguji provider AI...");
    try {
        const payload = await arOSApiFetch("action=ai_test", { method: "POST" });
        renderAiServiceStatus(payload.data || {});
        showServiceMessage(message, payload.message || "AI provider merespons.");
    } catch (error) {
        showServiceMessage(message, formatApiError(error), true);
        await loadAiServiceStatus();
    } finally {
        button.disabled = false;
    }
}

function setServiceControlsReadOnly(readOnly) {
    ["moduleEnabled", "modulePollInterval", "moduleTargetSector", "moduleFallback"].forEach((id) => {
        const control = document.getElementById(id);
        if (control) control.disabled = readOnly;
    });
}

function setStatusBadge(id, text, mode) {
    const element = document.getElementById(id);
    if (!element) return;
    element.textContent = text;
    element.className = `status-badge ${mode || "neutral"}`;
}

function showServiceMessage(element, text, error = false) {
    if (!element) return;
    element.style.color = error ? "#ff3333" : "var(--text-muted)";
    element.textContent = text || "";
}

function formatApiError(error) {
    const code = error?.data?.code;
    const message = error?.message || "Request gagal.";
    return code ? `${code}: ${message}` : message;
}

function setText(id, text) {
    const element = document.getElementById(id);
    if (element) element.textContent = text;
}
