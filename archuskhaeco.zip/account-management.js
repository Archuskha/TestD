document.addEventListener("DOMContentLoaded", async () => {
    renderSidebar("account");
    document.getElementById("mobileMenuBtn")?.addEventListener("click", toggleMobileMenu);
    document.getElementById("logoutBtn")?.addEventListener("click", logoutAction);
    document.getElementById("refreshAdminsBtn")?.addEventListener("click", loadAdmins);
    document.getElementById("adminForm")?.addEventListener("submit", handleAddAdmin);

    const session = await requireAuth(["OWNER"], "cirata.html");
    if (!session) return;
    await loadAdmins();
});

async function loadAdmins() {
    const list = document.getElementById("adminList");
    if (!list) return;
    list.textContent = "Memuat daftar admin...";
    try {
        const payload = await arOSApiFetch("action=admins");
        document.getElementById("ownerEmail").textContent = payload.owner?.email || "mikojemmisaputra@gmail.com";
        list.replaceChildren();
        const admins = payload.admins || [];
        if (admins.length === 0) {
            const empty = document.createElement("p");
            empty.className = "form-message";
            empty.textContent = "Belum ada Admin terdaftar.";
            list.appendChild(empty);
            return;
        }

        admins.forEach((admin) => list.appendChild(renderAdminRow(admin)));
    } catch (error) {
        list.textContent = error.message || "Gagal memuat daftar admin.";
    }
}

function renderAdminRow(admin) {
    const row = document.createElement("div");
    row.className = "admin-row";

    const meta = document.createElement("div");
    meta.className = "admin-meta";
    const email = document.createElement("strong");
    email.textContent = admin.email || "";
    const name = document.createElement("span");
    name.textContent = admin.displayName ? `Nama: ${admin.displayName}` : "Nama: -";
    const date = document.createElement("span");
    date.textContent = `Ditambahkan: ${formatJakarta(admin.addedAtUtc)}`;
    const by = document.createElement("span");
    by.textContent = `Oleh: ${admin.addedBy || "-"}`;
    meta.append(email, name, date, by);

    const remove = document.createElement("button");
    remove.type = "button";
    remove.className = "tab-btn admin-remove-btn";
    remove.textContent = "Remove";
    remove.addEventListener("click", () => removeAdmin(admin.email));

    row.append(meta, remove);
    return row;
}

async function handleAddAdmin(event) {
    event.preventDefault();
    const button = document.getElementById("addAdminBtn");
    const message = document.getElementById("formMessage");
    const email = document.getElementById("adminEmail").value.trim().toLowerCase();
    const displayName = document.getElementById("adminDisplayName").value.trim();

    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
        message.style.color = "#ff3333";
        message.textContent = "Format email tidak valid.";
        return;
    }

    button.disabled = true;
    message.style.color = "var(--text-muted)";
    message.textContent = "Menyimpan admin...";
    try {
        await arOSApiFetch("action=admin_add", {
            method: "POST",
            body: JSON.stringify({ email, displayName })
        });
        message.style.color = "#00ffff";
        message.textContent = "Admin berhasil ditambahkan.";
        event.target.reset();
        await loadAdmins();
    } catch (error) {
        message.style.color = "#ff3333";
        message.textContent = error.message || "Gagal menambah admin.";
    } finally {
        button.disabled = false;
    }
}

async function removeAdmin(email) {
    if (!email || !confirm(`Hapus Admin ${email}?`)) return;
    try {
        await arOSApiFetch("action=admin_remove", {
            method: "POST",
            body: JSON.stringify({ email })
        });
        await loadAdmins();
    } catch (error) {
        alert(error.message || "Gagal menghapus Admin.");
    }
}

function formatJakarta(utc) {
    if (!utc) return "-";
    const date = new Date(utc);
    if (Number.isNaN(date.getTime())) return "-";
    return date.toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });
}
