const AROS_API_URL = (() => {
    if (window.location.protocol === "file:" || !window.location.hostname) {
        return "http://localhost:8080";
    }
    return `${window.location.origin}/api-bridge`;
})();

const AROS_STORAGE_KEYS = [
    "arOSToken",
    "arOSRole",
    "arOSEmail",
    "arOSName",
    "arOSPicture",
    "arOSExpiresAt"
];

function arOSToken() {
    return sessionStorage.getItem("arOSToken") || "";
}

function clearLocalSession() {
    AROS_STORAGE_KEYS.forEach((key) => sessionStorage.removeItem(key));
}

async function arOSApiFetch(action, options = {}) {
    const headers = new Headers(options.headers || {});
    headers.set("Accept", "application/json");
    if (options.body && !headers.has("Content-Type")) {
        headers.set("Content-Type", "application/json");
    }

    const token = arOSToken();
    if (token) {
        headers.set("Authorization", `Bearer ${token}`);
    }

    const url = action.startsWith("http") ? action : `${AROS_API_URL}/?${action}`;
    const response = await fetch(url, { ...options, headers });
    let data = null;
    try {
        data = await response.json();
    } catch {
        data = { status: response.status, message: "Response server tidak valid." };
    }

    if (response.status === 401 || data.code === "SESSION_EXPIRED") {
        clearLocalSession();
        throw Object.assign(new Error(data.message || "Sesi berakhir."), { status: response.status, data });
    }

    if (!response.ok || (data.status && data.status >= 400)) {
        throw Object.assign(new Error(data.message || "Request gagal."), { status: response.status, data });
    }

    return data;
}

async function refreshSession() {
    const token = arOSToken();
    if (!token) return null;
    const data = await arOSApiFetch("action=session");
    if (data.authenticated) {
        sessionStorage.setItem("arOSRole", data.role || "GUEST");
        sessionStorage.setItem("arOSEmail", data.email || "");
        sessionStorage.setItem("arOSName", data.name || "");
        sessionStorage.setItem("arOSPicture", data.picture || "");
        sessionStorage.setItem("arOSExpiresAt", data.expiresAtUtc || "");
    }
    return data;
}

async function requireAuth(allowedRoles = ["OWNER", "ADMIN", "GUEST"], redirectTo = "archuskha.html") {
    try {
        const session = await refreshSession();
        if (!session || !allowedRoles.includes(session.role)) {
            showAccessDenied("Anda tidak memiliki izin untuk membuka halaman ini.");
            setTimeout(() => { window.location.href = redirectTo; }, 1200);
            return null;
        }
        applyRoleAwareUi(session.role);
        return session;
    } catch (error) {
        showAccessDenied(error.message || "Sesi tidak valid.");
        setTimeout(() => { window.location.href = redirectTo; }, 1200);
        return null;
    }
}

function showAccessDenied(message) {
    let box = document.getElementById("accessDeniedBox");
    if (!box) {
        box = document.createElement("div");
        box.id = "accessDeniedBox";
        box.className = "access-denied-box";
        document.body.appendChild(box);
    }
    box.textContent = message;
}

function applyRoleAwareUi(role) {
    document.querySelectorAll("[data-roles]").forEach((el) => {
        const roles = (el.getAttribute("data-roles") || "").split(",").map((item) => item.trim());
        el.style.display = roles.includes(role) ? "" : "none";
    });

    document.querySelectorAll("[data-role-label]").forEach((el) => {
        el.textContent = role || "GUEST";
    });
}

function renderSidebar(activePage = "home") {
    const headerTitle = activePage === "home"
        ? "Admin Utama"
        : activePage === "lokasi"
            ? "Cianjur Portal"
            : "Cirata Admin";
    const sidebars = document.querySelectorAll("[data-aros-sidebar]");
    sidebars.forEach((sidebar) => {
        sidebar.innerHTML = `
            <button class="close-menu-btn" type="button" data-mobile-close>×</button>
            <div class="sidebar-header">
                <h2>${headerTitle}</h2>
            </div>
            <ul class="sidebar-menu">
                <li class="parent-menu ${activePage === "home" ? "active" : ""}" data-nav="archuskha.html">🏠 Home</li>
                <li class="parent-menu ${activePage === "cirata" || activePage === "dashboard" || activePage === "lokasi" ? "active" : ""}" data-nav="cirata.html">🌊 Cianjur (BRIN)</li>
                <li class="divider">MENU NAVIGASI</li>
                <li class="sub-item ${activePage === "dashboard" ? "active" : ""}" data-nav="cirata.html">Dashboard Parameter</li>
                <li class="sub-item ${activePage === "lokasi" ? "active" : ""}" data-nav="lokasi.html">Lokasi Peta (GIS)</li>
                <li class="sub-item ${activePage === "account" ? "active" : ""}" data-roles="OWNER" data-nav="account-management.html">Account Management</li>
                <li class="sub-item ${activePage === "database" ? "active" : ""}" data-roles="OWNER,ADMIN" data-nav="database.html">Database</li>
                <li class="divider mobile-only">SISTEM</li>
                <li class="sub-item mobile-only" style="color: #ff3333;" data-logout>🔒 Keluar Sesi</li>
            </ul>
            <div class="sidebar-footer">
                <div class="logo-container">
                    <img src="https://upload.wikimedia.org/wikipedia/commons/d/dd/Alt_Logo_BRIN.png" alt="BRIN" class="footer-logo brin-logo">
                    <span class="aros-logo-text"><span class="ar">ar</span><span class="os">OS</span></span>
                </div>
                <p class="footer-copyright">Archuskha Ecosystem</p>
            </div>
        `;
    });

    document.querySelectorAll("[data-nav]").forEach((el) => {
        el.addEventListener("click", () => { window.location.href = el.getAttribute("data-nav"); });
    });
    document.querySelectorAll("[data-logout]").forEach((el) => el.addEventListener("click", logoutAction));
    document.querySelectorAll("[data-mobile-close]").forEach((el) => el.addEventListener("click", toggleMobileMenu));
    applyRoleAwareUi(sessionStorage.getItem("arOSRole") || "GUEST");
}

async function logoutAction() {
    try {
        if (arOSToken()) {
            await arOSApiFetch("action=logout", { method: "POST" });
        }
    } catch {
    } finally {
        clearLocalSession();
        window.location.href = "archuskha.html";
    }
}

function toggleMobileMenu() {
    const sidebar = document.querySelector(".sidebar");
    if (sidebar) sidebar.classList.toggle("open");
}
