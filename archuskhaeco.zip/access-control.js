const AROS_API_URL = (() => {
    if (window.location.protocol === "file:" || !window.location.hostname) {
        return "http://localhost:8080";
    }
    return `${window.location.origin}/api-bridge`;
})();

const AROS_STORAGE_KEYS = [
    "arOSToken",
    "arOSRole",
    "arOSEmail",
    "arOSName",
    "arOSPicture",
    "arOSExpiresAt"
];
const AROS_API_TIMEOUT_MS = 20000;
const AROS_HTTP_ERROR_CODES = {
    401: "SESSION_INVALID",
    403: "FORBIDDEN",
    404: "API_ACTION_NOT_FOUND",
    500: "BACKEND_ERROR",
    502: "UPSTREAM_ERROR",
    503: "SERVICE_UNAVAILABLE"
};

function arOSToken() {
    return sessionStorage.getItem("arOSToken") || "";
}

function clearLocalSession() {
    AROS_STORAGE_KEYS.forEach((key) => sessionStorage.removeItem(key));
    window.dispatchEvent(new CustomEvent("aros:session-cleared"));
}

async function arOSApiFetch(action, options = {}) {
    const headers = new Headers(options.headers || {});
    headers.set("Accept", "application/json");
    if (options.body && !headers.has("Content-Type")) {
        headers.set("Content-Type", "application/json");
    }

    const token = arOSToken();
    if (token) {
        headers.set("Authorization", `Bearer ${token}`);
    }

    const url = action.startsWith("http") ? action : `${AROS_API_URL}/?${action}`;
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), AROS_API_TIMEOUT_MS);
    let response;
    try {
        response = await fetch(url, { ...options, headers, signal: controller.signal });
    } catch (cause) {
        const timedOut = cause?.name === "AbortError";
        const data = {
            status: 0,
            code: timedOut ? "REQUEST_TIMEOUT" : "NETWORK_ERROR",
            message: timedOut ? "Backend tidak merespons tepat waktu." : "Backend tidak dapat dihubungi."
        };
        logApiFailure(action, options.method, 0, data);
        throw Object.assign(new Error(data.message), { status: 0, data, cause });
    } finally {
        clearTimeout(timeout);
    }

    let data = null;
    try {
        data = await response.json();
    } catch {
        data = {
            status: response.status,
            code: AROS_HTTP_ERROR_CODES[response.status] || "INVALID_RESPONSE",
            message: response.ok ? "Response server tidak valid." : apiErrorMessage(response.status)
        };
    }

    if (response.status === 401 || data.code === "SESSION_EXPIRED") {
        clearLocalSession();
        data.code ||= "SESSION_INVALID";
        logApiFailure(action, options.method, response.status, data);
        throw Object.assign(new Error(data.message || "Sesi berakhir."), { status: response.status, data });
    }

    if (!response.ok || (data.status && data.status >= 400)) {
        data.code ||= AROS_HTTP_ERROR_CODES[response.status] || "API_REQUEST_FAILED";
        data.message ||= apiErrorMessage(response.status);
        logApiFailure(action, options.method, response.status, data);
        throw Object.assign(new Error(data.message), { status: response.status, data });
    }

    return data;
}

function apiErrorMessage(status) {
    if (status === 401) return "Sesi tidak valid atau telah berakhir.";
    if (status === 403) return "Anda tidak memiliki izin untuk request ini.";
    if (status === 404) return "Endpoint backend tidak ditemukan.";
    if (status === 500) return "Backend mengalami kesalahan internal.";
    if (status === 502) return "API bridge tidak dapat menjangkau backend.";
    if (status === 503) return "Layanan backend sementara tidak tersedia.";
    return "Request API gagal.";
}

function logApiFailure(action, method, status, data) {
    const query = action.startsWith("http") ? new URL(action).search : action;
    const actionName = new URLSearchParams(query.replace(/^\?/, "")).get("action") || "unknown";
    console.error("[API]", {
        action: actionName,
        method: (method || "GET").toUpperCase(),
        status,
        code: data?.code || "API_REQUEST_FAILED",
        message: data?.message || "Request API gagal."
    });
}

async function refreshSession() {
    const token = arOSToken();
    if (!token) return null;
    const data = await arOSApiFetch("action=session");
    if (data.authenticated) {
        sessionStorage.setItem("arOSRole", data.role || "GUEST");
        sessionStorage.setItem("arOSEmail", data.email || "");
        sessionStorage.setItem("arOSName", data.name || "");
        sessionStorage.setItem("arOSPicture", data.picture || "");
        sessionStorage.setItem("arOSExpiresAt", data.expiresAtUtc || "");
    }
    return data;
}

async function requireAuth(allowedRoles = ["OWNER", "ADMIN", "GUEST"], redirectTo = "archuskha.html") {
    try {
        const session = await refreshSession();
        if (!session || !allowedRoles.includes(session.role)) {
            showAccessDenied("Anda tidak memiliki izin untuk membuka halaman ini.");
            setTimeout(() => { window.location.href = redirectTo; }, 1200);
            return null;
        }
        applyRoleAwareUi(session.role);
        window.dispatchEvent(new CustomEvent("aros:authenticated", { detail: session }));
        return session;
    } catch (error) {
        showAccessDenied(error.message || "Sesi tidak valid.");
        setTimeout(() => { window.location.href = redirectTo; }, 1200);
        return null;
    }
}

function showAccessDenied(message) {
    let box = document.getElementById("accessDeniedBox");
    if (!box) {
        box = document.createElement("div");
        box.id = "accessDeniedBox";
        box.className = "access-denied-box";
        document.body.appendChild(box);
    }
    box.textContent = message;
}

function applyRoleAwareUi(role) {
    document.querySelectorAll("[data-roles]").forEach((el) => {
        const roles = (el.getAttribute("data-roles") || "").split(",").map((item) => item.trim());
        el.style.display = roles.includes(role) ? "" : "none";
    });

    document.querySelectorAll("[data-role-label]").forEach((el) => {
        el.textContent = role || "GUEST";
    });
}

function renderSidebar(activePage = "home") {
    const headerTitle = activePage === "home"
        ? "Admin Utama"
        : activePage === "lokasi"
            ? "Cianjur Portal"
            : "arOS Admin";
    const sidebars = document.querySelectorAll("[data-aros-sidebar]");
    sidebars.forEach((sidebar) => {
        sidebar.innerHTML = `
            <button class="close-menu-btn" type="button" data-mobile-close>×</button>
            <div class="sidebar-header">
                <h2>${headerTitle}</h2>
            </div>
            <ul class="sidebar-menu">
                <li class="parent-menu ${activePage === "home" ? "active" : ""}" data-nav="archuskha.html">🏠 Home</li>
                <li class="parent-menu ${activePage === "cirata" || activePage === "dashboard" || activePage === "lokasi" ? "active" : ""}" data-nav="cirata.html">🌊 Cianjur (BRIN)</li>
                <li class="divider">MENU NAVIGASI</li>
                <li class="sub-item ${activePage === "dashboard" ? "active" : ""}" data-nav="cirata.html">Dashboard Parameter</li>
                <li class="sub-item ${activePage === "lokasi" ? "active" : ""}" data-nav="lokasi.html">Lokasi Peta (GIS)</li>
                <li class="sub-item ${activePage === "account" ? "active" : ""}" data-roles="OWNER,ADMIN" data-nav="account-management.html">Account Management</li>
                <li class="sub-item ${activePage === "database" ? "active" : ""}" data-roles="OWNER,ADMIN" data-nav="database.html">Database</li>
                <li class="divider mobile-only">SISTEM</li>
                <li class="sub-item mobile-only" style="color: #ff3333;" data-logout>🔒 Keluar Sesi</li>
            </ul>
            <div class="sidebar-footer">
                <label class="theme-control">
                    <span>Tampilan</span>
                    <select data-theme-select aria-label="Mode tampilan">
                        <option value="dark">Dark</option>
                        <option value="light">Light</option>
                        <option value="system">System</option>
                    </select>
                </label>
                <div class="logo-container">
                    <img src="https://upload.wikimedia.org/wikipedia/commons/d/dd/Alt_Logo_BRIN.png" alt="BRIN" class="footer-logo brin-logo">
                    <span class="aros-logo-text"><span class="ar">ar</span><span class="os">OS</span></span>
                </div>
                <p class="footer-copyright">Archuskha Ecosystem</p>
            </div>
        `;
    });

    document.querySelectorAll("[data-nav]").forEach((el) => {
        el.addEventListener("click", () => { window.location.href = el.getAttribute("data-nav"); });
    });
    document.querySelectorAll("[data-logout]").forEach((el) => el.addEventListener("click", logoutAction));
    document.querySelectorAll("[data-mobile-close]").forEach((el) => el.addEventListener("click", toggleMobileMenu));
    applyRoleAwareUi(sessionStorage.getItem("arOSRole") || "GUEST");
    window.arOSTheme?.syncControls();
}

async function logoutAction() {
    try {
        if (arOSToken()) {
            await arOSApiFetch("action=logout", { method: "POST" });
        }
    } catch {
    } finally {
        clearLocalSession();
        window.location.href = "archuskha.html";
    }
}

function toggleMobileMenu() {
    const sidebar = document.querySelector(".sidebar");
    if (sidebar) sidebar.classList.toggle("open");
}
