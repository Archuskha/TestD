// Konfigurasi Koneksi Utama
// UBAH INI: Jika menggunakan IP langsung (Contoh: "http://192.168.1.10:8080")
// UBAH INI: Jika masih menggunakan Nginx murni tanpa Cloudflare (Contoh: "/api-bridge")
const BRIDGE_API_URL = "http://103.150.117.90:8080"; 

let sessionToken = null;

const loginScreen = document.getElementById('loginScreen');
const mainScreen = document.getElementById('mainScreen');
const passwordInput = document.getElementById('passwordInput');
const loginBtn = document.getElementById('loginBtn');
const loginMessage = document.getElementById('loginMessage');

const logBox = document.getElementById('logBox');
const promptInput = document.getElementById('promptInput');
const sendBtn = document.getElementById('sendBtn');

// --- FUNGSI OTORISASI (LOGIN) ---
async function loginAction() {
    const pwd = passwordInput.value;
    if (!pwd) return;

    loginBtn.disabled = true;
    loginMessage.style.color = "var(--text-muted)";
    loginMessage.textContent = "Mengautentikasi...";

    try {
        const response = await fetch(`${BRIDGE_API_URL}/?action=login&password=${encodeURIComponent(pwd)}`);
        const data = await response.json();

        if (response.ok && data.status === 200) {
            sessionToken = data.message;
            passwordInput.value = "";
            loginMessage.textContent = "";
            
            loginScreen.style.display = "none";
            mainScreen.style.display = "block";
            promptInput.focus();
        } else {
            loginMessage.style.color = "var(--danger)";
            loginMessage.textContent = data.message || "Akses ditolak.";
        }
    } catch (error) {
        loginMessage.style.color = "var(--danger)";
        loginMessage.textContent = "Koneksi ke server gagal. Periksa IP atau Bridge Anda.";
        console.error("Detail Error:", error);
    } finally {
        loginBtn.disabled = false;
    }
}

passwordInput.addEventListener("keypress", function(event) {
    if (event.key === "Enter") {
        event.preventDefault();
        loginBtn.click();
    }
});

// --- FUNGSI TERMINASI (LOGOUT) ---
async function logoutAction() {
    if(!sessionToken) return;
    
    try {
        await fetch(`${BRIDGE_API_URL}/?action=logout&token=${encodeURIComponent(sessionToken)}`);
    } catch(e) { console.error("Gagal mengirim sinyal logout."); }

    sessionToken = null;
    mainScreen.style.display = "none";
    loginScreen.style.display = "block";
    logBox.innerHTML = '<p class="log-system">[SYSTEM] Sesi telah diakhiri secara aman.</p>';
}

window.addEventListener('beforeunload', function() {
    if (sessionToken) {
        fetch(`${BRIDGE_API_URL}/?action=logout&token=${encodeURIComponent(sessionToken)}`, { keepalive: true });
    }
});

// --- FUNGSI TRANSMISI DATA ---
function addLog(message, type = 'system') {
    const p = document.createElement('p');
    p.textContent = message;
    p.className = `log-${type}`;
    logBox.appendChild(p);
    logBox.scrollTop = logBox.scrollHeight;
}

async function sendRequestToBridge(promptText) {
    if (!promptText.trim() || !sessionToken) return;

    promptInput.disabled = true;
    sendBtn.disabled = true;
    addLog(`[USER] Eksekusi: "${promptText}"`, 'user');

    try {
        const response = await fetch(`${BRIDGE_API_URL}/?prompt=${encodeURIComponent(promptText)}&token=${encodeURIComponent(sessionToken)}`);
        const data = await response.json();
        
        if (data.status === 200) {
            addLog(`[BRIDGE] Instruksi berhasil diteruskan ke AI.`, 'system');
        } else if (data.status === 401) {
            addLog(`[ERROR] ${data.message}`, 'error');
            alert("Sesi keamanan Anda telah kedaluwarsa.");
            logoutAction(); 
        } else {
            addLog(`[ERROR] ${data.message}`, 'error');
        }
    } catch (error) {
        addLog(`[ERROR] Gagal menyambungkan transmisi ke Bridge C#.`, 'error');
        console.error("Detail Error:", error);
    } finally {
        promptInput.disabled = false;
        sendBtn.disabled = false;
        promptInput.focus();
    }
}

function sendCustomPrompt() {
    sendRequestToBridge(promptInput.value);
    promptInput.value = '';
}

promptInput.addEventListener("keypress", function(event) {
    if (event.key === "Enter") {
        event.preventDefault();
        sendBtn.click();
    }
});