const BRIDGE_API_URL = "/api-bridge"; 
const GOOGLE_SHEET_API = "https://script.google.com/macros/s/AKfycbyyJfEoS7vQfR-NzxRHbmKnOQetgvtdW_a5LRmO5BPva6WeM24lQ-4lHvuEvGSD3mIILg/exec";

let sessionToken = null;
let telemetryInterval = null;
let sensorChart = null;

function splitTextToParticles(elementId, baseDelay) {
    const el = document.getElementById(elementId);
    if (!el) return;
    
    const text = el.innerText;
    el.innerText = ''; 
    
    for (let i = 0; i < text.length; i++) {
        let span = document.createElement('span');
        span.className = 'letter-particle';
        
        // MENAMBAHKAN KELAS KHUSUS PADA SPASI AGAR BISA DIPISAH DI MOBILE
        if (text[i] === ' ') {
            span.innerHTML = '&nbsp;';
            span.classList.add('space-char');
        } else {
            span.innerHTML = text[i];
        }
        
        let rx = (Math.random() - 0.5) * 2000;
        let ry = (Math.random() - 0.5) * 2000;
        let rz = (Math.random() - 0.5) * 2000;
        
        span.style.setProperty('--rx', rx);
        span.style.setProperty('--ry', ry);
        span.style.setProperty('--rz', rz);
        
        // PENGATURAN WARNA DAN GLOW SPESIFIK UNTUK HURUF
        if (elementId === 'introTitle') {
            // Indeks 0 & 1 = "Ar", Indeks 12 & 13 = "os"
            if (i === 0 || i === 1 || i === 12 || i === 13) {
                span.style.setProperty('--target-color', '#00ffff'); 
                span.style.setProperty('--target-shadow', '0 0 15px #00ffff, 0 0 30px #00ffff'); // Glow terang Cyan
            } else {
                span.style.setProperty('--target-color', '#ffffff'); 
                span.style.setProperty('--target-shadow', '0 0 8px rgba(255, 255, 255, 0.6)'); // Glow standar Putih
            }
        } else if (elementId === 'introSubtitle') {
            span.style.setProperty('--target-color', '#00ffff'); 
            span.style.setProperty('--target-shadow', 'none'); // BRIN tanpa glow, hanya warna Cyan
        }
        
        let delay = baseDelay + (i * 0.04); 
        span.style.animation = `assembleLetter 6s cubic-bezier(0.25, 1, 0.3, 1) ${delay}s forwards`;
        
        el.appendChild(span);
    }
}

document.addEventListener("DOMContentLoaded", () => {
    generateParticles();
    
    const introTextContainer = document.getElementById('introTextContainer');
    const particleContainer = document.getElementById('particle-container');

    setTimeout(() => {
        if (particleContainer) {
            particleContainer.classList.add('destroy-particles');
            setTimeout(() => particleContainer.remove(), 2000); 
        }
    }, 4000); 

    setTimeout(() => {
        if (introTextContainer) {
            introTextContainer.style.display = 'block'; 
            introTextContainer.style.opacity = '1';
        }
        
        splitTextToParticles('introTitle', 0);
        splitTextToParticles('introSubtitle', 0.3);
    }, 4500); 

    setTimeout(() => {
        if (introTextContainer) introTextContainer.style.display = 'none';
        showLogin(); 
    }, 12500); 
});

// ==========================================
// FUNGSI GENERATOR PARTIKEL (ACAK -> arOS)
// ==========================================
function generateParticles() {
    const wrap = document.getElementById('particle-container');
    if (!wrap) return;

    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    canvas.width = 700;
    canvas.height = 300;

    ctx.fillStyle = "white";
    ctx.font = "bold 160px 'Varela Round', sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("arOS", canvas.width / 2, canvas.height / 2);

    const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height).data;
    const step = 6; 

    for (let y = 0; y < canvas.height; y += step) {
        for (let x = 0; x < canvas.width; x += step) {
            const alpha = imgData[(y * canvas.width + x) * 4 + 3];
            if (alpha > 128) {
                let div = document.createElement('div');
                div.className = 'c';

                let tx = x - (canvas.width / 2);
                let ty = y - (canvas.height / 2);
                
                let sx = (Math.random() - 0.5) * 3000;
                let sy = (Math.random() - 0.5) * 3000;
                let sz = (Math.random() - 0.5) * 3000;

                div.style.backgroundColor = '#ffffff';
                div.style.boxShadow = '0 0 8px #ffffff';

                div.style.setProperty('--tx', `${tx}px`);
                div.style.setProperty('--ty', `${ty}px`);
                div.style.setProperty('--sx', `${sx}px`);
                div.style.setProperty('--sy', `${sy}px`);
                div.style.setProperty('--sz', `${sz}px`);

                div.style.animationDelay = `${Math.random() * 1.5}s`;

                wrap.appendChild(div);
            }
        }
    }
}

// ==========================================
// KONTROL ALUR LAYAR & FUNGSI OTORISASI
// ==========================================
function showLogin() {
    const introScreen = document.getElementById('introScreen');
    const loginScreen = document.getElementById('loginScreen');
    
    if(introScreen) introScreen.classList.remove('active');
    setTimeout(() => {
        if(loginScreen) loginScreen.classList.add('active');
    }, 500); 
}

async function loginAction() {
    const passwordInput = document.getElementById('passwordInput');
    const loginMessage = document.getElementById('loginMessage');
    const loginScreen = document.getElementById('loginScreen');
    const mainScreen = document.getElementById('mainScreen');
    
    const pwd = passwordInput.value;
    if (!pwd) return;

    loginMessage.style.color = "var(--text-muted)";
    loginMessage.textContent = "Memverifikasi...";

    try {
        const response = await fetch(`${BRIDGE_API_URL}/?action=login&password=${encodeURIComponent(pwd)}`);
        const data = await response.json();

        if (response.ok && data.status === 200) {
            sessionToken = data.message;
            passwordInput.value = "";
            loginMessage.textContent = "";
            
            loginScreen.classList.remove('active');
            setTimeout(() => {
                mainScreen.classList.add('active');
                mulaiTelemetri();
                inisialisasiGrafik();
            }, 800);
        } else {
            loginMessage.style.color = "#ff3333";
            loginMessage.textContent = data.message || "Akses ditolak.";
        }
    } catch (error) {
        // Fallback UI
        loginScreen.classList.remove('active');
        setTimeout(() => {
            mainScreen.classList.add('active');
            mulaiTelemetri();
            inisialisasiGrafik();
        }, 800);
    }
}

document.getElementById('passwordInput').addEventListener("keypress", (e) => { if (e.key === "Enter") loginAction(); });

async function logoutAction() {
    if(!sessionToken) return;
    try { await fetch(`${BRIDGE_API_URL}/?action=logout&token=${encodeURIComponent(sessionToken)}`); } catch(e) {}

    const loginScreen = document.getElementById('loginScreen');
    const mainScreen = document.getElementById('mainScreen');
    const logBox = document.getElementById('logBox');

    sessionToken = null;
    clearInterval(telemetryInterval);
    
    mainScreen.classList.remove('active');
    setTimeout(() => {
        loginScreen.classList.add('active');
        if(logBox) logBox.innerHTML = '<p class="log-system">[SYSTEM] Sesi telah diakhiri secara aman.</p>';
    }, 800);
}

function mulaiTelemetri() {
    telemetryInterval = setInterval(async () => {
        if (!sessionToken) return;
        try {
            const res = await fetch(`${BRIDGE_API_URL}/?action=telemetry&token=${encodeURIComponent(sessionToken)}`);
            const data = await res.json();
            if (data.status === 200 && data.message) perbaruiDashboard(data.message);
        } catch (e) {}
    }, 2000);
}

function perbaruiDashboard(logMessage) {
    const extract = (str, pattern) => {
        const match = str.match(new RegExp(pattern, "i"));
        return match ? match[1] : "--";
    };

    document.getElementById('valSuhu').textContent = extract(logMessage, "\\[suhu\\]\\s*([0-9.]+)");
    document.getElementById('valPh').textContent = extract(logMessage, "\\[Ph\\]\\s*([0-9.]+)");
    document.getElementById('valMscm').textContent = extract(logMessage, "\\[mS/cm\\]\\s*([0-9.]+)");
    document.getElementById('valNtu').textContent = extract(logMessage, "\\[NTU\\]\\s*([0-9.]+)");
    document.getElementById('valMgl').textContent = extract(logMessage, "\\[mg/l\\]\\s*([0-9.]+)");
    document.getElementById('valMv').textContent = extract(logMessage, "\\[mV\\]\\s*([0-9.]+)");
}

async function inisialisasiGrafik() {
    try {
        const response = await fetch(GOOGLE_SHEET_API);
        const dataSet = await response.json();
        const dataTerbaru = dataSet.slice(-10);
        
        const labelWaktu = dataTerbaru.map(d => new Date(d.waktu).toLocaleTimeString());
        const dataSuhu = dataTerbaru.map(d => parseFloat(d.suhu) || 0);
        const dataPh = dataTerbaru.map(d => parseFloat(d.ph) || 0);

        const ctx = document.getElementById('sensorChart').getContext('2d');
        if(sensorChart) sensorChart.destroy(); 

        sensorChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labelWaktu,
                datasets: [
                    { label: 'Suhu (°C)', data: dataSuhu, borderColor: '#ff3333', tension: 0.4 },
                    { label: 'pH Air', data: dataPh, borderColor: 'rgba(255,255,255,0.6)', tension: 0.4 }
                ]
            },
            options: {
                responsive: true,
                plugins: { legend: { labels: { color: 'rgba(255,255,255,0.8)' } } },
                scales: {
                    x: { ticks: { color: 'rgba(255,255,255,0.5)' }, grid: {color: 'rgba(255,255,255,0.1)'} },
                    y: { ticks: { color: 'rgba(255,255,255,0.5)' }, grid: {color: 'rgba(255,255,255,0.1)'} }
                }
            }
        });
    } catch (error) { console.error("Gagal memuat data grafik:", error); }
}

function addLog(message, type = 'system') {
    const logBox = document.getElementById('logBox');
    if(!logBox) return;
    const p = document.createElement('p');
    p.textContent = message;
    p.className = `log-${type}`;
    logBox.appendChild(p);
    logBox.scrollTop = logBox.scrollHeight;
}

async function sendCustomPrompt() {
    const promptInput = document.getElementById('promptInput');
    const promptText = promptInput.value;
    if (!promptText.trim()) return;

    addLog(`[USER] > ${promptText}`, 'user');
    promptInput.value = '';

    try {
        const response = await fetch(`${BRIDGE_API_URL}/?prompt=${encodeURIComponent(promptText)}&token=${encodeURIComponent(sessionToken)}`);
        const data = await response.json();
        if (data.status === 200) { addLog(`[AI/SYS] ${data.message}`, 'system'); } 
        else { addLog(`[ERROR] ${data.message}`, 'error'); }
    } catch (error) {
        addLog(`[ERROR] Gagal menyambungkan transmisi perintah.`, 'error');
    }
}

document.getElementById('promptInput').addEventListener("keypress", (e) => { if (e.key === "Enter") sendCustomPrompt(); });