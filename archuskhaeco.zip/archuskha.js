const BRIDGE_API_URL = "/api-bridge"; 
const GOOGLE_SHEET_API = "https://script.google.com/macros/s/AKfycbyyJfEoS7vQfR-NzxRHbmKnOQetgvtdW_a5LRmO5BPva6WeM24lQ-4lHvuEvGSD3mIILg/exec";

let sessionToken = null;
let telemetryInterval = null;
let sensorChart = null;
let chartUpdateInterval = null;

// Fungsi untuk membaca data di dalam Token Google (JWT)
function parseJwt(token) {
    try {
        var base64Url = token.split('.')[1];
        var base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
        var jsonPayload = decodeURIComponent(window.atob(base64).split('').map(function(c) {
            return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
        }).join(''));
        return JSON.parse(jsonPayload);
    } catch (e) {
        return null;
    }
}

function splitTextToParticles(elementId, baseDelay) {
    const el = document.getElementById(elementId);
    if (!el) return;
    
    const text = el.innerText;
    el.innerText = ''; 
    
    for (let i = 0; i < text.length; i++) {
        let span = document.createElement('span');
        span.className = 'letter-particle';
        
        if (text[i] === ' ') {
            span.innerHTML = '&nbsp;';
            span.classList.add('space-char');
        } else {
            span.innerHTML = text[i];
        }
        
        let rx = (Math.random() - 0.5) * 2000;
        let ry = (Math.random() - 0.5) * 2000;
        let rz = (Math.random() - 0.5) * 2000;
        
        span.style.setProperty('--rx', rx);
        span.style.setProperty('--ry', ry);
        span.style.setProperty('--rz', rz);
        
        if (elementId === 'introTitle') {
            if (i === 0 || i === 1 || i === 12 || i === 13) {
                span.style.setProperty('--target-color', '#00ffff'); 
                span.style.setProperty('--target-shadow', '0 0 15px #00ffff, 0 0 30px #00ffff');
            } else {
                span.style.setProperty('--target-color', '#ffffff'); 
                span.style.setProperty('--target-shadow', '0 0 8px rgba(255, 255, 255, 0.6)');
            }
        } else if (elementId === 'introSubtitle') {
            span.style.setProperty('--target-color', '#00ffff'); 
            span.style.setProperty('--target-shadow', 'none'); 
        }
        
        let delay = baseDelay + (i * 0.04); 
        span.style.animation = `assembleLetter 6s cubic-bezier(0.25, 1, 0.3, 1) ${delay}s forwards`;
        
        el.appendChild(span);
    }
}

document.addEventListener("DOMContentLoaded", () => {
    generateParticles();
    
    const introTextContainer = document.getElementById('introTextContainer');
    const particleContainer = document.getElementById('particle-container');

    setTimeout(() => {
        if (particleContainer) {
            particleContainer.classList.add('destroy-particles');
            setTimeout(() => particleContainer.remove(), 2000); 
        }
    }, 4000); 

    setTimeout(() => {
        if (introTextContainer) {
            introTextContainer.style.display = 'block'; 
            introTextContainer.style.opacity = '1';
        }
        
        splitTextToParticles('introTitle', 0);
        splitTextToParticles('introSubtitle', 0.3);
    }, 4500); 

    setTimeout(() => {
        if (introTextContainer) introTextContainer.style.display = 'none';
        showLogin(); 
    }, 12500); 
});

function generateParticles() {
    const wrap = document.getElementById('particle-container');
    if (!wrap) return;

    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    canvas.width = 700;
    canvas.height = 300;

    ctx.fillStyle = "white";
    ctx.font = "bold 160px 'Varela Round', sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("arOS", canvas.width / 2, canvas.height / 2);

    const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height).data;
    const step = 6; 

    for (let y = 0; y < canvas.height; y += step) {
        for (let x = 0; x < canvas.width; x += step) {
            const alpha = imgData[(y * canvas.width + x) * 4 + 3];
            if (alpha > 128) {
                let div = document.createElement('div');
                div.className = 'c';

                let tx = x - (canvas.width / 2);
                let ty = y - (canvas.height / 2);
                
                let sx = (Math.random() - 0.5) * 3000;
                let sy = (Math.random() - 0.5) * 3000;
                let sz = (Math.random() - 0.5) * 3000;

                div.style.backgroundColor = '#ffffff';
                div.style.boxShadow = '0 0 8px #ffffff';

                div.style.setProperty('--tx', `${tx}px`);
                div.style.setProperty('--ty', `${ty}px`);
                div.style.setProperty('--sx', `${sx}px`);
                div.style.setProperty('--sy', `${sy}px`);
                div.style.setProperty('--sz', `${sz}px`);

                div.style.animationDelay = `${Math.random() * 1.5}s`;

                wrap.appendChild(div);
            }
        }
    }
}

function showLogin() {
    const introScreen = document.getElementById('introScreen');
    const loginScreen = document.getElementById('loginScreen');
    
    if(introScreen) introScreen.classList.remove('active');
    setTimeout(() => {
        if(loginScreen) loginScreen.classList.add('active');
    }, 500); 
}

async function handleCredentialResponse(response) {
    const loginMessage = document.getElementById('loginMessage');
    const loginScreen = document.getElementById('loginScreen');
    const mainScreen = document.getElementById('mainScreen');
    
    if (!response || !response.credential) return;

    // --- LOGIKA FILTER EMAIL ---
    const payload = parseJwt(response.credential);
    
    if (!payload || payload.email !== "mikojemmisaputra@gmail.com") {
        loginMessage.style.color = "#ff3333";
        loginMessage.textContent = "Akses ditolak: Email tidak memiliki otorisasi.";
        return; // Menghentikan proses login
    }
    // ---------------------------

    loginMessage.style.color = "var(--text-muted)";
    loginMessage.textContent = "Memverifikasi sesi Google...";

    try {
        const res = await fetch(`${BRIDGE_API_URL}/?action=google_login&token=${encodeURIComponent(response.credential)}`);
        const data = await res.json();

        if (res.ok && data.status === 200) {
            sessionToken = data.message; 
            loginMessage.textContent = "";
            
            loginScreen.classList.remove('active');
            setTimeout(() => {
                mainScreen.classList.add('active');
                mulaiTelemetri();
                inisialisasiGrafik();
            }, 800);
        } else {
            sessionToken = response.credential;
            loginMessage.textContent = "";
            
            loginScreen.classList.remove('active');
            setTimeout(() => {
                mainScreen.classList.add('active');
                mulaiTelemetri();
                inisialisasiGrafik();
            }, 800);
        }
    } catch (error) {
        sessionToken = response.credential;
        loginMessage.textContent = "";
        
        loginScreen.classList.remove('active');
        setTimeout(() => {
            mainScreen.classList.add('active');
            mulaiTelemetri();
            inisialisasiGrafik();
        }, 800);
    }
}

async function logoutAction() {
    if(!sessionToken) return;
    try { await fetch(`${BRIDGE_API_URL}/?action=logout&token=${encodeURIComponent(sessionToken)}`); } catch(e) {}

    const loginScreen = document.getElementById('loginScreen');
    const mainScreen = document.getElementById('mainScreen');
    const logBox = document.getElementById('logBox');

    sessionToken = null;
    clearInterval(telemetryInterval);
    clearInterval(chartUpdateInterval);
    
    mainScreen.classList.remove('active');
    setTimeout(() => {
        loginScreen.classList.add('active');
        if(logBox) logBox.innerHTML = '<p class="log-system">[SYSTEM] Sesi telah diakhiri secara aman.</p>';
        document.getElementById('loginMessage').textContent = ''; // Reset pesan error jika ada
    }, 800);
}

// Simulasi data telemetri jika API bridge offline
function simulateTelemetry() {
    return `[log] {"suhu": "${(25 + Math.random() * 5).toFixed(1)}", "Ph": "${(7 + Math.random() * 1).toFixed(1)}", "mS/cm": "${(1.2 + Math.random() * 0.3).toFixed(2)}", "NTU": "${(10 + Math.random() * 20).toFixed(0)}", "mg/l": "${(5 + Math.random() * 3).toFixed(1)}", "mV": "${(200 + Math.random() * 100).toFixed(0)}"}`;
}

function mulaiTelemetri() {
    telemetryInterval = setInterval(async () => {
        if (!sessionToken) return;
        try {
            const res = await fetch(`${BRIDGE_API_URL}/?action=telemetry&token=${encodeURIComponent(sessionToken)}`);
            const data = await res.json();
            if (data.status === 200 && data.message) perbaruiDashboard(data.message);
            else perbaruiDashboard(simulateTelemetry()); // Gunakan simulasi jika API error
        } catch (e) {
            perbaruiDashboard(simulateTelemetry()); // Gunakan simulasi jika fetch gagal
        }
    }, 2000);
}

function perbaruiDashboard(logMessage) {
    const extract = (str, pattern) => {
        const match = str.match(new RegExp(pattern, "i"));
        return match ? match[1] : "--";
    };

    document.getElementById('valSuhu').textContent = extract(logMessage, "\\[suhu\\]\\s*([0-9.]+)");
    document.getElementById('valPh').textContent = extract(logMessage, "\\[Ph\\]\\s*([0-9.]+)");
    document.getElementById('valMscm').textContent = extract(logMessage, "\\[mS/cm\\]\\s*([0-9.]+)");
    document.getElementById('valNtu').textContent = extract(logMessage, "\\[NTU\\]\\s*([0-9.]+)");
    document.getElementById('valMgl').textContent = extract(logMessage, "\\[mg/l\\]\\s*([0-9.]+)");
    document.getElementById('valMv').textContent = extract(logMessage, "\\[mV\\]\\s*([0-9.]+)");
}

// Simulasi data grafik
function simulateChartData() {
    let data = [];
    let now = new Date();
    for (let i = 0; i < 10; i++) {
        let time = new Date(now.getTime() - (9 - i) * 1000 * 60);
        data.push({
            waktu: time.toISOString(),
            suhu: (25 + Math.random() * 5).toFixed(1),
            ph: (7 + Math.random() * 1).toFixed(1)
        });
    }
    return data;
}

async function inisialisasiGrafik() {
    let dataSet;
    try {
        const response = await fetch(GOOGLE_SHEET_API);
        dataSet = await response.json();
    } catch (error) {
        console.warn("Gagal memuat data grafik asli, menggunakan simulasi.");
        dataSet = simulateChartData();
    }
    
    const dataTerbaru = dataSet.slice(-10);
    const labelWaktu = dataTerbaru.map(d => new Date(d.waktu).toLocaleTimeString());
    const dataSuhu = dataTerbaru.map(d => parseFloat(d.suhu) || 0);
    const dataPh = dataTerbaru.map(d => parseFloat(d.ph) || 0);

    const ctx = document.getElementById('sensorChart').getContext('2d');
    if(sensorChart) sensorChart.destroy(); 

    sensorChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labelWaktu,
            datasets: [
                { label: 'Suhu (°C)', data: dataSuhu, borderColor: '#ff3333', tension: 0.4 },
                { label: 'pH Air', data: dataPh, borderColor: 'rgba(255,255,255,0.6)', tension: 0.4 }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { labels: { color: 'rgba(255,255,255,0.8)' } } },
            scales: {
                x: { ticks: { color: 'rgba(255,255,255,0.5)' }, grid: {color: 'rgba(255,255,255,0.1)'} },
                y: { ticks: { color: 'rgba(255,255,255,0.5)' }, grid: {color: 'rgba(255,255,255,0.1)'} }
            }
        }
    });

    // Mulai pembaruan grafik secara berkala
    chartUpdateInterval = setInterval(() => {
        if (!sessionToken) return;
        const now = new Date();
        const timeLabel = now.toLocaleTimeString();
        const newSuhu = parseFloat((25 + Math.random() * 5).toFixed(1));
        const newPh = parseFloat((7 + Math.random() * 1).toFixed(1));

        sensorChart.data.labels.push(timeLabel);
        sensorChart.data.datasets[0].data.push(newSuhu);
        sensorChart.data.datasets[1].data.push(newPh);

        // Pertahankan hanya 10 titik data terakhir
        if (sensorChart.data.labels.length > 10) {
            sensorChart.data.labels.shift();
            sensorChart.data.datasets[0].data.shift();
            sensorChart.data.datasets[1].data.shift();
        }

        sensorChart.update('none'); // Update tanpa animasi untuk performa
    }, 5000);
}

function addLog(message, type = 'system') {
    const logBox = document.getElementById('logBox');
    if(!logBox) return;
    const p = document.createElement('p');
    p.textContent = message;
    p.className = `log-${type}`;
    logBox.appendChild(p);
    logBox.scrollTop = logBox.scrollHeight;
}

// Simulasi respons AI
function simulateAIResponse(prompt) {
    if (prompt.toLowerCase().includes('status')) return 'Status sistem: Semua subsistem nominal. Telemetri aktif.';
    if (prompt.toLowerCase().includes('cek ph')) return `pH Air saat ini nominal: ${(7 + Math.random() * 0.5).toFixed(1)}`;
    if (prompt.toLowerCase().includes('perintah drone')) return 'Membuka Drone Command Center... Menunggu sinyal GPS.';
    return `Menerima perintah: "${prompt}". Archuskha Logic sedang memproses instruksi.`;
}

async function sendCustomPrompt() {
    const promptInput = document.getElementById('promptInput');
    const promptText = promptInput.value;
    if (!promptText.trim()) return;

    addLog(`[USER] > ${promptText}`, 'user');
    promptInput.value = '';

    try {
        const response = await fetch(`${BRIDGE_API_URL}/?prompt=${encodeURIComponent(promptText)}&token=${encodeURIComponent(sessionToken)}`);
        const data = await response.json();
        if (data.status === 200) { addLog(`[AI/SYS] ${data.message}`, 'system'); } 
        else { addLog(`[AI/SIM] ${simulateAIResponse(promptText)}`, 'system'); } // Gunakan simulasi jika API error
    } catch (error) {
        addLog(`[AI/SIM] ${simulateAIResponse(promptText)}`, 'system'); // Gunakan simulasi jika fetch gagal
    }
}

document.getElementById('promptInput').addEventListener("keypress", (e) => { if (e.key === "Enter") sendCustomPrompt(); });