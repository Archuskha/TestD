const PROGRAM_API_URL = (() => {
    if (window.location.protocol === "file:" || !window.location.hostname) {
        return "http://localhost:8080";
    }
    return `${window.location.origin}/api-bridge`;
})();

const AROS_THEME_KEY = "arOSTheme";

function applyArOSTheme(theme) {
    const mode = theme === "light" ? "light" : "dark";
    document.body.classList.toggle("light-mode", mode === "light");
    document.body.classList.toggle("dark-mode", mode === "dark");

    const label = document.getElementById("themeLabel");
    const toggle = document.getElementById("themeToggle");
    if (label) label.textContent = mode === "light" ? "Light Mode" : "Dark Mode";
    if (toggle) toggle.setAttribute("aria-pressed", String(mode === "light"));
}

function initArOSTheme() {
    const savedTheme = localStorage.getItem(AROS_THEME_KEY) || localStorage.getItem("cianjurTheme") || "dark";
    applyArOSTheme(savedTheme);

    const toggle = document.getElementById("themeToggle");
    if (!toggle) return;
    toggle.addEventListener("click", () => {
        const nextTheme = document.body.classList.contains("light-mode") ? "dark" : "light";
        localStorage.setItem(AROS_THEME_KEY, nextTheme);
        localStorage.setItem("cianjurTheme", nextTheme);
        applyArOSTheme(nextTheme);
    });
}

function applyRoleNavigation(role) {
    const isMinecraftOnly = role === "MINECRAFT_ONLY";
    const deniedMessage = sessionStorage.getItem("arOSAccessDenied");
    document.body.classList.toggle("role-minecraft-only", isMinecraftOnly);
    document.querySelectorAll(".admin-only").forEach((el) => {
        el.style.display = isMinecraftOnly ? "none" : "";
    });

    if (!isMinecraftOnly) return;

    const pageTitle = document.querySelector(".page-copy h1");
    const pageSubtitle = document.querySelector(".page-copy p:last-child");
    const infoTitle = document.querySelector(".info-card h2");
    const infoParagraphs = document.querySelectorAll(".info-card p");

    if (pageTitle) pageTitle.textContent = "Menu Utama";
    if (pageSubtitle) pageSubtitle.textContent = deniedMessage || "Akses sesi tersedia untuk panel Minecraft Server.";
    if (infoTitle) infoTitle.textContent = "Akses Minecraft Server";
    infoParagraphs.forEach((p, index) => {
        p.textContent = index === 0
            ? "Akun ini memiliki role MINECRAFT_ONLY. Pilih Minecraft Server dari menu untuk masuk ke panel server."
            : "";
    });

    if (deniedMessage) sessionStorage.removeItem("arOSAccessDenied");
}

function parseJwt(token) {
    try {
        var base64Url = token.split('.')[1];
        var base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
        var jsonPayload = decodeURIComponent(window.atob(base64).split('').map(function(c) {
            return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
        }).join(''));
        return JSON.parse(jsonPayload);
    } catch (e) { return null; }
}

function splitTextToParticles(elementId, baseDelay) {
    const el = document.getElementById(elementId);
    if (!el) return;
    const text = el.innerText;
    el.innerText = ''; 
    for (let i = 0; i < text.length; i++) {
        let span = document.createElement('span');
        span.className = 'letter-particle';
        if (text[i] === ' ') { span.innerHTML = '&nbsp;'; span.classList.add('space-char'); } 
        else { span.innerHTML = text[i]; }
        
        let rx = (Math.random() - 0.5) * 2000;
        let ry = (Math.random() - 0.5) * 2000;
        let rz = (Math.random() - 0.5) * 2000;
        span.style.setProperty('--rx', rx);
        span.style.setProperty('--ry', ry);
        span.style.setProperty('--rz', rz);
        
        if (elementId === 'introTitle') {
            if (i === 0 || i === 1 || i === 12 || i === 13) {
                span.style.setProperty('--target-color', '#00ffff'); 
                span.style.setProperty('--target-shadow', '0 0 15px #00ffff, 0 0 30px #00ffff');
            } else {
                span.style.setProperty('--target-color', '#ffffff'); 
                span.style.setProperty('--target-shadow', '0 0 8px rgba(255, 255, 255, 0.6)');
            }
        } else {
            span.style.setProperty('--target-color', '#00ffff'); 
            span.style.setProperty('--target-shadow', 'none'); 
        }
        span.style.animation = `assembleLetter 6s cubic-bezier(0.25, 1, 0.3, 1) ${baseDelay + (i * 0.04)}s forwards`;
        el.appendChild(span);
    }
}

document.addEventListener("DOMContentLoaded", () => {
    initArOSTheme();

    const token = sessionStorage.getItem("arOSToken");
    const role = sessionStorage.getItem("arOSRole");
    applyRoleNavigation(role);

    // Jika sudah login
    if(token) {
        // Matikan animasi dan layar intro untuk sesi aktif
        const particleWrap = document.getElementById('particle-container');
        if(particleWrap) particleWrap.style.display = 'none';
        
        document.getElementById('introScreen').style.display = 'none';
        document.getElementById('loginScreen').classList.remove('active');
        document.getElementById('mainScreen').classList.add('active');
        return; 
    }

    // JIKA BELUM LOGIN: Mainkan animasi
    generateParticles();
    const introTextContainer = document.getElementById('introTextContainer');
    const particleContainer = document.getElementById('particle-container');

    setTimeout(() => {
        if (particleContainer) {
            particleContainer.classList.add('destroy-particles');
            setTimeout(() => particleContainer.remove(), 2000); 
        }
    }, 4000); 

    setTimeout(() => {
        if (introTextContainer) {
            introTextContainer.style.display = 'block'; 
            introTextContainer.style.opacity = '1';
        }
        splitTextToParticles('introTitle', 0);
        splitTextToParticles('introSubtitle', 0.3);
    }, 4500); 

    setTimeout(() => {
        if (introTextContainer) introTextContainer.style.display = 'none';
        showLogin(); 
    }, 12500); 
});

function generateParticles() {
    const wrap = document.getElementById('particle-container');
    if (!wrap) return;
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    canvas.width = 700; canvas.height = 300;
    ctx.fillStyle = "white"; ctx.font = "bold 160px 'Varela Round', sans-serif";
    ctx.textAlign = "center"; ctx.textBaseline = "middle";
    ctx.fillText("arOS", canvas.width / 2, canvas.height / 2);

    const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height).data;
    const step = 6; 
    for (let y = 0; y < canvas.height; y += step) {
        for (let x = 0; x < canvas.width; x += step) {
            const alpha = imgData[(y * canvas.width + x) * 4 + 3];
            if (alpha > 128) {
                let div = document.createElement('div');
                div.className = 'c';
                div.style.backgroundColor = '#ffffff'; div.style.boxShadow = '0 0 8px #ffffff';
                div.style.setProperty('--tx', `${x - (canvas.width / 2)}px`);
                div.style.setProperty('--ty', `${y - (canvas.height / 2)}px`);
                div.style.setProperty('--sx', `${(Math.random() - 0.5) * 3000}px`);
                div.style.setProperty('--sy', `${(Math.random() - 0.5) * 3000}px`);
                div.style.setProperty('--sz', `${(Math.random() - 0.5) * 3000}px`);
                div.style.animationDelay = `${Math.random() * 1.5}s`;
                wrap.appendChild(div);
            }
        }
    }
}

function showLogin() {
    document.getElementById('introScreen').classList.remove('active');
    setTimeout(() => document.getElementById('loginScreen').classList.add('active'), 500); 
}

async function handleCredentialResponse(response) {
    const loginMessage = document.getElementById('loginMessage');
    if (!response || !response.credential) return;

    const payload = parseJwt(response.credential);
    if (!payload || !payload.email) {
        loginMessage.style.color = "#ff3333";
        loginMessage.textContent = "Akses ditolak: Data otorisasi Google rusak.";
        return; 
    }

    loginMessage.style.color = "var(--text-muted)";
    loginMessage.textContent = "Memverifikasi otorisasi ke peladen pusat C#...";

    try {
        // MENGIRIM EMAIL KE BACKEND C# UNTUK VERIFIKASI (RBAC)
        const res = await fetch(`${PROGRAM_API_URL}/?action=verify_google&email=${encodeURIComponent(payload.email)}`);
        const data = await res.json();
        
        if (res.ok && data.status === 200) {
            sessionStorage.setItem("arOSToken", data.token);
            sessionStorage.setItem("arOSRole", data.role); // Simpan Hak Akses (SUPERADMIN / MINECRAFT_ONLY)
            
            loginMessage.style.color = "#00ffff";
            loginMessage.textContent = data.message;
            
            setTimeout(() => goToDashboard(data.role), 1000);
        } else {
            loginMessage.style.color = "#ff3333";
            loginMessage.textContent = data.message || "Akses Ditolak dari Server.";
            sessionStorage.removeItem("arOSToken");
            sessionStorage.removeItem("arOSRole");
        }
    } catch (error) {
        loginMessage.style.color = "#ff3333";
        loginMessage.textContent = "Koneksi ke backend keamanan gagal.";
    }
}

function goToDashboard(role) {
    applyRoleNavigation(role);
    document.getElementById('loginMessage').textContent = "";
    document.getElementById('loginScreen').classList.remove('active');
    setTimeout(() => document.getElementById('mainScreen').classList.add('active'), 800);
}

function logoutAction() {
    sessionStorage.removeItem("arOSToken");
    sessionStorage.removeItem("arOSRole");
    window.location.href = 'archuskha.html';
}

function addLog(message, type = 'system') {
    const logBox = document.getElementById('logBox');
    if(!logBox) return;
    const p = document.createElement('p'); p.textContent = message; p.className = `log-${type}`;
    logBox.appendChild(p); logBox.scrollTop = logBox.scrollHeight;
}

function simulateAIResponse(prompt) {
    if (prompt.toLowerCase().includes('status')) return 'Status sistem: Seluruh infrastruktur Cloud dan Edge Node stabil.';
    if (prompt.toLowerCase().includes('suhu cianjur')) return '[CMD] /cek_suhu';
    if (prompt.toLowerCase().includes('drone')) return '[CMD] /drone_wakeup';
    return `Menerima perintah: "${prompt}". Archuskha Logic sedang merumuskan matriks respon.`;
}

async function sendCustomPrompt() {
    const promptInput = document.getElementById('promptInput');
    const promptText = promptInput.value;
    if (!promptText.trim()) return;

    addLog(`[USER] > ${promptText}`, 'user');
    promptInput.value = '';

    try {
        const response = await fetch(`${PROGRAM_API_URL}/?prompt=${encodeURIComponent(promptText)}&token=${encodeURIComponent(sessionStorage.getItem("arOSToken"))}`);
        const data = await response.json();
        if (data.status === 200) addLog(`[AI/SYS] ${data.message}`, 'system'); 
        else addLog(`[AI/SIM] ${simulateAIResponse(promptText)}`, 'system'); 
    } catch (error) {
        addLog(`[AI/SIM] ${simulateAIResponse(promptText)}`, 'system');
    }
}

const pInput = document.getElementById('promptInput');
if(pInput) pInput.addEventListener("keypress", (e) => { if (e.key === "Enter") sendCustomPrompt(); });

function toggleMobileMenu() {
    const sidebar = document.querySelector('.sidebar');
    if (sidebar) {
        sidebar.classList.toggle('open');
    }
}

