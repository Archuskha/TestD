function splitTextToParticles(elementId, baseDelay) {
    const el = document.getElementById(elementId);
    if (!el) return;
    const text = el.innerText;
    el.innerText = "";
    for (let i = 0; i < text.length; i += 1) {
        const span = document.createElement("span");
        span.className = "letter-particle";
        span.textContent = text[i] === " " ? "\u00a0" : text[i];
        if (text[i] === " ") span.classList.add("space-char");
        span.style.setProperty("--rx", (Math.random() - 0.5) * 2000);
        span.style.setProperty("--ry", (Math.random() - 0.5) * 2000);
        span.style.setProperty("--rz", (Math.random() - 0.5) * 2000);
        if (elementId === "introTitle") {
            if (i === 0 || i === 1 || i === 12 || i === 13) {
                span.style.setProperty("--target-color", "#00ffff");
                span.style.setProperty("--target-shadow", "0 0 15px #00ffff, 0 0 30px #00ffff");
            } else {
                span.style.setProperty("--target-color", "#ffffff");
                span.style.setProperty("--target-shadow", "0 0 8px rgba(255, 255, 255, 0.6)");
            }
        } else {
            span.style.setProperty("--target-color", "#00ffff");
            span.style.setProperty("--target-shadow", "none");
        }
        span.style.animation = `assembleLetter 6s cubic-bezier(0.25, 1, 0.3, 1) ${baseDelay + (i * 0.04)}s forwards`;
        el.appendChild(span);
    }
}

function generateParticles() {
    const wrap = document.getElementById("particle-container");
    if (!wrap) return;
    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");
    canvas.width = 700;
    canvas.height = 300;
    ctx.fillStyle = "white";
    ctx.font = "bold 160px 'Varela Round', sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("arOS", canvas.width / 2, canvas.height / 2);

    const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height).data;
    for (let y = 0; y < canvas.height; y += 6) {
        for (let x = 0; x < canvas.width; x += 6) {
            const alpha = imgData[(y * canvas.width + x) * 4 + 3];
            if (alpha > 128) {
                const div = document.createElement("div");
                div.className = "c";
                div.style.backgroundColor = "#ffffff";
                div.style.boxShadow = "0 0 8px #ffffff";
                div.style.setProperty("--tx", `${x - (canvas.width / 2)}px`);
                div.style.setProperty("--ty", `${y - (canvas.height / 2)}px`);
                div.style.setProperty("--sx", `${(Math.random() - 0.5) * 3000}px`);
                div.style.setProperty("--sy", `${(Math.random() - 0.5) * 3000}px`);
                div.style.setProperty("--sz", `${(Math.random() - 0.5) * 3000}px`);
                div.style.animationDelay = `${Math.random() * 1.5}s`;
                wrap.appendChild(div);
            }
        }
    }
}

function showLogin() {
    document.getElementById("introScreen").classList.remove("active");
    setTimeout(() => document.getElementById("loginScreen").classList.add("active"), 500);
    setupGoogleLogin();
}

async function setupGoogleLogin() {
    const host = document.getElementById("googleSignInHost");
    const loginMessage = document.getElementById("loginMessage");
    if (!host || !loginMessage) return;

    try {
        const config = await arOSApiFetch("action=public_config");
        if (!config.googleClientId) {
            loginMessage.style.color = "#ff3333";
            loginMessage.textContent = "Google Client ID belum diisi di backend.";
            return;
        }

        const render = () => {
            if (!window.google?.accounts?.id) {
                setTimeout(render, 150);
                return;
            }
            window.google.accounts.id.initialize({
                client_id: config.googleClientId,
                callback: handleCredentialResponse,
                auto_select: false,
                cancel_on_tap_outside: true
            });
            window.google.accounts.id.renderButton(host, {
                type: "standard",
                shape: "rectangular",
                theme: "filled_black",
                text: "signin_with",
                size: "large",
                logo_alignment: "left"
            });
        };
        render();
    } catch (error) {
        loginMessage.style.color = "#ff3333";
        loginMessage.textContent = "Backend login belum dapat dihubungi.";
    }
}

async function handleCredentialResponse(response) {
    const loginMessage = document.getElementById("loginMessage");
    if (!response?.credential) return;

    loginMessage.style.color = "var(--text-muted)";
    loginMessage.textContent = "Memverifikasi credential Google ke backend...";

    try {
        const data = await arOSApiFetch("action=verify_google", {
            method: "POST",
            body: JSON.stringify({ credential: response.credential })
        });
        sessionStorage.setItem("arOSToken", data.token);
        sessionStorage.setItem("arOSRole", data.role);
        sessionStorage.setItem("arOSEmail", data.email);
        sessionStorage.setItem("arOSName", data.name || "");
        sessionStorage.setItem("arOSPicture", data.picture || "");
        sessionStorage.setItem("arOSExpiresAt", data.expiresAtUtc || "");
        loginMessage.style.color = "#00ffff";
        loginMessage.textContent = data.message || "Login berhasil.";
        setTimeout(showMainScreen, 600);
    } catch (error) {
        loginMessage.style.color = "#ff3333";
        loginMessage.textContent = error.message || "Login gagal.";
        clearLocalSession();
    }
}

async function showMainScreen() {
    document.getElementById("particle-container")?.remove();
    document.getElementById("introScreen").style.display = "none";
    document.getElementById("loginScreen").classList.remove("active");
    document.getElementById("mainScreen").classList.add("active");
    renderSidebar("home");
    const session = await requireAuth(["OWNER", "ADMIN", "GUEST"], "archuskha.html");
    if (!session) return;

    const roleLine = document.getElementById("homeRoleLine");
    if (roleLine) roleLine.textContent = `[ROLE] ${session.role} - ${session.email}`;
    loadHomeTelemetry();
}

async function loadHomeTelemetry() {
    try {
        const latest = await arOSApiFetch("action=telemetry_latest&sector=A");
        const line = document.getElementById("homeLastSyncLine");
        if (line) line.textContent = `[TELEMETRY] Sinkronisasi terakhir: ${latest.data?.timestampLocal || "Data belum tersedia"} | Sumber: ${latest.data?.source || "-"}`;
    } catch (error) {
        const line = document.getElementById("homeLastSyncLine");
        if (line) line.textContent = `[TELEMETRY] ${error.data?.code === "TELEMETRY_UNAVAILABLE" ? "Data belum tersedia" : "Perlu konfigurasi"}.`;
    }
}

document.addEventListener("DOMContentLoaded", async () => {
    document.getElementById("mobileMenuBtn")?.addEventListener("click", toggleMobileMenu);
    document.getElementById("logoutBtn")?.addEventListener("click", logoutAction);
    document.getElementById("openDashboardBtn")?.addEventListener("click", () => { window.location.href = "cirata.html"; });
    document.getElementById("openMapBtn")?.addEventListener("click", () => { window.location.href = "lokasi.html"; });

    if (arOSToken()) {
        await showMainScreen();
        return;
    }

    generateParticles();
    const introTextContainer = document.getElementById("introTextContainer");
    const particleContainer = document.getElementById("particle-container");

    setTimeout(() => {
        particleContainer?.classList.add("destroy-particles");
        setTimeout(() => particleContainer?.remove(), 2000);
    }, 4000);

    setTimeout(() => {
        if (introTextContainer) {
            introTextContainer.style.display = "block";
            introTextContainer.style.opacity = "1";
        }
        splitTextToParticles("introTitle", 0);
        splitTextToParticles("introSubtitle", 0.3);
    }, 4500);

    setTimeout(() => {
        if (introTextContainer) introTextContainer.style.display = "none";
        showLogin();
    }, 12500);
});
