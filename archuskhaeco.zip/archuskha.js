const BRIDGE_API_URL = "/api-bridge"; 
const GOOGLE_SHEET_API = "https://script.google.com/macros/s/AKfycbyyJfEoS7vQfR-NzxRHbmKnOQetgvtdW_a5LRmO5BPva6WeM24lQ-4lHvuEvGSD3mIILg/exec";

let sessionToken = null;
let telemetryInterval = null;
let sensorChart = null;

const loginScreen = document.getElementById('loginScreen');
const mainScreen = document.getElementById('mainScreen');
const passwordInput = document.getElementById('passwordInput');
const loginBtn = document.getElementById('loginBtn');
const loginMessage = document.getElementById('loginMessage');
const logBox = document.getElementById('logBox');
const promptInput = document.getElementById('promptInput');
const sendBtn = document.getElementById('sendBtn');

// --- FUNGSI OTORISASI & ANIMASI ---
async function loginAction() {
    const pwd = passwordInput.value;
    if (!pwd) return;

    loginBtn.disabled = true;
    loginMessage.style.color = "var(--text-muted)";
    loginMessage.textContent = "Memverifikasi Kredensial...";

    try {
        const response = await fetch(`${BRIDGE_API_URL}/?action=login&password=${encodeURIComponent(pwd)}`);
        const data = await response.json();

        if (response.ok && data.status === 200) {
            sessionToken = data.message;
            passwordInput.value = "";
            loginMessage.textContent = "";
            
            loginScreen.classList.add('fade-out');
            setTimeout(() => {
                loginScreen.style.display = "none";
                loginScreen.classList.remove('fade-out');
                
                mainScreen.style.display = "block";
                mainScreen.classList.add('slide-up');
                
                mulaiTelemetri();
                inisialisasiGrafik();
            }, 500);

        } else {
            loginMessage.style.color = "var(--danger)";
            loginMessage.textContent = data.message || "Akses ditolak.";
        }
    } catch (error) {
        loginMessage.style.color = "var(--danger)";
        loginMessage.textContent = "Koneksi ke backend terputus.";
    } finally {
        loginBtn.disabled = false;
    }
}

passwordInput.addEventListener("keypress", (e) => { if (e.key === "Enter") loginAction(); });

async function logoutAction() {
    if(!sessionToken) return;
    try { await fetch(`${BRIDGE_API_URL}/?action=logout&token=${encodeURIComponent(sessionToken)}`); } catch(e) {}

    sessionToken = null;
    clearInterval(telemetryInterval);
    
    mainScreen.style.display = "none";
    mainScreen.classList.remove('slide-up');
    loginScreen.style.display = "block";
    logBox.innerHTML = '<p class="log-system">[SYSTEM] Sesi telah diakhiri secara aman.</p>';
}

// --- FUNGSI TELEMETRI WAKTU NYATA (REAL-TIME) ---
function mulaiTelemetri() {
    telemetryInterval = setInterval(async () => {
        if (!sessionToken) return;
        try {
            const res = await fetch(`${BRIDGE_API_URL}/?action=telemetry&token=${encodeURIComponent(sessionToken)}`);
            const data = await res.json();
            
            if (data.status === 200 && data.message) {
                perbaruiDashboard(data.message);
            }
        } catch (e) { /* Abaikan kegagalan jaringan sementara */ }
    }, 2000); // Polling setiap 2 detik
}

function perbaruiDashboard(logMessage) {
    const extract = (str, pattern) => {
        const match = str.match(new RegExp(pattern, "i"));
        return match ? match[1] : "--";
    };

    document.getElementById('valSuhu').textContent = extract(logMessage, "\\[suhu\\]\\s*([0-9.]+)");
    document.getElementById('valPh').textContent = extract(logMessage, "\\[Ph\\]\\s*([0-9.]+)");
    document.getElementById('valMscm').textContent = extract(logMessage, "\\[mS/cm\\]\\s*([0-9.]+)");
    document.getElementById('valNtu').textContent = extract(logMessage, "\\[NTU\\]\\s*([0-9.]+)");
    document.getElementById('valMgl').textContent = extract(logMessage, "\\[mg/l\\]\\s*([0-9.]+)");
    document.getElementById('valMv').textContent = extract(logMessage, "\\[mV\\]\\s*([0-9.]+)");
}

// --- FUNGSI GRAFIK HISTORIS (CHART.JS) ---
async function inisialisasiGrafik() {
    try {
        const response = await fetch(GOOGLE_SHEET_API);
        const dataSet = await response.json();

        // Mengambil 10 data terakhir
        const dataTerbaru = dataSet.slice(-10);
        const labelWaktu = dataTerbaru.map(d => new Date(d.waktu).toLocaleTimeString());
        const dataSuhu = dataTerbaru.map(d => parseFloat(d.suhu) || 0);
        const dataPh = dataTerbaru.map(d => parseFloat(d.ph) || 0);

        const ctx = document.getElementById('sensorChart').getContext('2d');
        if(sensorChart) sensorChart.destroy(); 

        sensorChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labelWaktu,
                datasets: [
                    { label: 'Suhu (°C)', data: dataSuhu, borderColor: '#ef4444', tension: 0.4 },
                    { label: 'pH Air', data: dataPh, borderColor: '#3b82f6', tension: 0.4 }
                ]
            },
            options: {
                responsive: true,
                plugins: { legend: { labels: { color: '#f8fafc' } } },
                scales: {
                    x: { ticks: { color: '#94a3b8' } },
                    y: { ticks: { color: '#94a3b8' } }
                }
            }
        });
    } catch (error) {
        console.error("Gagal memuat data grafik:", error);
    }
}

// --- FUNGSI TERMINAL / KONSOL ---
function addLog(message, type = 'system') {
    const p = document.createElement('p');
    p.textContent = message;
    p.className = `log-${type}`;
    logBox.appendChild(p);
    logBox.scrollTop = logBox.scrollHeight;
}

async function sendCustomPrompt() {
    const promptText = promptInput.value;
    if (!promptText.trim() || !sessionToken) return;

    promptInput.disabled = true;
    sendBtn.disabled = true;
    addLog(`[USER] > ${promptText}`, 'user');
    promptInput.value = '';

    try {
        const response = await fetch(`${BRIDGE_API_URL}/?prompt=${encodeURIComponent(promptText)}&token=${encodeURIComponent(sessionToken)}`);
        const data = await response.json();
        
        if (data.status === 200) { addLog(`[AI/SYS] ${data.message}`, 'system'); } 
        else { addLog(`[ERROR] ${data.message}`, 'error'); }
    } catch (error) {
        addLog(`[ERROR] Gagal menyambungkan transmisi perintah.`, 'error');
    } finally {
        promptInput.disabled = false;
        sendBtn.disabled = false;
        promptInput.focus();
    }
}

promptInput.addEventListener("keypress", (e) => { if (e.key === "Enter") sendCustomPrompt(); });