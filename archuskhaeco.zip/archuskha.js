// GANTI URL INI SESUAI DOMAIN LU. Kalo lokal biarin aja.
const BRIDGE_API_URL = "https://archuskha.online/api-bridge"; 

// Variabel Sesi
let sessionToken = null;

// Element UI
const loginScreen = document.getElementById('loginScreen');
const mainScreen = document.getElementById('mainScreen');
const passwordInput = document.getElementById('passwordInput');
const loginBtn = document.getElementById('loginBtn');
const loginMessage = document.getElementById('loginMessage');

const logBox = document.getElementById('logBox');
const promptInput = document.getElementById('promptInput');
const sendBtn = document.getElementById('sendBtn');

// --- FUNGSI LOGIN ---
async function loginAction() {
    const pwd = passwordInput.value;
    if (!pwd) return;

    loginBtn.disabled = true;
    loginMessage.style.color = "var(--text-muted)";
    loginMessage.textContent = "Memverifikasi...";

    try {
        const response = await fetch(`${BRIDGE_API_URL}/?action=login&password=${encodeURIComponent(pwd)}`);
        const data = await response.json();

        if (data.status === 200) {
            // Berhasil Login, simpan token
            sessionToken = data.message;
            passwordInput.value = "";
            loginMessage.textContent = "";
            
            // Pindah Layar
            loginScreen.style.display = "none";
            mainScreen.style.display = "block";
            promptInput.focus();
        } else {
            // Error (Salah sandi / Dipakai orang lain)
            loginMessage.style.color = "var(--danger)";
            loginMessage.textContent = data.message;
        }
    } catch (error) {
        loginMessage.style.color = "var(--danger)";
        loginMessage.textContent = "Server tidak merespon. Cek Bridge/Nginx!";
        console.error(error);
    } finally {
        loginBtn.disabled = false;
    }
}

// Biar pencet enter bisa langsung login
passwordInput.addEventListener("keypress", function(event) {
    if (event.key === "Enter") {
        event.preventDefault();
        loginBtn.click();
    }
});

// --- FUNGSI LOGOUT ---
async function logoutAction() {
    if(!sessionToken) return;
    
    try {
        await fetch(`${BRIDGE_API_URL}/?action=logout&token=${encodeURIComponent(sessionToken)}`);
    } catch(e) {} // Cuekin error, yang penting udah di-clear di lokal

    sessionToken = null;
    mainScreen.style.display = "none";
    loginScreen.style.display = "block";
    logBox.innerHTML = '<p class="log-system">[SYSTEM] Archuskha Web Panel Terhubung Secara Aman.</p>';
}

// Auto-Logout kalau user nyesel ngeclose tab browser tanpa pencet tombol logout
window.addEventListener('beforeunload', function() {
    if (sessionToken) {
        // Pake keepalive biar fetch tetep jalan di background walau tab ditutup
        fetch(`${BRIDGE_API_URL}/?action=logout&token=${encodeURIComponent(sessionToken)}`, { keepalive: true });
    }
});

// --- FUNGSI CHAT KE AI ---
function addLog(message, type = 'system') {
    const p = document.createElement('p');
    p.textContent = message;
    p.className = `log-${type}`;
    logBox.appendChild(p);
    logBox.scrollTop = logBox.scrollHeight;
}

async function sendRequestToBridge(promptText) {
    if (!promptText.trim() || !sessionToken) return;

    promptInput.disabled = true;
    sendBtn.disabled = true;
    addLog(`[USER] Mengirim: "${promptText}"`, 'user');

    try {
        // Nambahin parameter TOKEN di URL
        const response = await fetch(`${BRIDGE_API_URL}/?prompt=${encodeURIComponent(promptText)}&token=${encodeURIComponent(sessionToken)}`);
        const data = await response.json();
        
        if (data.status === 200) {
            addLog(`[BRIDGE] Sukses diteruskan ke AI.`, 'system');
        } else if (data.status === 401) {
            // Sesi habis / ditendang
            addLog(`[ERROR] ${data.message}`, 'error');
            alert("Sesi Anda telah kedaluwarsa atau diakhiri.");
            logoutAction(); // Paksa balik ke layar login
        } else {
            addLog(`[ERROR] ${data.message}`, 'error');
        }
    } catch (error) {
        addLog(`[ERROR] Gagal nyambung ke server Bridge.`, 'error');
    } finally {
        promptInput.disabled = false;
        sendBtn.disabled = false;
        promptInput.focus();
    }
}

function sendCustomPrompt() {
    sendRequestToBridge(promptInput.value);
    promptInput.value = '';
}

promptInput.addEventListener("keypress", function(event) {
    if (event.key === "Enter") {
        event.preventDefault();
        sendBtn.click();
    }
});