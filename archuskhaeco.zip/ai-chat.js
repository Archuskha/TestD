(() => {
    let chatRoot = null;
    let historyLoaded = false;

    function currentSector() {
        const activeButton = document.querySelector("[data-sector-button].active");
        const querySector = new URLSearchParams(window.location.search).get("sector");
        return (activeButton?.dataset.sectorButton || querySector || "A").toUpperCase() === "B" ? "B" : "A";
    }

    function mountChat() {
        if (chatRoot || !window.arOSToken?.()) return;

        chatRoot = document.createElement("div");
        chatRoot.className = "ai-chat-root";
        chatRoot.innerHTML = `
            <button class="ai-chat-launcher" type="button" aria-label="Buka arOS Environment AI" aria-expanded="false">
                <span aria-hidden="true">AI</span>
            </button>
            <section class="ai-chat-panel" aria-label="arOS Environment AI" hidden>
                <header class="ai-chat-header">
                    <div>
                        <strong>arOS Environment AI</strong>
                        <span>Analisis monitoring, tanpa kontrol perangkat</span>
                    </div>
                    <div class="ai-chat-actions">
                        <button type="button" data-ai-reset aria-label="Reset history AI">Reset</button>
                        <button type="button" data-ai-close aria-label="Tutup chat AI">&times;</button>
                    </div>
                </header>
                <div class="ai-chat-messages" data-ai-messages aria-live="polite"></div>
                <form class="ai-chat-form" data-ai-form>
                    <label class="sr-only" for="aiChatInput">Pertanyaan monitoring</label>
                    <textarea id="aiChatInput" maxlength="2000" rows="2" placeholder="Tanyakan kondisi telemetry..." required></textarea>
                    <button type="submit" data-ai-send>Kirim</button>
                </form>
            </section>
        `;
        document.body.appendChild(chatRoot);

        chatRoot.querySelector(".ai-chat-launcher").addEventListener("click", togglePanel);
        chatRoot.querySelector("[data-ai-close]").addEventListener("click", closePanel);
        chatRoot.querySelector("[data-ai-reset]").addEventListener("click", resetHistory);
        chatRoot.querySelector("[data-ai-form]").addEventListener("submit", sendMessage);
        updateKeyboardOffset();
    }

    function unmountChat() {
        chatRoot?.remove();
        chatRoot = null;
        historyLoaded = false;
        document.documentElement.style.removeProperty("--ai-keyboard-offset");
    }

    async function togglePanel() {
        if (!chatRoot) return;
        const panel = chatRoot.querySelector(".ai-chat-panel");
        const willOpen = panel.hidden;
        panel.hidden = !willOpen;
        chatRoot.querySelector(".ai-chat-launcher").setAttribute("aria-expanded", String(willOpen));
        if (willOpen) {
            await loadHistory();
            chatRoot.querySelector("textarea").focus({ preventScroll: true });
        }
    }

    function closePanel() {
        if (!chatRoot) return;
        chatRoot.querySelector(".ai-chat-panel").hidden = true;
        chatRoot.querySelector(".ai-chat-launcher").setAttribute("aria-expanded", "false");
        chatRoot.querySelector(".ai-chat-launcher").focus();
    }

    async function loadHistory() {
        if (!chatRoot || historyLoaded) return;
        const messages = chatRoot.querySelector("[data-ai-messages]");
        messages.replaceChildren();
        appendMessage("system", "Memuat history session...");
        try {
            const payload = await arOSApiFetch("action=ai_history");
            messages.replaceChildren();
            const items = payload.data || [];
            if (!items.length) {
                appendMessage("system", "Tanyakan kondisi telemetry Sektor A atau B.");
            } else {
                items.forEach((item) => appendMessage(item.role, item.message));
            }
            historyLoaded = true;
        } catch (error) {
            messages.replaceChildren();
            appendMessage("error", error.message || "History AI belum dapat dimuat.");
        }
    }

    async function sendMessage(event) {
        event.preventDefault();
        if (!chatRoot) return;
        const input = chatRoot.querySelector("textarea");
        const sendButton = chatRoot.querySelector("[data-ai-send]");
        const message = input.value.trim();
        if (!message) return;

        appendMessage("user", message);
        input.value = "";
        input.disabled = true;
        sendButton.disabled = true;
        const pending = appendMessage("system", "AI sedang menganalisis telemetry...");
        try {
            const payload = await arOSApiFetch("action=ai_chat", {
                method: "POST",
                body: JSON.stringify({ message, sector: currentSector() })
            });
            pending.remove();
            appendMessage("assistant", payload.data?.message || "AI tidak mengembalikan jawaban.");
            historyLoaded = true;
        } catch (error) {
            pending.remove();
            appendMessage("error", error.message || "AI sementara tidak tersedia.");
        } finally {
            input.disabled = false;
            sendButton.disabled = false;
            input.focus({ preventScroll: true });
        }
    }

    async function resetHistory() {
        if (!chatRoot) return;
        const button = chatRoot.querySelector("[data-ai-reset]");
        button.disabled = true;
        try {
            await arOSApiFetch("action=ai_reset", { method: "POST" });
            const messages = chatRoot.querySelector("[data-ai-messages]");
            messages.replaceChildren();
            appendMessage("system", "History AI untuk session ini sudah dihapus.");
            historyLoaded = true;
        } catch (error) {
            appendMessage("error", error.message || "History AI gagal direset.");
        } finally {
            button.disabled = false;
        }
    }

    function appendMessage(role, text) {
        const messages = chatRoot?.querySelector("[data-ai-messages]");
        if (!messages) return document.createElement("div");
        const item = document.createElement("div");
        item.className = `ai-chat-message ${role || "system"}`;
        item.textContent = text || "";
        messages.appendChild(item);
        messages.scrollTop = messages.scrollHeight;
        return item;
    }

    function updateKeyboardOffset() {
        if (!window.visualViewport) return;
        const keyboardHeight = Math.max(
            0,
            window.innerHeight - window.visualViewport.height - window.visualViewport.offsetTop
        );
        document.documentElement.style.setProperty("--ai-keyboard-offset", `${keyboardHeight}px`);
    }

    window.addEventListener("aros:authenticated", mountChat);
    window.addEventListener("aros:session-cleared", unmountChat);
    window.visualViewport?.addEventListener("resize", updateKeyboardOffset);
    window.visualViewport?.addEventListener("scroll", updateKeyboardOffset);
})();
