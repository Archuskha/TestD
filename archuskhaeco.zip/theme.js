(() => {
    const STORAGE_KEY = "arOSTheme";
    const VALID_MODES = new Set(["dark", "light", "system"]);
    const systemTheme = window.matchMedia("(prefers-color-scheme: light)");

    function readPreference() {
        try {
            const saved = localStorage.getItem(STORAGE_KEY) || "system";
            return VALID_MODES.has(saved) ? saved : "system";
        } catch {
            return "system";
        }
    }

    function resolvedTheme(mode) {
        return mode === "system" ? (systemTheme.matches ? "light" : "dark") : mode;
    }

    function syncControls() {
        const mode = document.documentElement.dataset.themePreference || "system";
        document.querySelectorAll("[data-theme-select]").forEach((select) => {
            select.value = mode;
        });
    }

    function apply(mode, persist = true) {
        const preference = VALID_MODES.has(mode) ? mode : "system";
        const resolved = resolvedTheme(preference);
        document.documentElement.dataset.themePreference = preference;
        document.documentElement.dataset.theme = resolved;
        if (persist) {
            try {
                localStorage.setItem(STORAGE_KEY, preference);
            } catch {
            }
        }
        syncControls();
        window.dispatchEvent(new CustomEvent("aros:themechange", {
            detail: { mode: preference, resolved }
        }));
    }

    document.addEventListener("change", (event) => {
        if (event.target.matches?.("[data-theme-select]")) {
            apply(event.target.value);
        }
    });

    systemTheme.addEventListener?.("change", () => {
        if ((document.documentElement.dataset.themePreference || "system") === "system") {
            apply("system", false);
        }
    });

    window.arOSTheme = { apply, syncControls };
    apply(readPreference(), false);
    document.addEventListener("DOMContentLoaded", syncControls);
})();
