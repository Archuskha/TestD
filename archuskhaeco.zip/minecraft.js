// [PERBAIKAN] Memastikan path endpoint dieksekusi dari root URL web server Nginx Anda
const API_BASE_URL = "/api-mc"; 

document.addEventListener("DOMContentLoaded", () => {
    if (!sessionStorage.getItem("arOSToken")) {
        window.location.href = 'archuskha.html';
        return;
    }
    
    // Memuat daftar isi direktori secara otomatis saat halaman dibuka
    loadFileList('mod');
    loadFileList('datapack');
});

function toggleMobileMenu() {
    const sidebar = document.querySelector('.sidebar');
    if (sidebar) sidebar.classList.toggle('open');
}

function logoutAction() {
    sessionStorage.removeItem("arOSToken");
    window.location.href = 'archuskha.html';
}

function formatBytes(bytes, decimals = 2) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

// === FUNGSI MEMUAT DAFTAR FILE ===
async function loadFileList(type) {
    const listContainer = document.getElementById(type === 'mod' ? 'modFileList' : 'datapackFileList');
    listContainer.innerHTML = '<p style="padding: 10px; color: var(--text-muted); font-size: 0.8rem;">Mensinkronisasi direktori server...</p>';
    
    try {
        const response = await fetch(`${API_BASE_URL}/list?type=${type}`, {
            headers: { 'Authorization': 'Bearer ' + sessionStorage.getItem("arOSToken") }
        });
        
        if (!response.ok) throw new Error("Gagal mengambil data");
        const files = await response.json();
        
        listContainer.innerHTML = ''; 
        
        if (files.length === 0) {
            listContainer.innerHTML = '<p style="padding: 10px; color: var(--text-muted); font-size: 0.8rem;">Direktori kosong.</p>';
            return;
        }

        files.forEach(file => {
            const item = document.createElement('div');
            item.className = 'file-item';
            item.innerHTML = `
                <div class="file-info">
                    <span class="file-name">${file.name}</span>
                    <span class="file-meta">${formatBytes(file.size)} • Diubah: ${file.date}</span>
                </div>
                <button class="btn-download-small" onclick="downloadFile('${type}', '${file.name}')">Unduh</button>
            `;
            listContainer.appendChild(item);
        });
    } catch (error) {
        listContainer.innerHTML = '<p style="padding: 10px; color: #ff3333; font-size: 0.8rem;">Koneksi backend gagal. Pastikan diakses via HTTP.</p>';
    }
}

// === FUNGSI UNDUH FILE ===
function downloadFile(type, fileName) {
    const url = `${API_BASE_URL}/download?type=${type}&file=${encodeURIComponent(fileName)}`;
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName; 
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
}

// === FUNGSI UNGGAH (DENGAN PROGRESS BAR) ===
async function uploadMinecraftFile(type) {
    const inputId = type === 'mod' ? 'modFileInput' : 'datapackFileInput';
    const statusId = type === 'mod' ? 'modUploadStatus' : 'datapackUploadStatus';
    const progressContainerId = type === 'mod' ? 'modProgressContainer' : 'datapackProgressContainer';
    const progressBarId = type === 'mod' ? 'modProgressBar' : 'datapackProgressBar';
    
    const fileInput = document.getElementById(inputId);
    const statusEl = document.getElementById(statusId);
    const progContainer = document.getElementById(progressContainerId);
    const progBar = document.getElementById(progressBarId);

    if (fileInput.files.length === 0) {
        statusEl.style.color = "#ff3333";
        statusEl.textContent = "Sistem menolak: Pilih minimal satu file.";
        return;
    }

    fileInput.disabled = true;
    progContainer.style.display = "block";
    
    for (let i = 0; i < fileInput.files.length; i++) {
        const file = fileInput.files[i];
        statusEl.style.color = "var(--text-muted)";
        statusEl.textContent = `Mentransmisikan file (${i+1}/${fileInput.files.length}): ${file.name}...`;
        progBar.style.width = "0%";

        await new Promise((resolve, reject) => {
            const xhr = new XMLHttpRequest();
            xhr.open('POST', `${API_BASE_URL}/upload`, true);
            
            xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("arOSToken"));
            xhr.setRequestHeader('X-File-Name', encodeURIComponent(file.name));
            xhr.setRequestHeader('X-Target-Type', type);
            xhr.setRequestHeader('Content-Type', 'application/octet-stream');

            xhr.upload.onprogress = function(e) {
                if (e.lengthComputable) {
                    const percentComplete = (e.loaded / e.total) * 100;
                    progBar.style.width = percentComplete + '%';
                }
            };

            xhr.onload = function() {
                if (xhr.status === 200) {
                    resolve();
                } else {
                    reject(`Error ${xhr.status}`);
                }
            };

            xhr.onerror = function() { reject("Koneksi terputus."); };
            xhr.send(file);
        }).catch(err => {
            statusEl.style.color = "#ff3333";
            statusEl.textContent = `[GAGAL] Transmisi dibatalkan: ${err}`;
            fileInput.disabled = false;
            throw new Error("Upload aborted"); 
        });
    }

    statusEl.style.color = "#00ffff";
    statusEl.textContent = `[BERHASIL] ${fileInput.files.length} file telah direplikasi ke server.`;
    
    setTimeout(() => {
        progContainer.style.display = "none";
        progBar.style.width = "0%";
    }, 2000);

    fileInput.value = "";
    fileInput.disabled = false;
    
    loadFileList(type);
}