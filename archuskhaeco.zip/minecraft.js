const API_BASE_URL = "/api-mc"; 

document.addEventListener("DOMContentLoaded", () => {
    const token = sessionStorage.getItem("arOSToken");
    const role = sessionStorage.getItem("arOSRole");

    if (!token) {
        window.location.href = 'archuskha.html';
        return;
    }

    // [FITUR BARU] Menyembunyikan menu lain jika user adalah mahasiswa (Minecraft Only)
    if (role === "MINECRAFT_ONLY") {
        const parentMenus = document.querySelectorAll('.parent-menu');
        parentMenus.forEach(menu => {
            if (!menu.textContent.includes('Minecraft Server')) {
                menu.style.display = 'none'; // Sembunyikan tombol navigasi lain
            }
        });
    }

    loadFileList('mod');
    loadFileList('datapack');
    
    checkServerStatus();
    setInterval(checkServerStatus, 3000);
    
    fetchServerLog();
    setInterval(fetchServerLog, 3000);
});

function toggleMobileMenu() {
    const sidebar = document.querySelector('.sidebar');
    if (sidebar) sidebar.classList.toggle('open');
}

function logoutAction() {
    sessionStorage.removeItem("arOSToken");
    sessionStorage.removeItem("arOSRole");
    window.location.href = 'archuskha.html';
}

function formatBytes(bytes, decimals = 2) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

async function loadFileList(type) {
    const listContainer = document.getElementById(type === 'mod' ? 'modFileList' : 'datapackFileList');
    listContainer.innerHTML = '<p style="padding: 10px; color: var(--text-muted); font-size: 0.8rem;">Mensinkronisasi direktori server...</p>';
    
    try {
        const response = await fetch(`${API_BASE_URL}/list?type=${type}`, {
            headers: { 'Authorization': 'Bearer ' + sessionStorage.getItem("arOSToken") }
        });
        
        if (!response.ok) throw new Error("Gagal mengambil data");
        const files = await response.json();
        
        listContainer.innerHTML = ''; 
        
        if (files.length === 0) {
            listContainer.innerHTML = '<p style="padding: 10px; color: var(--text-muted); font-size: 0.8rem;">Direktori kosong.</p>';
            return;
        }

        files.forEach(file => {
            const item = document.createElement('div');
            item.className = 'file-item';
            item.innerHTML = `
                <div class="file-info">
                    <span class="file-name">${file.name}</span>
                    <span class="file-meta">${formatBytes(file.size)} • Diubah: ${file.date}</span>
                </div>
                <div style="display: flex; gap: 8px;">
                    <button class="btn-download-small" onclick="downloadFile('${type}', '${file.name}')">Unduh</button>
                    <button style="background: #ff3333; color: white; border: none; padding: 5px 10px; border-radius: 4px; cursor: pointer; font-size: 0.8rem;" onclick="deleteFile('${type}', '${file.name}')">Hapus</button>
                </div>
            `;
            listContainer.appendChild(item);
        });
    } catch (error) {
        listContainer.innerHTML = '<p style="padding: 10px; color: #ff3333; font-size: 0.8rem;">Koneksi backend gagal. Pastikan diakses via HTTP.</p>';
    }
}

function downloadFile(type, fileName) {
    const url = `${API_BASE_URL}/download?type=${type}&file=${encodeURIComponent(fileName)}`;
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName; 
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
}

async function deleteFile(type, fileName) {
    const konfirmasi = confirm(`Apakah Anda yakin ingin menghapus file "${fileName}"?\nTindakan ini tidak dapat dibatalkan. (Ya/Tidak)`);
    if (!konfirmasi) return;

    try {
        const response = await fetch(`${API_BASE_URL}/delete?type=${type}&file=${encodeURIComponent(fileName)}`, {
            method: 'DELETE',
            headers: { 'Authorization': 'Bearer ' + sessionStorage.getItem("arOSToken") }
        });

        if (response.ok) {
            alert(`Sistem: File ${fileName} berhasil dihapus.`);
            loadFileList(type);
        } else {
            alert('Sistem Menolak: Gagal menghapus file.');
        }
    } catch (error) {
        alert('Kesalahan Sistem: Terjadi masalah koneksi saat mencoba menghapus file.');
    }
}

async function checkServerStatus() {
    try {
        const response = await fetch(`${API_BASE_URL}/status`, {
            headers: { 'Authorization': 'Bearer ' + sessionStorage.getItem("arOSToken") }
        });
        
        if (response.ok) {
            const data = await response.json();
            const isRunning = data.server_status === "running";
            
            const btnStart = document.getElementById("btnStart");
            const btnRestart = document.getElementById("btnRestart");
            const btnStop = document.getElementById("btnStop");
            const logIndicator = document.getElementById("logIndicator");

            if (isRunning) {
                btnStart.innerText = "▶ SERVER BERJALAN";
                btnStart.disabled = true;
                btnStart.style.opacity = "0.5";
                btnStart.style.cursor = "not-allowed";

                btnRestart.disabled = false;
                btnRestart.style.opacity = "1";
                btnRestart.style.cursor = "pointer";

                btnStop.disabled = false;
                btnStop.style.opacity = "1";
                btnStop.style.cursor = "pointer";
                
                if(logIndicator) logIndicator.style.color = "#00ffff";
            } else {
                btnStart.innerText = "▶ MULAI SERVER";
                btnStart.disabled = false;
                btnStart.style.opacity = "1";
                btnStart.style.cursor = "pointer";

                btnRestart.disabled = true;
                btnRestart.style.opacity = "0.5";
                btnRestart.style.cursor = "not-allowed";

                btnStop.disabled = true;
                btnStop.style.opacity = "0.5";
                btnStop.style.cursor = "not-allowed";
                
                if(logIndicator) logIndicator.style.color = "#ff3333";
            }
        }
    } catch (error) {
        console.warn("Gagal mengecek status server", error);
    }
}

let lastLogContent = "";
async function fetchServerLog() {
    try {
        const response = await fetch(`${API_BASE_URL}/log`, {
            headers: { 'Authorization': 'Bearer ' + sessionStorage.getItem("arOSToken") }
        });
        
        if (response.ok) {
            const data = await response.json();
            if (data.log !== lastLogContent) {
                const term = document.getElementById('mcLogTerminal');
                if (term) {
                    term.textContent = data.log;
                    term.scrollTop = term.scrollHeight;
                }
                lastLogContent = data.log;
            }
        }
    } catch (error) {
        console.warn("Gagal mengecek log server", error);
    }
}

async function controlServer(action) {
    let pesanKonfirmasi = "";
    if (action === "start") pesanKonfirmasi = "Apakah Anda ingin MENJALANKAN server Minecraft?";
    if (action === "stop") pesanKonfirmasi = "Apakah Anda yakin ingin MENGHENTIKAN server? Seluruh pemain akan terputus dan data akan disimpan.";
    if (action === "restart") pesanKonfirmasi = "Apakah Anda yakin ingin melakukan RESTART pada Server Minecraft? Semua pemain akan terputus sementara.";

    const konfirmasi = confirm(pesanKonfirmasi + " (Ya/Tidak)");
    if (!konfirmasi) return;

    try {
        const response = await fetch(`${API_BASE_URL}/${action}`, {
            method: 'POST',
            headers: { 'Authorization': 'Bearer ' + sessionStorage.getItem("arOSToken") }
        });

        const result = await response.json();
        if (response.ok) {
            alert(result.message);
            setTimeout(checkServerStatus, 1500); 
        } else {
            alert("Sistem Menolak: Gagal mengeksekusi perintah server.");
        }
    } catch (error) {
        alert("Kesalahan Sistem: Terjadi masalah komunikasi dengan backend.");
    }
}

async function uploadMinecraftFile(type) {
    const inputId = type === 'mod' ? 'modFileInput' : 'datapackFileInput';
    const statusId = type === 'mod' ? 'modUploadStatus' : 'datapackUploadStatus';
    const progressContainerId = type === 'mod' ? 'modProgressContainer' : 'datapackProgressContainer';
    const progressBarId = type === 'mod' ? 'modProgressBar' : 'datapackProgressBar';
    
    const fileInput = document.getElementById(inputId);
    const statusEl = document.getElementById(statusId);
    const progContainer = document.getElementById(progressContainerId);
    const progBar = document.getElementById(progressBarId);

    if (fileInput.files.length === 0) {
        statusEl.style.color = "#ff3333";
        statusEl.textContent = "Sistem menolak: Pilih minimal satu file.";
        return;
    }

    fileInput.disabled = true;
    progContainer.style.display = "block";
    
    for (let i = 0; i < fileInput.files.length; i++) {
        const file = fileInput.files[i];
        statusEl.style.color = "var(--text-muted)";
        statusEl.textContent = `Mentransmisikan file (${i+1}/${fileInput.files.length}): ${file.name}...`;
        progBar.style.width = "0%";

        await new Promise((resolve, reject) => {
            const xhr = new XMLHttpRequest();
            xhr.open('POST', `${API_BASE_URL}/upload`, true);
            
            xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("arOSToken"));
            xhr.setRequestHeader('X-File-Name', encodeURIComponent(file.name));
            xhr.setRequestHeader('X-Target-Type', type);
            xhr.setRequestHeader('Content-Type', 'application/octet-stream');

            xhr.upload.onprogress = function(e) {
                if (e.lengthComputable) {
                    const percentComplete = (e.loaded / e.total) * 100;
                    progBar.style.width = percentComplete + '%';
                }
            };

            xhr.onload = function() {
                if (xhr.status === 200) {
                    resolve();
                } else {
                    reject(`Error ${xhr.status}`);
                }
            };

            xhr.onerror = function() { reject("Koneksi terputus."); };
            xhr.send(file);
        }).catch(err => {
            statusEl.style.color = "#ff3333";
            statusEl.textContent = `[GAGAL] Transmisi dibatalkan: ${err}`;
            fileInput.disabled = false;
            throw new Error("Upload aborted"); 
        });
    }

    statusEl.style.color = "#00ffff";
    statusEl.textContent = `[BERHASIL] ${fileInput.files.length} file telah direplikasi ke server.`;
    
    setTimeout(() => {
        progContainer.style.display = "none";
        progBar.style.width = "0%";
    }, 2000);

    fileInput.value = "";
    fileInput.disabled = false;
    
    loadFileList(type);
}