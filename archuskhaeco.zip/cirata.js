const SECTOR_A_COORDINATES = [-6.8246388889, 107.1393333333];
const SECTOR_B_COORDINATES = [-6.8219, 107.1452];
const SECTORS = {
    A: { name: "Sektor A", coordinates: SECTOR_A_COORDINATES, color: "#ff3333" },
    B: { name: "Sektor B", coordinates: SECTOR_B_COORDINATES, color: "#00ffff" }
};

let selectedSector = "A";
let sensorChart = null;
let miniMap = null;
let miniTileLayer = null;
let miniMarkers = [];
let refreshTimer = null;
let initialTelemetryRetryTimer = null;
let initialTelemetryRetryCount = 0;
let lastValidData = {};

document.addEventListener("DOMContentLoaded", async () => {
    renderSidebar("dashboard");
    document.getElementById("mobileMenuBtn")?.addEventListener("click", toggleMobileMenu);
    document.getElementById("logoutBtn")?.addEventListener("click", logoutAction);
    document.getElementById("openMapPanel")?.addEventListener("click", () => { window.location.href = "lokasi.html"; });
    document.querySelectorAll("[data-sector-button]").forEach((button) => {
        button.addEventListener("click", () => switchSector(button.dataset.sectorButton));
    });

    const session = await requireAuth(["OWNER", "ADMIN", "GUEST"], "archuskha.html");
    if (!session) return;

    initChart();
    initMiniMap();
    await refreshDashboard();
    refreshTimer = setInterval(refreshDashboard, 300000);
});

async function switchSector(sector) {
    if (!SECTORS[sector]) return;
    selectedSector = sector;
    document.querySelectorAll("[data-sector-button]").forEach((button) => {
        button.classList.toggle("active", button.dataset.sectorButton === sector);
    });
    document.getElementById("sectorTitle").textContent = `TELEMETRI KUALITAS AIR - SEKTOR ${sector}`;
    setText("aiInsightText", `Memuat insight Sektor ${sector}...`);
    updateMiniMapFocus();
    await refreshDashboard();
}

async function refreshDashboard() {
    await Promise.allSettled([loadLatestTelemetry(), loadHistoryTelemetry()]);
}

async function loadLatestTelemetry() {
    setApiStatus("Memuat...", "neutral");
    try {
        const payload = await arOSApiFetch(`action=telemetry_latest&sector=${encodeURIComponent(selectedSector)}`);
        const data = payload?.data;
        if (!data || !data.sector) {
            throw Object.assign(new Error("Telemetry response invalid."), {
                status: 0,
                data: { code: "INVALID_TELEMETRY_RESPONSE" }
            });
        }
        initialTelemetryRetryCount = 0;
        lastValidData[selectedSector] = data;
        renderTelemetry(data);
        setApiStatus(data.deviceStatus || "ONLINE", "ok");
        logEvent(`[TELEMETRY] Sektor ${selectedSector} diperbarui ${data.timestampLocal || ""}`);
        void loadAiInsight(selectedSector);
    } catch (error) {
        if (lastValidData[selectedSector]) {
            renderTelemetry(lastValidData[selectedSector]);
            setApiStatus("Koneksi telemetry gagal", "warn");
        } else if (error?.data?.code === "TELEMETRY_UNAVAILABLE") {
            renderTelemetry(null);
            setApiStatus("Memuat telemetry...", "neutral");
            scheduleInitialTelemetryRetry();
        } else {
            renderTelemetry(null);
            setApiStatus("Data belum tersedia", "warn");
        }
        logEvent(`[WARNING] ${error.message || "Telemetry belum tersedia."}`);
    }
}

function scheduleInitialTelemetryRetry() {
    if (initialTelemetryRetryCount >= 5) return;
    initialTelemetryRetryCount += 1;
    clearTimeout(initialTelemetryRetryTimer);
    initialTelemetryRetryTimer = setTimeout(refreshDashboard, 2000);
}

async function loadHistoryTelemetry() {
    try {
        const payload = await arOSApiFetch(`action=telemetry_history&sector=${encodeURIComponent(selectedSector)}&limit=50`);
        renderChart((payload.data || []).slice().reverse());
    } catch {
        renderChart([]);
    }
}

function renderTelemetry(data) {
    setText("valSuhu", data?.suhu == null ? "--" : `${formatNumber(data.suhu)} \u00b0C`);
    setText("valPh", data?.ph == null ? "--" : formatNumber(data.ph));
    setText("valMscm", data?.mscm == null ? "--" : `${formatNumber(data.mscm, 5)} mS/cm`);
    setText("valMgl", data?.mgl == null ? "--" : `${formatNumber(data.mgl)} mg/L`);
    setText("valNtu", `NTU: ${data?.ntu == null ? "--" : formatNumber(data.ntu)}`);
    setText("valMv", `mV: ${data?.mv == null ? "--" : formatNumber(data.mv)}`);
    setText("sourceStatus", sourceDisplay(data?.source));
    setText("lastUpdated", data?.timestampLocal ? `Update: ${data.timestampLocal}` : "Data belum tersedia");
    renderHealthIntelligence(data);
}

async function loadAiInsight(sector) {
    const requestedSector = sector;
    try {
        const payload = await arOSApiFetch(`action=ai_insight&sector=${encodeURIComponent(requestedSector)}`);
        if (requestedSector !== selectedSector) return;
        setText("aiInsightText", payload.data?.message || "Insight belum tersedia.");
        setText("aiInsightSource", payload.data?.source === "GEMINI" ? "AI Interpretation" : "Deterministik");
    } catch (error) {
        if (requestedSector !== selectedSector) return;
        setText("aiInsightSource", "Tidak tersedia");
        setText("aiInsightText", error.message || "Insight belum dapat dimuat.");
    }
}

function renderHealthIntelligence(data) {
    const score = numericOrNull(data?.riverHealthScore);
    const confidence = numericOrNull(data?.scientificConfidence);
    const statuses = data?.parameterStatuses || {};

    updateGauge("riverHealthGauge", score, 100, overallStatus(score), score);
    setText("riverHealthScore", score == null ? "--" : String(Math.round(score)));
    setText("riverHealthLabel", data?.riverHealthLabel || "Menunggu data");

    updateParameterGauge("phGauge", "phGaugeValue", "phGaugeStatus", data?.ph, 14, statuses.ph);
    updateParameterGauge("doGauge", "doGaugeValue", "doGaugeStatus", data?.mgl, 10, statuses.mgl);
    updateParameterGauge("conductivityGauge", "conductivityGaugeValue", "conductivityGaugeStatus", data?.mscm, 3, statuses.mscm, 5);
    updateGauge("waterQualityGauge", score, 100, overallStatus(score), score);
    setText("waterQualityGaugeValue", score == null ? "--" : String(Math.round(score)));
    setText("waterQualityGaugeStatus", data?.riverHealthLabel || "Data belum tersedia");

    const confidenceValue = confidence == null ? 0 : Math.max(0, Math.min(100, confidence));
    setText("scientificConfidenceValue", confidence == null ? "--%" : `${Math.round(confidenceValue)}%`);
    const confidenceBar = document.getElementById("scientificConfidenceBar");
    if (confidenceBar) confidenceBar.style.width = `${confidenceValue}%`;
    const confidenceTrack = confidenceBar?.parentElement;
    confidenceTrack?.setAttribute("aria-valuenow", String(Math.round(confidenceValue)));

    document.querySelectorAll("[data-parameter-status]").forEach((item) => {
        const result = statuses[item.dataset.parameterStatus];
        item.classList.remove("safe", "warning", "critical", "data-only");
        item.classList.add(statusClass(result?.status));
        const label = item.querySelector("strong");
        if (label) label.textContent = result?.label || "Data belum tersedia";
        item.title = result?.message || "";
    });
}

function updateParameterGauge(gaugeId, valueId, statusId, value, max, status, maximumFractionDigits = 2) {
    const numeric = numericOrNull(value);
    updateGauge(gaugeId, numeric, max, status?.status, numeric);
    setText(valueId, numeric == null ? "--" : formatNumber(numeric, maximumFractionDigits));
    setText(statusId, status?.label || "Data belum tersedia");
}

function updateGauge(id, value, max, status, ariaValue) {
    const gauge = document.getElementById(id);
    if (!gauge) return;
    const numeric = numericOrNull(value);
    const percent = numeric == null ? 0 : Math.max(0, Math.min(100, (numeric / max) * 100));
    gauge.style.setProperty("--gauge-value", percent);
    gauge.classList.remove("safe", "warning", "critical", "data-only");
    gauge.classList.add(statusClass(status));
    gauge.setAttribute("aria-valuenow", String(ariaValue == null ? 0 : ariaValue));
}

function overallStatus(score) {
    if (score == null) return "DATA_ONLY";
    if (score >= 85) return "AMAN";
    if (score >= 70) return "CUKUP_BAIK";
    if (score >= 50) return "PERINGATAN";
    return "KRITIS";
}

function statusClass(status) {
    if (status === "AMAN" || status === "CUKUP_BAIK") return "safe";
    if (status === "PERINGATAN") return "warning";
    if (status === "KRITIS") return "critical";
    return "data-only";
}

function numericOrNull(value) {
    if (value == null || value === "") return null;
    const numeric = Number(value);
    return Number.isFinite(numeric) ? numeric : null;
}

function initChart() {
    const ctx = document.getElementById("sensorChart").getContext("2d");
    sensorChart = new Chart(ctx, {
        type: "line",
        data: {
            labels: [],
            datasets: [
                { label: "Suhu (\u00b0C)", data: [], borderColor: "#00ffff", tension: 0.35 },
                { label: "pH Air", data: [], borderColor: "rgba(255,255,255,0.75)", tension: 0.35 }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { labels: { color: "rgba(255,255,255,0.8)" } } },
            scales: {
                x: { ticks: { color: "rgba(255,255,255,0.5)" }, grid: { color: "rgba(255,255,255,0.1)" } },
                y: { ticks: { color: "rgba(255,255,255,0.5)" }, grid: { color: "rgba(255,255,255,0.1)" } }
            }
        }
    });
    applyChartTheme();
}

function renderChart(records) {
    if (!sensorChart) return;
    sensorChart.data.labels = records.map((item) => item.timestampLocal || item.timestampUtc || "");
    sensorChart.data.datasets[0].data = records.map((item) => item.suhu ?? null);
    sensorChart.data.datasets[1].data = records.map((item) => item.ph ?? null);
    sensorChart.update();
}

function initMiniMap() {
    miniMap = L.map("miniMap", {
        zoomControl: false,
        dragging: false,
        scrollWheelZoom: false,
        doubleClickZoom: false,
        touchZoom: false
    });

    miniTileLayer = L.tileLayer(tileUrlForTheme(), {
        attribution: "&copy; OpenStreetMap"
    }).addTo(miniMap);

    Object.entries(SECTORS).forEach(([id, sector]) => {
        const marker = L.circleMarker(sector.coordinates, {
            color: sector.color,
            fillColor: sector.color,
            fillOpacity: 0.8,
            radius: id === selectedSector ? 12 : 8
        }).addTo(miniMap);
        marker.bindPopup(`${sector.name}<br><button type="button" onclick="window.location.href='lokasi-detail.html?sector=${id}'">Lihat Detail</button>`);
        miniMarkers.push({ id, marker });
        L.circle(sector.coordinates, {
            color: "transparent",
            fillColor: sector.color,
            fillOpacity: 0.12,
            radius: 300
        }).addTo(miniMap);
    });

    updateMiniMapFocus();
}

function tileUrlForTheme() {
    const style = document.documentElement.dataset.theme === "light" ? "light_all" : "dark_all";
    return `https://{s}.basemaps.cartocdn.com/${style}/{z}/{x}/{y}{r}.png`;
}

function applyChartTheme() {
    if (!sensorChart) return;
    const light = document.documentElement.dataset.theme === "light";
    const text = light ? "rgba(16,33,60,0.75)" : "rgba(255,255,255,0.8)";
    const muted = light ? "rgba(16,33,60,0.45)" : "rgba(255,255,255,0.5)";
    const grid = light ? "rgba(18,72,130,0.12)" : "rgba(255,255,255,0.1)";
    sensorChart.data.datasets[0].borderColor = light ? "#1677ff" : "#00ffff";
    sensorChart.data.datasets[1].borderColor = text;
    sensorChart.options.plugins.legend.labels.color = text;
    sensorChart.options.scales.x.ticks.color = muted;
    sensorChart.options.scales.y.ticks.color = muted;
    sensorChart.options.scales.x.grid.color = grid;
    sensorChart.options.scales.y.grid.color = grid;
    sensorChart.update("none");
}

function updateMiniMapFocus() {
    if (!miniMap) return;
    miniMap.fitBounds([SECTOR_A_COORDINATES, SECTOR_B_COORDINATES], { padding: [20, 20], maxZoom: 15 });
    miniMarkers.forEach(({ id, marker }) => {
        marker.setStyle({ radius: id === selectedSector ? 12 : 8 });
    });
}

function setApiStatus(text, mode) {
    const el = document.getElementById("apiStatus");
    if (!el) return;
    el.textContent = text;
    el.className = `status-badge ${mode || "neutral"}`;
}

function logEvent(msg) {
    const box = document.getElementById("eventBox");
    if (!box) return;
    const p = document.createElement("p");
    p.textContent = msg;
    p.className = "log-system";
    box.appendChild(p);
    box.scrollTop = box.scrollHeight;
}

function setText(id, text) {
    const el = document.getElementById(id);
    if (el) el.textContent = text;
}

function formatNumber(value, maximumFractionDigits = 2) {
    return Number(value).toLocaleString("id-ID", { maximumFractionDigits });
}

function sourceDisplay(source) {
    if (source === "CIANJUR_EXTERNAL") return "LIVE - CIANJUR EXTERNAL";
    if (source === "SIMULATION_FALLBACK") return "SIMULATION FALLBACK";
    if (source === "SIMULATION") return "SIMULATION";
    return `Sumber: ${source || "-"}`;
}

window.addEventListener("beforeunload", () => {
    if (refreshTimer) clearInterval(refreshTimer);
    if (initialTelemetryRetryTimer) clearTimeout(initialTelemetryRetryTimer);
});

window.addEventListener("aros:themechange", () => {
    applyChartTheme();
    miniTileLayer?.setUrl(tileUrlForTheme());
    requestAnimationFrame(() => {
        sensorChart?.resize();
        miniMap?.invalidateSize(false);
    });
});
