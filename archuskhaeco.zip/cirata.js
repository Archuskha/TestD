const BRIDGE_API_URL = "/api-bridge"; 
const GOOGLE_SHEET_API = "https://script.google.com/macros/s/AKfycbyyJfEoS7vQfR-NzxRHbmKnOQetgvtdW_a5LRmO5BPva6WeM24lQ-4lHvuEvGSD3mIILg/exec";

let telemetryInterval = null;
let sensorChart = null;
let chartUpdateInterval = null;

function logoutAction() {
    sessionStorage.removeItem("arOSToken");
    window.location.href = 'archuskha.html';
}

document.addEventListener("DOMContentLoaded", () => {
    mulaiTelemetri();
    inisialisasiGrafik();
});

function logEvent(msg) {
    const box = document.getElementById('eventBox');
    if(!box) return;
    const p = document.createElement('p'); p.textContent = msg; p.className = 'log-system';
    box.appendChild(p); box.scrollTop = box.scrollHeight;
}

function simulateTelemetry() {
    return `[log] {"suhu": "${(25 + Math.random() * 5).toFixed(1)}", "Ph": "${(7 + Math.random() * 1).toFixed(1)}", "mS/cm": "${(1.2 + Math.random() * 0.3).toFixed(2)}", "NTU": "${(10 + Math.random() * 20).toFixed(0)}", "mg/l": "${(5 + Math.random() * 3).toFixed(1)}", "mV": "${(200 + Math.random() * 100).toFixed(0)}"}`;
}

function mulaiTelemetri() {
    logEvent("[SYSTEM] Sinkronisasi data MQTT Edge Node...");
    telemetryInterval = setInterval(async () => {
        try {
            const res = await fetch(`${BRIDGE_API_URL}/?action=telemetry&token=${sessionStorage.getItem("arOSToken")}`);
            const data = await res.json();
            perbaruiDashboard(data.status === 200 && data.message ? data.message : simulateTelemetry());
        } catch (e) { perbaruiDashboard(simulateTelemetry()); }
    }, 2000);
}

function perbaruiDashboard(logMessage) {
    const extract = (str, pattern) => { const m = str.match(new RegExp(pattern, "i")); return m ? m[1] : "--"; };
    document.getElementById('valSuhu').textContent = extract(logMessage, "\\[suhu\\]\\s*([0-9.]+)");
    document.getElementById('valPh').textContent = extract(logMessage, "\\[Ph\\]\\s*([0-9.]+)");
    document.getElementById('valMscm').textContent = extract(logMessage, "\\[mS/cm\\]\\s*([0-9.]+)");
    document.getElementById('valNtu').textContent = extract(logMessage, "\\[NTU\\]\\s*([0-9.]+)");
    document.getElementById('valMgl').textContent = extract(logMessage, "\\[mg/l\\]\\s*([0-9.]+)");
    document.getElementById('valMv').textContent = extract(logMessage, "\\[mV\\]\\s*([0-9.]+)");
}

function simulateChartData() {
    let data = []; let now = new Date();
    for (let i = 0; i < 10; i++) {
        let time = new Date(now.getTime() - (9 - i) * 1000 * 60);
        data.push({ waktu: time.toISOString(), suhu: (25 + Math.random() * 5).toFixed(1), ph: (7 + Math.random() * 1).toFixed(1) });
    }
    return data;
}

async function inisialisasiGrafik() {
    let dataSet;
    try {
        const response = await fetch(GOOGLE_SHEET_API);
        dataSet = await response.json();
    } catch (error) {
        logEvent("[WARNING] API Google Sheets lambat, beralih ke simulasi lokal.");
        dataSet = simulateChartData();
    }
    
    const dataTerbaru = dataSet.slice(-10);
    const labelWaktu = dataTerbaru.map(d => new Date(d.waktu).toLocaleTimeString());
    const dataSuhu = dataTerbaru.map(d => parseFloat(d.suhu) || 0);
    const dataPh = dataTerbaru.map(d => parseFloat(d.ph) || 0);

    const ctx = document.getElementById('sensorChart').getContext('2d');
    sensorChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labelWaktu,
            datasets: [
                { label: 'Suhu (°C)', data: dataSuhu, borderColor: '#00ffff', tension: 0.4 },
                { label: 'pH Air', data: dataPh, borderColor: 'rgba(255,255,255,0.6)', tension: 0.4 }
            ]
        },
        options: {
            responsive: true, maintainAspectRatio: false,
            plugins: { legend: { labels: { color: 'rgba(255,255,255,0.8)' } } },
            scales: { x: { ticks: { color: 'rgba(255,255,255,0.5)' }, grid: {color: 'rgba(255,255,255,0.1)'} }, y: { ticks: { color: 'rgba(255,255,255,0.5)' }, grid: {color: 'rgba(255,255,255,0.1)'} } }
        }
    });

    chartUpdateInterval = setInterval(() => {
        sensorChart.data.labels.push(new Date().toLocaleTimeString());
        sensorChart.data.datasets[0].data.push(parseFloat((25 + Math.random() * 5).toFixed(1)));
        sensorChart.data.datasets[1].data.push(parseFloat((7 + Math.random() * 1).toFixed(1)));
        if (sensorChart.data.labels.length > 10) {
            sensorChart.data.labels.shift(); sensorChart.data.datasets[0].data.shift(); sensorChart.data.datasets[1].data.shift();
        }
        sensorChart.update('none'); 
    }, 5000);
}