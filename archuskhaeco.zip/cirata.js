const SECTOR_A_COORDINATES = [-6.8246388889, 107.1393333333];
const SECTOR_B_COORDINATES = [-6.8219, 107.1452];
const SECTORS = {
    A: { name: "Sektor A", coordinates: SECTOR_A_COORDINATES, color: "#ff3333" },
    B: { name: "Sektor B", coordinates: SECTOR_B_COORDINATES, color: "#00ffff" }
};

let selectedSector = "A";
let sensorChart = null;
let miniMap = null;
let miniMarkers = [];
let refreshTimer = null;
let lastValidData = {};

document.addEventListener("DOMContentLoaded", async () => {
    renderSidebar("dashboard");
    document.getElementById("mobileMenuBtn")?.addEventListener("click", toggleMobileMenu);
    document.getElementById("logoutBtn")?.addEventListener("click", logoutAction);
    document.getElementById("openMapPanel")?.addEventListener("click", () => { window.location.href = "lokasi.html"; });
    document.querySelectorAll("[data-sector-button]").forEach((button) => {
        button.addEventListener("click", () => switchSector(button.dataset.sectorButton));
    });

    const session = await requireAuth(["OWNER", "ADMIN", "GUEST"], "archuskha.html");
    if (!session) return;

    initChart();
    initMiniMap();
    await refreshDashboard();
    refreshTimer = setInterval(refreshDashboard, 300000);
});

async function switchSector(sector) {
    if (!SECTORS[sector]) return;
    selectedSector = sector;
    document.querySelectorAll("[data-sector-button]").forEach((button) => {
        button.classList.toggle("active", button.dataset.sectorButton === sector);
    });
    document.getElementById("sectorTitle").textContent = `TELEMETRI KUALITAS AIR - SEKTOR ${sector}`;
    updateMiniMapFocus();
    await refreshDashboard();
}

async function refreshDashboard() {
    await Promise.all([loadLatestTelemetry(), loadHistoryTelemetry()]);
}

async function loadLatestTelemetry() {
    setApiStatus("Memuat...", "neutral");
    try {
        const payload = await arOSApiFetch(`action=telemetry_latest&sector=${encodeURIComponent(selectedSector)}`);
        lastValidData[selectedSector] = payload.data;
        renderTelemetry(payload.data);
        setApiStatus(payload.data?.deviceStatus || "ONLINE", "ok");
        logEvent(`[TELEMETRY] Sektor ${selectedSector} diperbarui ${payload.data?.timestampLocal || ""}`);
    } catch (error) {
        if (lastValidData[selectedSector]) {
            renderTelemetry(lastValidData[selectedSector]);
            setApiStatus("Koneksi telemetry gagal", "warn");
        } else {
            renderTelemetry(null);
            setApiStatus("Data belum tersedia", "warn");
        }
        logEvent(`[WARNING] ${error.message || "Telemetry belum tersedia."}`);
    }
}

async function loadHistoryTelemetry() {
    try {
        const payload = await arOSApiFetch(`action=telemetry_history&sector=${encodeURIComponent(selectedSector)}&limit=50`);
        renderChart((payload.data || []).slice().reverse());
    } catch {
        renderChart([]);
    }
}

function renderTelemetry(data) {
    setText("valSuhu", data?.suhu == null ? "--" : `${formatNumber(data.suhu)} \u00b0C`);
    setText("valPh", data?.ph == null ? "--" : formatNumber(data.ph));
    setText("valMscm", data?.mscm == null ? "--" : `${formatNumber(data.mscm)} mS/cm`);
    setText("valMgl", data?.mgl == null ? "--" : `${formatNumber(data.mgl)} mg/L`);
    setText("valNtu", `NTU: ${data?.ntu == null ? "--" : formatNumber(data.ntu)}`);
    setText("valMv", `mV: ${data?.mv == null ? "--" : formatNumber(data.mv)}`);
    setText("sourceStatus", `Sumber: ${data?.source || "-"}`);
    setText("lastUpdated", data?.timestampLocal ? `Update: ${data.timestampLocal}` : "Data belum tersedia");
}

function initChart() {
    const ctx = document.getElementById("sensorChart").getContext("2d");
    sensorChart = new Chart(ctx, {
        type: "line",
        data: {
            labels: [],
            datasets: [
                { label: "Suhu (\u00b0C)", data: [], borderColor: "#00ffff", tension: 0.35 },
                { label: "pH Air", data: [], borderColor: "rgba(255,255,255,0.75)", tension: 0.35 }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { labels: { color: "rgba(255,255,255,0.8)" } } },
            scales: {
                x: { ticks: { color: "rgba(255,255,255,0.5)" }, grid: { color: "rgba(255,255,255,0.1)" } },
                y: { ticks: { color: "rgba(255,255,255,0.5)" }, grid: { color: "rgba(255,255,255,0.1)" } }
            }
        }
    });
}

function renderChart(records) {
    if (!sensorChart) return;
    sensorChart.data.labels = records.map((item) => item.timestampLocal || item.timestampUtc || "");
    sensorChart.data.datasets[0].data = records.map((item) => item.suhu ?? null);
    sensorChart.data.datasets[1].data = records.map((item) => item.ph ?? null);
    sensorChart.update();
}

function initMiniMap() {
    miniMap = L.map("miniMap", {
        zoomControl: false,
        dragging: false,
        scrollWheelZoom: false,
        doubleClickZoom: false,
        touchZoom: false
    });

    L.tileLayer("https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png", {
        attribution: "&copy; OpenStreetMap"
    }).addTo(miniMap);

    Object.entries(SECTORS).forEach(([id, sector]) => {
        const marker = L.circleMarker(sector.coordinates, {
            color: sector.color,
            fillColor: sector.color,
            fillOpacity: 0.8,
            radius: id === selectedSector ? 12 : 8
        }).addTo(miniMap);
        marker.bindPopup(`${sector.name}<br><button type="button" onclick="window.location.href='lokasi-detail.html?sector=${id}'">Lihat Detail</button>`);
        miniMarkers.push({ id, marker });
        L.circle(sector.coordinates, {
            color: "transparent",
            fillColor: sector.color,
            fillOpacity: 0.12,
            radius: 300
        }).addTo(miniMap);
    });

    updateMiniMapFocus();
}

function updateMiniMapFocus() {
    if (!miniMap) return;
    miniMap.fitBounds([SECTOR_A_COORDINATES, SECTOR_B_COORDINATES], { padding: [20, 20], maxZoom: 15 });
    miniMarkers.forEach(({ id, marker }) => {
        marker.setStyle({ radius: id === selectedSector ? 12 : 8 });
    });
}

function setApiStatus(text, mode) {
    const el = document.getElementById("apiStatus");
    if (!el) return;
    el.textContent = text;
    el.className = `status-badge ${mode || "neutral"}`;
}

function logEvent(msg) {
    const box = document.getElementById("eventBox");
    if (!box) return;
    const p = document.createElement("p");
    p.textContent = msg;
    p.className = "log-system";
    box.appendChild(p);
    box.scrollTop = box.scrollHeight;
}

function setText(id, text) {
    const el = document.getElementById(id);
    if (el) el.textContent = text;
}

function formatNumber(value) {
    return Number(value).toLocaleString("id-ID", { maximumFractionDigits: 2 });
}

window.addEventListener("beforeunload", () => {
    if (refreshTimer) clearInterval(refreshTimer);
});
