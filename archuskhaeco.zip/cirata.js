const PROGRAM_API_URL = (() => {
    if (window.location.protocol === "file:" || !window.location.hostname) {
        return "http://localhost:8080";
    }
    return `${window.location.origin}/api-bridge`;
})();

const GOOGLE_SHEET_API = "https://script.google.com/macros/s/AKfycbyyJfEoS7vQfR-NzxRHbmKnOQetgvtdW_a5LRmO5BPva6WeM24lQ-4lHvuEvGSD3mIILg/exec";
const CIRATA_THEME_KEY = "cirataTheme";

let telemetryInterval = null;
let sensorChart = null;
let chartUpdateInterval = null;
let miniMapInstance = null;
let miniMapTileLayer = null;
let miniMapMarker = null;
let miniMapPulse = null;

function logoutAction() {
    sessionStorage.removeItem("arOSToken");
    window.location.href = 'archuskha.html';
}

function toggleMobileMenu() {
    const sidebar = document.querySelector('.sidebar');
    if (sidebar) sidebar.classList.toggle('open');
}

function getCssVar(name) {
    return getComputedStyle(document.body).getPropertyValue(name).trim();
}

function getActiveTheme() {
    return document.body.classList.contains("light-mode") ? "light" : "dark";
}

function applyCirataTheme(theme) {
    const mode = theme === "light" ? "light" : "dark";
    document.body.classList.toggle("light-mode", mode === "light");
    document.body.classList.toggle("dark-mode", mode === "dark");

    const themeToggle = document.getElementById("themeToggle");
    const themeLabel = document.getElementById("themeLabel");
    if (themeToggle) themeToggle.setAttribute("aria-pressed", String(mode === "light"));
    if (themeLabel) themeLabel.textContent = mode === "light" ? "Light Mode" : "Dark Mode";

    updateChartTheme();
    updateMiniMapTheme();
}

function initCirataTheme() {
    const savedTheme = localStorage.getItem(CIRATA_THEME_KEY);
    applyCirataTheme(savedTheme === "light" ? "light" : "dark");

    const themeToggle = document.getElementById("themeToggle");
    if (themeToggle) {
        themeToggle.addEventListener("click", () => {
            const nextTheme = getActiveTheme() === "light" ? "dark" : "light";
            localStorage.setItem(CIRATA_THEME_KEY, nextTheme);
            applyCirataTheme(nextTheme);
        });
    }
}

function getChartTheme() {
    return {
        accent: getCssVar("--accent-strong") || "#00e5ff",
        secondary: getCssVar("--chart-secondary") || "rgba(255,255,255,0.68)",
        muted: getCssVar("--text-muted") || "rgba(255,255,255,0.5)",
        grid: getCssVar("--border-soft") || "rgba(255,255,255,0.1)"
    };
}

function updateChartTheme() {
    if (!sensorChart) return;
    const colors = getChartTheme();
    sensorChart.data.datasets[0].borderColor = colors.accent;
    sensorChart.data.datasets[0].pointBackgroundColor = colors.accent;
    sensorChart.data.datasets[1].borderColor = colors.secondary;
    sensorChart.data.datasets[1].pointBackgroundColor = colors.secondary;
    sensorChart.options.plugins.legend.labels.color = colors.muted;
    sensorChart.options.scales.x.ticks.color = colors.muted;
    sensorChart.options.scales.x.grid.color = colors.grid;
    sensorChart.options.scales.y.ticks.color = colors.muted;
    sensorChart.options.scales.y.grid.color = colors.grid;
    sensorChart.update('none');
}

function getMiniMapTileConfig() {
    if (getActiveTheme() === "light") {
        return {
            url: "https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png",
            attribution: "&copy; OpenStreetMap &copy; CARTO"
        };
    }

    return {
        url: "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png",
        attribution: "&copy; OpenStreetMap &copy; CARTO"
    };
}

function updateMiniMapTheme() {
    if (!miniMapInstance || !miniMapTileLayer) return;

    const tileConfig = getMiniMapTileConfig();
    miniMapTileLayer.setUrl(tileConfig.url);

    const accent = getCssVar("--accent-strong") || "#00e5ff";
    if (miniMapMarker) {
        miniMapMarker.setStyle({
            color: accent,
            fillColor: accent
        });
    }
    if (miniMapPulse) {
        miniMapPulse.setStyle({
            fillColor: accent
        });
    }
}

document.addEventListener("DOMContentLoaded", () => {
    initCirataTheme();
    mulaiTelemetri();
    inisialisasiGrafik();
    inisialisasiPetaMini();
});

function logEvent(msg) {
    const box = document.getElementById('eventBox');
    if(!box) return;
    const p = document.createElement('p');
    p.textContent = msg;
    p.className = 'log-system';
    box.appendChild(p);
    box.scrollTop = box.scrollHeight;
}

function simulateTelemetry() {
    return `[log] {"suhu": "${(25 + Math.random() * 5).toFixed(1)}", "Ph": "${(7 + Math.random() * 1).toFixed(1)}", "mS/cm": "${(1.2 + Math.random() * 0.3).toFixed(2)}", "NTU": "${(10 + Math.random() * 20).toFixed(0)}", "mg/l": "${(5 + Math.random() * 3).toFixed(1)}", "mV": "${(200 + Math.random() * 100).toFixed(0)}"}`;
}

function mulaiTelemetri() {
    logEvent("[SYSTEM] Sinkronisasi data MQTT Edge Node...");
    telemetryInterval = setInterval(async () => {
        try {
            const res = await fetch(`${PROGRAM_API_URL}/?action=telemetry&token=${sessionStorage.getItem("arOSToken")}`);
            const data = await res.json();
            perbaruiDashboard(data.status === 200 && data.message ? data.message : simulateTelemetry());
        } catch (e) {
            perbaruiDashboard(simulateTelemetry());
        }
    }, 2000);
}

function perbaruiDashboard(logMessage) {
    const extract = (str, pattern, jsonKey) => {
        let m = str.match(new RegExp(pattern, "i"));
        if (!m && jsonKey) {
            m = str.match(new RegExp(`"${jsonKey}"\\s*:\\s*"([0-9.]+)"`, "i"));
        }
        return m ? m[1] : "--";
    };

    document.getElementById('valSuhu').textContent = extract(logMessage, "\\[suhu\\]\\s*([0-9.]+)", "suhu");
    document.getElementById('valPh').textContent = extract(logMessage, "\\[Ph\\]\\s*([0-9.]+)", "Ph");
    document.getElementById('valMscm').textContent = extract(logMessage, "\\[mS/cm\\]\\s*([0-9.]+)", "mS/cm");
    document.getElementById('valMgl').textContent = extract(logMessage, "\\[mg/l\\]\\s*([0-9.]+)", "mg/l");
}

function simulateChartData() {
    let data = [];
    let now = new Date();
    for (let i = 0; i < 10; i++) {
        let time = new Date(now.getTime() - (9 - i) * 1000 * 60);
        data.push({ waktu: time.toISOString(), suhu: (25 + Math.random() * 5).toFixed(1), ph: (7 + Math.random() * 1).toFixed(1) });
    }
    return data;
}

async function inisialisasiGrafik() {
    let dataSet;
    try {
        const response = await fetch(GOOGLE_SHEET_API);
        dataSet = await response.json();
    } catch (error) {
        logEvent("[WARNING] API Google Sheets lambat, beralih ke simulasi lokal.");
        dataSet = simulateChartData();
    }

    const dataTerbaru = dataSet.slice(-10);
    const labelWaktu = dataTerbaru.map(d => new Date(d.waktu).toLocaleTimeString());
    const dataSuhu = dataTerbaru.map(d => parseFloat(d.suhu) || 0);
    const dataPh = dataTerbaru.map(d => parseFloat(d.ph) || 0);
    const chartColors = getChartTheme();

    const ctx = document.getElementById('sensorChart').getContext('2d');
    sensorChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labelWaktu,
            datasets: [
                {
                    label: 'Suhu (C)',
                    data: dataSuhu,
                    borderColor: chartColors.accent,
                    pointBackgroundColor: chartColors.accent,
                    pointRadius: 3,
                    tension: 0.4
                },
                {
                    label: 'pH Air',
                    data: dataPh,
                    borderColor: chartColors.secondary,
                    pointBackgroundColor: chartColors.secondary,
                    pointRadius: 3,
                    tension: 0.4
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    labels: { color: chartColors.muted }
                }
            },
            scales: {
                x: {
                    ticks: { color: chartColors.muted },
                    grid: { color: chartColors.grid }
                },
                y: {
                    ticks: { color: chartColors.muted },
                    grid: { color: chartColors.grid }
                }
            }
        }
    });

    chartUpdateInterval = setInterval(() => {
        sensorChart.data.labels.push(new Date().toLocaleTimeString());
        sensorChart.data.datasets[0].data.push(parseFloat((25 + Math.random() * 5).toFixed(1)));
        sensorChart.data.datasets[1].data.push(parseFloat((7 + Math.random() * 1).toFixed(1)));
        if (sensorChart.data.labels.length > 10) {
            sensorChart.data.labels.shift();
            sensorChart.data.datasets[0].data.shift();
            sensorChart.data.datasets[1].data.shift();
        }
        sensorChart.update('none');
    }, 5000);
}

function inisialisasiPetaMini() {
    const cirataCoords = [-6.7021, 107.3518];
    const tileConfig = getMiniMapTileConfig();
    const accent = getCssVar("--accent-strong") || "#00e5ff";

    miniMapInstance = L.map('miniMap', {
        zoomControl: false,
        dragging: false,
        scrollWheelZoom: false,
        doubleClickZoom: false,
        touchZoom: false
    }).setView(cirataCoords, 14);

    miniMapTileLayer = L.tileLayer(tileConfig.url, {
        attribution: tileConfig.attribution
    }).addTo(miniMapInstance);

    miniMapMarker = L.circleMarker(cirataCoords, {
        color: accent,
        fillColor: accent,
        fillOpacity: 0.72,
        radius: 12
    }).addTo(miniMapInstance);

    miniMapPulse = L.circle(cirataCoords, {
        color: 'transparent',
        fillColor: accent,
        fillOpacity: 0.18,
        radius: 300
    }).addTo(miniMapInstance);
}
