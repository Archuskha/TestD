const AROS_THEME_KEY = "arOSTheme";

let fullMapInstance = null;
let fullMapTileLayer = null;
let fullMapMarker = null;
let fullMapPulse = null;

function logoutAction() {
    sessionStorage.removeItem("arOSToken");
    window.location.href = 'archuskha.html';
}

function toggleMobileMenu() {
    const sidebar = document.querySelector('.sidebar');
    if (sidebar) sidebar.classList.toggle('open');
}

function getActiveTheme() {
    return document.body.classList.contains("light-mode") ? "light" : "dark";
}

function getCssVar(name) {
    return getComputedStyle(document.body).getPropertyValue(name).trim();
}

function getMapTileConfig() {
    if (getActiveTheme() === "light") {
        return {
            url: "https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png",
            attribution: "&copy; OpenStreetMap &copy; CARTO"
        };
    }

    return {
        url: "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png",
        attribution: "&copy; OpenStreetMap &copy; CARTO"
    };
}

function updateFullMapTheme() {
    if (!fullMapInstance || !fullMapTileLayer) return;

    const tileConfig = getMapTileConfig();
    const accent = getCssVar("--accent-2") || "#00e5ff";
    fullMapTileLayer.setUrl(tileConfig.url);

    if (fullMapMarker) {
        fullMapMarker.setStyle({
            color: accent,
            fillColor: accent
        });
    }

    if (fullMapPulse) {
        fullMapPulse.setStyle({
            fillColor: accent
        });
    }

    setTimeout(() => fullMapInstance.invalidateSize(), 120);
}

function applyArOSTheme(theme) {
    const mode = theme === "light" ? "light" : "dark";
    document.body.classList.toggle("light-mode", mode === "light");
    document.body.classList.toggle("dark-mode", mode === "dark");

    const label = document.getElementById("themeLabel");
    const toggle = document.getElementById("themeToggle");
    if (label) label.textContent = mode === "light" ? "Light Mode" : "Dark Mode";
    if (toggle) toggle.setAttribute("aria-pressed", String(mode === "light"));

    updateFullMapTheme();
}

function initArOSTheme() {
    const savedTheme = localStorage.getItem(AROS_THEME_KEY) || localStorage.getItem("cianjurTheme") || "dark";
    applyArOSTheme(savedTheme);

    const toggle = document.getElementById("themeToggle");
    if (!toggle) return;
    toggle.addEventListener("click", () => {
        const nextTheme = getActiveTheme() === "light" ? "dark" : "light";
        localStorage.setItem(AROS_THEME_KEY, nextTheme);
        localStorage.setItem("cianjurTheme", nextTheme);
        applyArOSTheme(nextTheme);
    });
}

function enforceProtectedPageAccess() {
    if (!sessionStorage.getItem("arOSToken")) {
        window.location.href = "archuskha.html";
        return false;
    }

    if (sessionStorage.getItem("arOSRole") === "MINECRAFT_ONLY") {
        sessionStorage.setItem("arOSAccessDenied", "Management Cianjur hanya tersedia untuk admin/operator.");
        window.location.href = "archuskha.html";
        return false;
    }

    return true;
}

document.addEventListener("DOMContentLoaded", () => {
    initArOSTheme();
    if (!enforceProtectedPageAccess()) return;

    const cianjurCoords = [-6.7021, 107.3518];
    const tileConfig = getMapTileConfig();
    const accent = getCssVar("--accent-2") || "#00e5ff";

    fullMapInstance = L.map('fullMap').setView(cianjurCoords, 14);

    fullMapTileLayer = L.tileLayer(tileConfig.url, {
        attribution: tileConfig.attribution
    }).addTo(fullMapInstance);

    fullMapMarker = L.circleMarker(cianjurCoords, {
        color: accent,
        fillColor: accent,
        fillOpacity: 1,
        radius: 10
    }).addTo(fullMapInstance);

    fullMapMarker.bindPopup(`
        <div style="text-align:center; font-family:'Varela Round', sans-serif;">
            <strong style="color: #006d99; font-size: 1.1rem;">MODUL SENSOR BRIN</strong><br>
            <span style="color: #666;">Cianjur Sektor A</span><br><br>
            <b>Lat:</b> -6.7021<br>
            <b>Long:</b> 107.3518<br><br>
            <span style="color: #00aa00;">Status: Online (Transmitting)</span>
        </div>
    `);

    fullMapPulse = L.circle(cianjurCoords, {
        color: 'transparent',
        fillColor: accent,
        fillOpacity: 0.14,
        radius: 500
    }).addTo(fullMapInstance);

    setTimeout(() => fullMapInstance.invalidateSize(), 150);
});
