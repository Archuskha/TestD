function logoutAction() {
    sessionStorage.removeItem("arOSToken");
    window.location.href = 'archuskha.html';
}

function toggleMobileMenu() {
    const sidebar = document.querySelector('.sidebar');
    if (sidebar) sidebar.classList.toggle('open');
}

document.addEventListener("DOMContentLoaded", () => {
    // Koordinat Waduk Cirata
    var cirataCoords = [-6.7021, 107.3518];

    // Inisialisasi Peta Penuh (Bisa di-zoom dan digeser)
    var map = L.map('fullMap').setView(cirataCoords, 14);

    // Basemap Tema Gelap
    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
        attribution: '&copy; OpenStreetMap & CartoDB'
    }).addTo(map);

    // Membuat Marker Titik Merah Utama
    var mainMarker = L.circleMarker(cirataCoords, {
        color: '#ff3333',
        fillColor: '#ff3333',
        fillOpacity: 1,
        radius: 10
    }).addTo(map);

    // Memberikan Informasi Popup saat Marker diklik
    mainMarker.bindPopup(`
        <div style="text-align:center; font-family:'Varela Round', sans-serif;">
            <strong style="color: #ff3333; font-size: 1.1rem;">MODUL SENSOR BRIN</strong><br>
            <span style="color: #666;">Cirata Sektor A</span><br><br>
            <b>Lat:</b> -6.7021<br>
            <b>Long:</b> 107.3518<br><br>
            <span style="color: #00aa00;">● Status: Online (Transmitting)</span>
        </div>
    `);

    // Tambahan radar deteksi di sekitar modul
    L.circle(cirataCoords, {
        color: '#ff3333',
        fillColor: '#ff3333',
        fillOpacity: 0.1,
        radius: 500 // Radius 500 meter
    }).addTo(map);
});