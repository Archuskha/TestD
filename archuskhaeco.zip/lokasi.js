const SECTOR_A_COORDINATES = [-6.8246388889, 107.1393333333];
const SECTOR_B_COORDINATES = [-6.8219, 107.1452];
const MAP_SECTORS = {
    A: {
        label: "Sektor A",
        coordinates: SECTOR_A_COORDINATES,
        color: "#ff3333",
        dms: "6\u00b049'28.7\"S 107\u00b008'21.6\"E"
    },
    B: {
        label: "Sektor B",
        coordinates: SECTOR_B_COORDINATES,
        color: "#00ffff",
        dms: "Sekitar Sektor A"
    }
};

document.addEventListener("DOMContentLoaded", async () => {
    renderSidebar("lokasi");
    document.getElementById("mobileMenuBtn")?.addEventListener("click", toggleMobileMenu);
    document.getElementById("backDashboardBtn")?.addEventListener("click", () => { window.location.href = "cirata.html"; });

    const session = await requireAuth(["OWNER", "ADMIN", "GUEST"], "archuskha.html");
    if (!session) return;
    initFullMap();
});

function initFullMap() {
    const map = L.map("fullMap");
    L.tileLayer("https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png", {
        attribution: "&copy; OpenStreetMap & CartoDB"
    }).addTo(map);

    Object.entries(MAP_SECTORS).forEach(([id, sector]) => {
        const marker = L.circleMarker(sector.coordinates, {
            color: sector.color,
            fillColor: sector.color,
            fillOpacity: 1,
            radius: 11
        }).addTo(map);

        const popup = document.createElement("div");
        popup.className = "map-popup";
        const title = document.createElement("strong");
        title.textContent = `Cirata ${sector.label}`;
        const coord = document.createElement("span");
        coord.textContent = `${sector.coordinates[0]}, ${sector.coordinates[1]}`;
        const dms = document.createElement("span");
        dms.textContent = sector.dms;
        const button = document.createElement("button");
        button.type = "button";
        button.className = "popup-detail-btn";
        button.textContent = "Lihat Detail";
        button.addEventListener("click", () => openSectorDetail(id));
        popup.append(title, document.createElement("br"), coord, document.createElement("br"), dms, document.createElement("br"), button);

        marker.bindPopup(popup);
        marker.on("click", () => openSectorDetail(id));
        L.circle(sector.coordinates, {
            color: sector.color,
            fillColor: sector.color,
            fillOpacity: 0.1,
            radius: 500
        }).addTo(map);
    });

    map.fitBounds([SECTOR_A_COORDINATES, SECTOR_B_COORDINATES], { padding: [60, 60], maxZoom: 15 });
}

function openSectorDetail(sector) {
    window.location.href = `lokasi-detail.html?sector=${encodeURIComponent(sector)}`;
}
