const PROGRAM_API_URL = (() => {
    if (window.location.protocol === "file:" || !window.location.hostname) {
        return "http://localhost:8080";
    }
    return `${window.location.origin}/api-bridge`;
})();

const CAMERA_TIMEOUT_MS = 4000;
const DIRECTION_BY_KEY = {
    w: "/maju",
    arrowup: "/maju",
    a: "/kiri",
    arrowleft: "/kiri",
    d: "/kanan",
    arrowright: "/kanan"
};

let telemetryTimer = null;
let cameraWatchdogTimer = null;
let cameraState = "init";
let cameraStreamActive = false;
let lastCameraOnlineAt = 0;

let activeDirection = null;
let pressedDirections = new Map();
let pointerDirection = null;
let commandInFlight = false;
let queuedCommand = null;
let lastCommandSent = null;
let robotControlsReady = false;

let micStream = null;
let micEnabled = true;
let speakerEnabled = true;
let currentAudio = null;
let audioContext = null;
let voiceLogState = "init";
let isAnalyzingCamera = false;

function logoutAction() {
    emergencyStop("logout");
    stopSpeaking();
    releaseMicrophone();
    sessionStorage.removeItem("arOSToken");
    sessionStorage.removeItem("arOSRole");
    window.location.href = 'archuskha.html';
}

function logRobot(msg, type='system') {
    const box = document.getElementById('robotLog');
    if(!box) return;
    const p = document.createElement('p');
    p.textContent = msg;
    p.className = `log-${type}`;
    box.appendChild(p);
    box.scrollTop = box.scrollHeight;
}

function logCameraState(nextState) {
    if (cameraState === nextState) return;

    const previousState = cameraState;
    cameraState = nextState;

    if (nextState === "online" && (previousState === "offline" || previousState === "reconnecting")) {
        logRobot("[KAMERA] Koneksi pulih. Feed FPV kembali online.", "system");
    } else if (nextState === "online") {
        logRobot("[KAMERA] Kamera online.", "system");
    } else if (nextState === "reconnecting") {
        logRobot("[KAMERA] Reconnecting feed kamera...", "system");
    } else if (nextState === "offline") {
        logRobot("[KAMERA] Koneksi kamera terputus.", "error");
    }
}

async function sendRobotCommand(command, options = {}) {
    if (!options.force && command === lastCommandSent && command !== "/berhenti") return;

    if (commandInFlight) {
        queuedCommand = command;
        return;
    }

    commandInFlight = true;
    queuedCommand = null;
    lastCommandSent = command;

    const token = sessionStorage.getItem("arOSToken") || "";
    if (!options.silentTx) {
        logRobot(`[TX] Mengirim instruksi: ${command}`, 'cmd');
    }

    try {
        const url = `${PROGRAM_API_URL}/?action=command&command=${encodeURIComponent(command)}&token=${encodeURIComponent(token)}`;
        const response = await fetch(url, { cache: "no-store" });
        const data = await response.json();

        if (data.status === 200) {
            if (!options.silentRx) {
                logRobot(`[RX] Berhasil: ${data.message}`, 'system');
            }
            await syncRobotTelemetry();
        } else {
            logRobot(`[ERROR] Gagal mengirim: ${data.message}`, 'error');
        }
    } catch (error) {
        logRobot(`[NETWORK ERROR] Gagal terhubung ke Program.cs backend.`, 'error');
    } finally {
        commandInFlight = false;
        if (queuedCommand && queuedCommand !== command) {
            const nextCommand = queuedCommand;
            queuedCommand = null;
            sendRobotCommand(nextCommand, { force: true });
        }
    }
}

function beginDirection(command) {
    if (!command || activeDirection === command) return;
    activeDirection = command;
    sendRobotCommand(command);
}

function stopMovement(options = {}) {
    if (!activeDirection && lastCommandSent === "/berhenti" && !options.force) return;
    activeDirection = null;
    sendRobotCommand("/berhenti", { force: true, silentRx: options.silentRx === true });
}

function emergencyStop(reason) {
    pressedDirections.clear();
    pointerDirection = null;
    stopMovement({ force: true, silentRx: reason !== "manual" });
}

function getLatestPressedDirection() {
    let latestCommand = null;
    let latestTime = -1;

    pressedDirections.forEach((value, key) => {
        if (value.time > latestTime) {
            latestTime = value.time;
            latestCommand = value.command;
        }
    });

    return latestCommand;
}

function handleDirectionKeyDown(event) {
    const key = event.key.toLowerCase();
    const command = DIRECTION_BY_KEY[key];
    if (!command) return false;

    event.preventDefault();
    if (event.repeat) return true;

    pressedDirections.set(key, { command, time: Date.now() });
    beginDirection(command);
    return true;
}

function handleDirectionKeyUp(event) {
    const key = event.key.toLowerCase();
    const command = DIRECTION_BY_KEY[key];
    if (!command) return false;

    event.preventDefault();
    pressedDirections.delete(key);

    if (activeDirection === command) {
        const nextCommand = getLatestPressedDirection();
        if (nextCommand) {
            beginDirection(nextCommand);
        } else {
            stopMovement();
        }
    }

    return true;
}

document.addEventListener('keydown', (event) => {
    if (!robotControlsReady) return;
    if (event.target.tagName === 'INPUT' || event.target.tagName === 'TEXTAREA') return;

    if (handleDirectionKeyDown(event)) return;

    if (event.key === ' ') {
        event.preventDefault();
        emergencyStop("manual");
    }
});

document.addEventListener('keyup', (event) => {
    if (!robotControlsReady) return;
    if (event.target.tagName === 'INPUT' || event.target.tagName === 'TEXTAREA') return;
    handleDirectionKeyUp(event);
});

window.addEventListener('blur', () => emergencyStop("blur"));
document.addEventListener('visibilitychange', () => {
    if (document.hidden) emergencyStop("hidden");
});

function toggleMobileMenu() {
    const sidebar = document.querySelector('.sidebar');
    if (sidebar) {
        sidebar.classList.toggle('open');
    }
}

document.addEventListener("DOMContentLoaded", () => {
    initializeRobotPage();
});

async function initializeRobotPage() {
    const permissionOk = await runRobotPermissionGate();
    if (!permissionOk) return;

    robotControlsReady = true;
    setupVoiceControls();
    setupDpadControls();
    startCameraStream();
    syncRobotTelemetry();
    telemetryTimer = setInterval(syncRobotTelemetry, 2000);
    cameraWatchdogTimer = setInterval(checkCameraTimeout, 1000);
}

function redirectHomeAfterPermissionFailure(message) {
    const status = document.getElementById("robotPermissionStatus");
    if (status) {
        status.textContent = message;
        status.style.color = "#ff5555";
    }

    setTimeout(() => {
        window.location.href = "archuskha.html";
    }, 1200);
}

async function runRobotPermissionGate() {
    const gate = document.getElementById("robotPermissionGate");
    const button = document.getElementById("robotPermissionBtn");
    const status = document.getElementById("robotPermissionStatus");

    if (!gate || !button || !status) {
        alert("Konfigurasi permission Robot Portal tidak lengkap. Kembali ke home.");
        window.location.href = "archuskha.html";
        return false;
    }

    gate.style.display = "flex";

    return new Promise((resolve) => {
        let permissionStarted = false;

        button.addEventListener("click", async () => {
            if (permissionStarted) return;
            permissionStarted = true;
            button.disabled = true;

            if (status) {
                status.textContent = "Meminta izin microphone dan menyiapkan audio...";
                status.style.color = "#9bcaca";
            }

            try {
                if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
                    redirectHomeAfterPermissionFailure("Browser tidak mendukung akses microphone. Kembali ke home.");
                    resolve(false);
                    return;
                }

                micStream = await navigator.mediaDevices.getUserMedia({ audio: true });
                micStream.getAudioTracks().forEach((track) => {
                    track.enabled = micEnabled;
                });

                const AudioContextCtor = window.AudioContext || window.webkitAudioContext;
                if (AudioContextCtor) {
                    audioContext = audioContext || new AudioContextCtor();
                    if (audioContext.state === "suspended") {
                        await audioContext.resume();
                    }
                }

                gate.style.display = "none";
                resolve(true);
            } catch (error) {
                redirectHomeAfterPermissionFailure("Izin microphone/audio ditolak. Kembali ke home.");
                resolve(false);
            }
        }, { once: true });
    });
}

function setupVoiceControls() {
    const micButton = document.getElementById("micToggleBtn");
    const speakerButton = document.getElementById("speakerToggleBtn");
    const stopButton = document.getElementById("stopAudioBtn");
    const analyzeButton = document.getElementById("analyzeCameraBtn");

    micButton?.addEventListener("click", () => setMicEnabled(!micEnabled));
    speakerButton?.addEventListener("click", () => setSpeakerEnabled(!speakerEnabled));
    stopButton?.addEventListener("click", stopSpeaking);
    analyzeButton?.addEventListener("click", analyzeCameraSnapshot);

    setMicEnabled(micEnabled, { silent: true });
    setSpeakerEnabled(speakerEnabled, { silent: true });
    updateAiStatus("AI voice siap.");
}

function setMicEnabled(enabled, options = {}) {
    micEnabled = enabled;
    if (micStream) {
        micStream.getAudioTracks().forEach((track) => {
            track.enabled = enabled;
        });
    }

    const button = document.getElementById("micToggleBtn");
    if (button) {
        button.textContent = enabled ? "Mic: ON" : "Mic: MUTE";
        button.classList.toggle("active", enabled);
    }

    if (!options.silent) {
        logVoiceState(enabled ? "mic-on" : "mic-muted", enabled ? "[VOICE] Microphone aktif." : "[VOICE] Microphone mute.");
    }
}

function setSpeakerEnabled(enabled, options = {}) {
    speakerEnabled = enabled;
    const button = document.getElementById("speakerToggleBtn");
    if (button) {
        button.textContent = enabled ? "Speaker: ON" : "Speaker: MUTE";
        button.classList.toggle("active", enabled);
    }

    if (!enabled) {
        stopSpeaking();
    }

    if (!options.silent) {
        logVoiceState(enabled ? "speaker-on" : "speaker-muted", enabled ? "[VOICE] Speaker aktif." : "[VOICE] Speaker mute.");
    }
}

function releaseMicrophone() {
    if (!micStream) return;
    micStream.getTracks().forEach((track) => track.stop());
    micStream = null;
}

function updateAiStatus(message) {
    const status = document.getElementById("aiStatusText");
    if (status) status.textContent = message;
}

function setAiAnswer(message) {
    const answerBox = document.getElementById("aiAnswerBox");
    if (answerBox) answerBox.textContent = message;
}

function logVoiceState(nextState, message) {
    if (voiceLogState === nextState) return;
    voiceLogState = nextState;
    logRobot(message, "system");
}

function getActiveSessionToken(contextLabel) {
    const token = sessionStorage.getItem("arOSToken") || "";
    logRobot(`[AI AUTH] Token sesi ${token ? "tersedia" : "kosong"} untuk ${contextLabel}.`, token ? "system" : "error");
    return token;
}

function handleInvalidAiSession(message = "Sesi backend tidak valid. Silakan login ulang.") {
    sessionStorage.removeItem("arOSToken");
    sessionStorage.removeItem("arOSRole");
    setAiAnswer(message);
    updateAiStatus(message);
    logRobot(`[AI AUTH] ${message}`, "error");

    setTimeout(() => {
        window.location.href = "archuskha.html";
    }, 900);
}

function stopSpeaking() {
    if (currentAudio) {
        currentAudio.pause();
        currentAudio.currentTime = 0;
        currentAudio = null;
    }

    if ("speechSynthesis" in window) {
        window.speechSynthesis.cancel();
    }
}

async function speakAiText(text) {
    if (!speakerEnabled || !text) return;

    stopSpeaking();
    updateAiStatus("Menyiapkan audio AI...");

    try {
        const token = getActiveSessionToken("Gemini TTS");
        if (!token) {
            handleInvalidAiSession("Token sesi kosong. Silakan login ulang.");
            return;
        }

        const response = await fetch(`${PROGRAM_API_URL}/?action=ai_tts&token=${encodeURIComponent(token)}`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            cache: "no-store",
            body: JSON.stringify({ text })
        });
        const data = await response.json();

        if (response.status === 401) {
            handleInvalidAiSession(data.message || "Sesi AI tidak valid. Silakan login ulang.");
            return;
        }

        if (response.ok && data.status === 200 && data.audioBase64) {
            currentAudio = new Audio(`data:${data.mimeType || "audio/wav"};base64,${data.audioBase64}`);
            currentAudio.onended = () => {
                currentAudio = null;
                updateAiStatus("AI voice siap.");
            };
            await currentAudio.play();
            updateAiStatus("Memutar audio Gemini TTS.");
            logVoiceState("tts-backend", "[VOICE] Audio Gemini TTS diputar.");
            return;
        }

        if (data.fallbackAllowed !== false) {
            speakWithBrowserTts(text);
            return;
        }

        updateAiStatus(data.message || "Gemini TTS tidak tersedia.");
    } catch (error) {
        speakWithBrowserTts(text);
    }
}

function speakWithBrowserTts(text) {
    if (!speakerEnabled || !("speechSynthesis" in window)) {
        updateAiStatus("Speaker nonaktif atau browser TTS tidak tersedia.");
        return;
    }

    stopSpeaking();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = "id-ID";
    utterance.onend = () => updateAiStatus("AI voice siap.");
    window.speechSynthesis.speak(utterance);
    updateAiStatus("Memutar fallback browser TTS.");
    logVoiceState("tts-browser", "[VOICE] Fallback browser TTS diputar.");
}

async function analyzeCameraSnapshot() {
    if (isAnalyzingCamera) return;
    isAnalyzingCamera = true;

    const button = document.getElementById("analyzeCameraBtn");
    if (button) button.disabled = true;

    updateAiStatus("Menganalisis snapshot kamera...");
    setAiAnswer("Meminta analisis visual dari backend.");
    logVoiceState("vision-analyzing", "[AI] Analisis kamera dimulai.");

    try {
        const imageBase64 = captureCameraSnapshotBase64();
        if (!imageBase64) {
            const message = "Snapshot kamera belum tersedia. Pastikan feed FPV sedang online.";
            setAiAnswer(message);
            updateAiStatus(message);
            logVoiceState("vision-no-snapshot", `[AI] ${message}`);
            return;
        }

        const token = getActiveSessionToken("Gemini Robotics");
        if (!token) {
            handleInvalidAiSession("Token sesi kosong. Silakan login ulang.");
            return;
        }

        const response = await fetch(`${PROGRAM_API_URL}/?action=robotics_analyze&token=${encodeURIComponent(token)}`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            cache: "no-store",
            body: JSON.stringify({
                imageBase64,
                prompt: "Analisis snapshot kamera robot darat. Jelaskan objek terlihat, posisi relatif, potensi rintangan, dan ringkasan situasi secara singkat."
            })
        });
        const data = await response.json();

        if (response.status === 401) {
            handleInvalidAiSession(data.message || "Sesi AI tidak valid. Silakan login ulang.");
            return;
        }

        if (response.ok && data.status === 200) {
            const answer = data.message || "Analisis selesai tanpa teks.";
            setAiAnswer(answer);
            updateAiStatus("Analisis kamera selesai.");
            logVoiceState("vision-complete", "[AI] Analisis kamera selesai.");
            await speakAiText(answer);
        } else {
            const message = data.message || "Analisis kamera gagal.";
            setAiAnswer(message);
            updateAiStatus(message);
            logVoiceState("vision-error", `[AI] ${message}`);
        }
    } catch (error) {
        const message = "Gagal terhubung ke endpoint analisis kamera.";
        setAiAnswer(message);
        updateAiStatus(message);
        logVoiceState("vision-network-error", `[AI] ${message}`);
    } finally {
        isAnalyzingCamera = false;
        if (button) button.disabled = false;
    }
}

function captureCameraSnapshotBase64() {
    const videoImg = document.getElementById("liveVideoFeed");
    if (!videoImg || cameraState !== "online" || videoImg.style.opacity === "0") {
        return "";
    }

    const sourceWidth = videoImg.naturalWidth || videoImg.clientWidth;
    const sourceHeight = videoImg.naturalHeight || videoImg.clientHeight;
    if (!sourceWidth || !sourceHeight) {
        return "";
    }

    try {
        const maxWidth = 960;
        const scale = Math.min(1, maxWidth / sourceWidth);
        const canvas = document.createElement("canvas");
        canvas.width = Math.max(1, Math.round(sourceWidth * scale));
        canvas.height = Math.max(1, Math.round(sourceHeight * scale));

        const ctx = canvas.getContext("2d");
        if (!ctx) return "";

        ctx.drawImage(videoImg, 0, 0, canvas.width, canvas.height);
        return canvas.toDataURL("image/jpeg", 0.82);
    } catch (error) {
        return "";
    }
}

function setupDpadControls() {
    document.querySelectorAll('.dpad-btn[data-command]').forEach((button) => {
        const command = button.dataset.command;

        button.addEventListener('click', (event) => {
            event.preventDefault();
        });

        button.addEventListener('pointerdown', (event) => {
            event.preventDefault();
            button.setPointerCapture?.(event.pointerId);

            if (command === "/berhenti") {
                emergencyStop("manual");
                return;
            }

            if (pointerDirection === command) return;
            pointerDirection = command;
            beginDirection(command);
        });

        const finishPointer = (event) => {
            event.preventDefault();
            if (command === "/berhenti") return;
            if (pointerDirection === command) {
                pointerDirection = null;
                stopMovement();
            }
        };

        button.addEventListener('pointerup', finishPointer);
        button.addEventListener('pointercancel', finishPointer);
        button.addEventListener('pointerleave', finishPointer);
    });
}

function startCameraStream() {
    const videoImg = document.getElementById('liveVideoFeed');
    const overlayText = document.getElementById('camOverlay');
    if (!videoImg || !overlayText) return;

    videoImg.onload = () => {
        lastCameraOnlineAt = Date.now();
        showCameraOnline();
    };

    videoImg.onerror = () => {
        setCameraOffline("Koneksi kamera terputus");
    };

    restartCameraStream();
    logCameraState("reconnecting");
}

function restartCameraStream() {
    const videoImg = document.getElementById('liveVideoFeed');
    if (!videoImg) return;

    cameraStreamActive = true;
    videoImg.crossOrigin = "anonymous";
    videoImg.src = `${PROGRAM_API_URL}/?action=video&t=${Date.now()}`;
}

function clearCameraFrame(message = "Koneksi kamera terputus") {
    const videoImg = document.getElementById('liveVideoFeed');
    const overlayText = document.getElementById('camOverlay');
    if (!videoImg || !overlayText) return;

    cameraStreamActive = false;
    videoImg.removeAttribute('src');
    videoImg.style.opacity = "0";
    overlayText.style.display = "block";
    overlayText.textContent = `[ ${message.toUpperCase()} ]`;
    overlayText.style.color = "#ff3333";
}

function showCameraOnline() {
    const videoImg = document.getElementById('liveVideoFeed');
    const overlayText = document.getElementById('camOverlay');
    if (!videoImg || !overlayText) return;

    videoImg.style.opacity = "1";
    overlayText.style.display = "none";
    logCameraState("online");
}

function setCameraOffline(message = "Koneksi kamera terputus") {
    clearCameraFrame(message);
    logCameraState("offline");
}

function checkCameraTimeout() {
    if (!lastCameraOnlineAt) return;

    const elapsed = Date.now() - lastCameraOnlineAt;
    if (elapsed > CAMERA_TIMEOUT_MS && cameraState === "online") {
        setCameraOffline("Koneksi kamera terputus");
    }
}

function updateCameraFromTelemetry(data) {
    if (data.cameraConnected) {
        lastCameraOnlineAt = Date.now();
        if (!cameraStreamActive) {
            restartCameraStream();
        }
        showCameraOnline();
        return;
    }

    if (cameraState !== "offline") {
        setCameraOffline("Koneksi kamera terputus");
    }
}

async function syncRobotTelemetry() {
    const startedAt = performance.now();

    try {
        const token = sessionStorage.getItem("arOSToken") || "";
        const response = await fetch(`${PROGRAM_API_URL}/?action=telemetry&token=${encodeURIComponent(token)}&t=${Date.now()}`, { cache: "no-store" });
        const data = await response.json();
        const latency = Math.max(1, Math.round(performance.now() - startedAt));

        if (data.status === 200) {
            updateRobotTelemetry(data, latency);
            updateCameraFromTelemetry(data);
        }
    } catch (error) {
        updateRobotConnectionState(false);
        setCameraOffline("Backend offline");
    }
}

function updateRobotTelemetry(data, latency) {
    const batteryText = document.getElementById('robotBat');
    const pingText = document.getElementById('robotPing');
    const panel = document.getElementById('jarakPanel');
    const distanceText = document.getElementById('robotJarak');

    if (batteryText) {
        batteryText.textContent = `${data.battery ?? 100}%`;
    }

    if (pingText) {
        pingText.textContent = `${latency} ms`;
    }

    if (panel && distanceText) {
        if (data.obstacleDetected) {
            panel.classList.add('alert');
            distanceText.textContent = data.distanceText || "Bahaya";
        } else {
            panel.classList.remove('alert');
            distanceText.textContent = data.distanceText || "Aman";
        }
    }
}

function updateRobotConnectionState(isConnected) {
    const pingText = document.getElementById('robotPing');
    const panel = document.getElementById('jarakPanel');
    const distanceText = document.getElementById('robotJarak');

    if (pingText) {
        pingText.textContent = isConnected ? pingText.textContent : "-- ms";
    }

    if (!isConnected && panel && distanceText) {
        panel.classList.add('alert');
        distanceText.textContent = "Backend offline";
    }
}
