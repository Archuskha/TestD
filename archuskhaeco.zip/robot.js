const PROGRAM_API_URL = (() => {
    if (window.location.protocol === "file:" || !window.location.hostname) {
        return "http://localhost:8080";
    }
    return `${window.location.origin}/api-bridge`;
})();

let telemetryTimer = null;

function logoutAction() {
    sessionStorage.removeItem("arOSToken");
    sessionStorage.removeItem("arOSRole");
    window.location.href = 'archuskha.html';
}

function logRobot(msg, type='system') {
    const box = document.getElementById('robotLog');
    if(!box) return;
    const p = document.createElement('p');
    p.textContent = msg;
    p.className = `log-${type}`;
    box.appendChild(p);
    box.scrollTop = box.scrollHeight;
}

async function sendRobotCommand(command) {
    const token = sessionStorage.getItem("arOSToken") || "";
    logRobot(`[TX] Mengirim instruksi: ${command}`, 'cmd');

    try {
        const url = `${PROGRAM_API_URL}/?action=command&command=${encodeURIComponent(command)}&token=${encodeURIComponent(token)}`;
        const response = await fetch(url, { cache: "no-store" });
        const data = await response.json();

        if (data.status === 200) {
            logRobot(`[RX] Berhasil: ${data.message}`, 'system');
            await syncRobotTelemetry();
        } else {
            logRobot(`[ERROR] Gagal mengirim: ${data.message}`, 'error');
        }
    } catch (error) {
        logRobot(`[NETWORK ERROR] Gagal terhubung ke Program.cs backend.`, 'error');
    }
}

document.addEventListener('keydown', (event) => {
    if (event.repeat) return;

    if (event.target.tagName === 'INPUT' || event.target.tagName === 'TEXTAREA') return;

    switch(event.key.toLowerCase()) {
        case 'w': case 'arrowup':
            sendRobotCommand('/maju');
            break;
        case 's': case 'arrowdown':
            sendRobotCommand('/mundur');
            break;
        case 'a': case 'arrowleft':
            sendRobotCommand('/kiri');
            break;
        case 'd': case 'arrowright':
            sendRobotCommand('/kanan');
            break;
        case ' ':
            event.preventDefault();
            sendRobotCommand('/berhenti');
            break;
    }
});

function toggleMobileMenu() {
    const sidebar = document.querySelector('.sidebar');
    if (sidebar) {
        sidebar.classList.toggle('open');
    }
}

document.addEventListener("DOMContentLoaded", () => {
    startCameraStream();
    syncRobotTelemetry();
    telemetryTimer = setInterval(syncRobotTelemetry, 2000);
});

function startCameraStream() {
    const videoImg = document.getElementById('liveVideoFeed');
    const overlayText = document.getElementById('camOverlay');
    if (!videoImg || !overlayText) return;

    const streamUrl = `${PROGRAM_API_URL}/?action=video&t=${Date.now()}`;
    videoImg.src = streamUrl;

    videoImg.onload = () => {
        videoImg.style.opacity = "1";
        overlayText.style.display = "none";
        logRobot("[KAMERA] Feed visual FPV berhasil ditautkan dan stabil.", "system");
    };

    videoImg.onerror = () => {
        videoImg.style.opacity = "0";
        overlayText.style.display = "block";
        overlayText.textContent = "[ KONEKSI KAMERA TERPUTUS ]";
        overlayText.style.color = "#ff3333";
    };
}

async function syncRobotTelemetry() {
    const startedAt = performance.now();

    try {
        const token = sessionStorage.getItem("arOSToken") || "";
        const response = await fetch(`${PROGRAM_API_URL}/?action=telemetry&token=${encodeURIComponent(token)}&t=${Date.now()}`, { cache: "no-store" });
        const data = await response.json();
        const latency = Math.max(1, Math.round(performance.now() - startedAt));

        if (data.status === 200) {
            updateRobotTelemetry(data, latency);
        }
    } catch (error) {
        updateRobotConnectionState(false);
    }
}

function updateRobotTelemetry(data, latency) {
    const batteryText = document.getElementById('robotBat');
    const pingText = document.getElementById('robotPing');
    const panel = document.getElementById('jarakPanel');
    const distanceText = document.getElementById('robotJarak');

    if (batteryText) {
        batteryText.textContent = `${data.battery ?? 100}%`;
    }

    if (pingText) {
        pingText.textContent = `${latency} ms`;
    }

    if (panel && distanceText) {
        if (data.obstacleDetected) {
            panel.classList.add('alert');
            distanceText.textContent = data.distanceText || "Rintangan terdeteksi";
        } else {
            panel.classList.remove('alert');
            distanceText.textContent = data.distanceText || "Aman";
        }
    }
}

function updateRobotConnectionState(isConnected) {
    const pingText = document.getElementById('robotPing');
    const panel = document.getElementById('jarakPanel');
    const distanceText = document.getElementById('robotJarak');

    if (pingText) {
        pingText.textContent = isConnected ? pingText.textContent : "-- ms";
    }

    if (!isConnected && panel && distanceText) {
        panel.classList.add('alert');
        distanceText.textContent = "Backend offline";
    }
}
