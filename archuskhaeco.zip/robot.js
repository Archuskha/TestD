const BRIDGE_API_URL = "http://103.150.117.90:8080"; 

function logoutAction() {
    sessionStorage.removeItem("arOSToken");
    sessionStorage.removeItem("arOSRole");
    window.location.href = 'archuskha.html';
}

function logRobot(msg, type='system') {
    const box = document.getElementById('robotLog');
    if(!box) return;
    const p = document.createElement('p'); 
    p.textContent = msg; 
    p.className = `log-${type}`;
    box.appendChild(p); 
    box.scrollTop = box.scrollHeight;
}

// Fungsi utama untuk mengirim instruksi D-PAD ke VPS C# Backend
async function sendRobotCommand(command) {
    const token = sessionStorage.getItem("arOSToken");
    logRobot(`[TX] Mengirim instruksi: ${command}`, 'cmd');

    try {
        const response = await fetch(`${BRIDGE_API_URL}/?prompt=${encodeURIComponent(command)}&token=${encodeURIComponent(token)}`);
        const data = await response.json();
        
        if (data.status === 200) {
            logRobot(`[RX] Berhasil: ${data.message}`, 'system');
        } else {
            logRobot(`[ERROR] Gagal mengirim: ${data.message}`, 'error');
        }
    } catch (error) {
        logRobot(`[NETWORK ERROR] Gagal terhubung ke Bridge VPS.`, 'error');
    }
}

// Fitur deteksi keyboard (W, A, S, D, Spasi)
document.addEventListener('keydown', (event) => {
    // Cegah spam eksekusi jika tombol ditahan terus menerus
    if (event.repeat) return; 

    // Mencegah eksekusi jika pengguna sedang mengetik di input box lain
    if (event.target.tagName === 'INPUT' || event.target.tagName === 'TEXTAREA') return;

    switch(event.key.toLowerCase()) {
        case 'w': case 'arrowup': 
            sendRobotCommand('/maju'); 
            break;
        case 's': case 'arrowdown': 
            sendRobotCommand('/mundur'); 
            break;
        case 'a': case 'arrowleft': 
            sendRobotCommand('/kiri'); 
            break;
        case 'd': case 'arrowright': 
            sendRobotCommand('/kanan'); 
            break;
        case ' ': // Spasi untuk pengereman darurat
            event.preventDefault(); // Mencegah halaman web tergeser (scroll) ke bawah
            sendRobotCommand('/berhenti'); 
            break;
    }
});

function toggleMobileMenu() {
    const sidebar = document.querySelector('.sidebar');
    if (sidebar) {
        sidebar.classList.toggle('open');
    }
}

// Memulai Live Streaming Kamera dari VPS Bridge
document.addEventListener("DOMContentLoaded", () => {
    const videoImg = document.getElementById('liveVideoFeed');
    const overlayText = document.getElementById('camOverlay');

    // Menembak alamat IP VPS Bridge pada endpoint MJPEG Action=video
    // Penggunaan Date.now() ditambahkan agar browser tidak menggunakan cache gambar lama
    const streamUrl = `${BRIDGE_API_URL}/?action=video&t=${Date.now()}`;
    
    videoImg.src = streamUrl;

    // Jika gambar sukses diterima dan mulai diputar
    videoImg.onload = () => {
        videoImg.style.opacity = "1";
        overlayText.style.display = "none";
        logRobot("[KAMERA] Feed visual FPV berhasil ditautkan dan stabil.", "system");
    };

    // Jika gagal terhubung ke VPS
    videoImg.onerror = () => {
        videoImg.style.opacity = "0";
        overlayText.style.display = "block";
        overlayText.textContent = "[ KONEKSI KAMERA TERPUTUS ]";
        overlayText.style.color = "#ff3333";
    };
});

// Simulasi Telemetri Peringatan Rintangan Jarak
setInterval(() => {
    const panel = document.getElementById('jarakPanel');
    const text = document.getElementById('robotJarak');
    
    // Angka acak ini merupakan simulasi untuk tampilan UI. 
    // Dalam produksi nyata, data diambil dari variabel 'latestTelemetry' di VPS.
    const mockDistance = Math.floor(Math.random() * 150) + 5; 
    
    if (mockDistance < 20) {
        panel.classList.add('alert');
        text.textContent = `${mockDistance} cm (AWAS!)`;
    } else {
        panel.classList.remove('alert');
        text.textContent = `Aman (> ${mockDistance} cm)`;
    }
}, 3000);