document.addEventListener('DOMContentLoaded', function() {
    // Variabel Antarmuka
    const rulesBox = document.getElementById('rulesBox');
    const mainFormBox = document.getElementById('mainFormBox');
    const summaryBox = document.getElementById('summaryBox');
    const btnMengerti = document.getElementById('btnMengerti');
    const btnSelesai = document.getElementById('btnSelesai');
    const peminjamanForm = document.getElementById('peminjamanForm');
    const formDetails = document.getElementById('formDetails');
    
    // Variabel Elemen Form
    const jenisPeminjaman = document.getElementById('jenisPeminjaman');
    
    const grupTujuan = document.getElementById('grupTujuan');
    const labelTujuan = document.getElementById('labelTujuan');
    const inputTujuan = document.getElementById('tujuan');
    
    const grupAlat = document.getElementById('grupAlat');
    const labelAlat = document.getElementById('labelAlat');
    const inputAlat = document.getElementById('inputAlat');

    const waktuManualGroup = document.getElementById('waktuManualGroup');
    const inputTanggal = document.getElementById('tanggal');
    const inputJamMulai = document.getElementById('jamMulai');
    const inputJamSelesai = document.getElementById('jamSelesai');

    // URL Google Apps Script Anda (Tetap sama)
    const scriptURL = 'https://script.google.com/macros/s/AKfycbwLYzjBQ8VwEIcG_LKNDRRhfgfMUsLLNDKCreEHqjetd85nr1fq0nXZWjTp4-3QQbSV/exec';

    btnMengerti.addEventListener('click', function() {
        rulesBox.style.display = 'none';      
        mainFormBox.style.display = 'block';  
    });

    jenisPeminjaman.addEventListener('change', function() {
        formDetails.style.display = 'block';

        // 1. Reset Tampilan Bawaan ke Kondisi Awal Terlebih Dahulu
        grupTujuan.style.display = 'block';
        inputTujuan.required = true;
        inputTujuan.value = '';
        document.getElementById('sumTujuanContainer').style.display = 'block';

        grupAlat.style.display = 'none';
        inputAlat.required = false;
        inputAlat.value = '';
        document.getElementById('sumAlatContainer').style.display = 'none';

        waktuManualGroup.style.display = 'block';
        inputTanggal.required = true;
        inputJamMulai.required = true;
        inputJamSelesai.required = true;

        // 2. Logika Berdasarkan Pilihan (Switch Control)
        if (this.value === 'lab') {
            labelTujuan.textContent = 'Tujuan untuk meminjam lab:';
        } 
        else if (this.value === 'lemari') {
            labelTujuan.textContent = 'Tujuan untuk meminjam kunci lemari:';
            grupAlat.style.display = 'block';
            labelAlat.textContent = 'Alat-alat yang digunakan:';
            inputAlat.required = true;
        } 
        else if (this.value === 'pinjamAlat') {
            labelTujuan.textContent = 'Tujuan meminjam alat lab:';
            grupAlat.style.display = 'block';
            labelAlat.textContent = 'Sebutkan nama alat yang dipinjam:';
            inputAlat.required = true;

            waktuManualGroup.style.display = 'none';
            inputTanggal.required = false;
            inputJamMulai.required = false;
            inputJamSelesai.required = false;
            inputTanggal.value = ''; inputJamMulai.value = ''; inputJamSelesai.value = '';
        } 
        else if (this.value === 'kembaliAlat') {
            // Sembunyikan dan setel nilai "Tujuan" menjadi "-" ke Google Sheets
            grupTujuan.style.display = 'none';
            inputTujuan.required = false;
            inputTujuan.value = '-';

            grupAlat.style.display = 'block';
            labelAlat.textContent = 'Sebutkan nama alat dan kondisinya saat dikembalikan:';
            inputAlat.required = true;

            waktuManualGroup.style.display = 'none';
            inputTanggal.required = false;
            inputJamMulai.required = false;
            inputJamSelesai.required = false;
            inputTanggal.value = ''; inputJamMulai.value = ''; inputJamSelesai.value = '';
        }
    });

    peminjamanForm.addEventListener('submit', function(e) {
        e.preventDefault(); 

        const submitButton = peminjamanForm.querySelector('button[type="submit"]');
        submitButton.textContent = 'Mengirim Data...';
        submitButton.disabled = true;

        const formData = new FormData(peminjamanForm);

        // Validasi Cloudflare
        const turnstileResp = formData.get('cf-turnstile-response');
        if (!turnstileResp) {
            alert('Silakan selesaikan verifikasi keamanan (CAPTCHA) terlebih dahulu.');
            submitButton.textContent = 'Kirim Pengajuan';
            submitButton.disabled = false;
            return; 
        }

        const valJenis = jenisPeminjaman.options[jenisPeminjaman.selectedIndex].text;
        const valNama = document.getElementById('nama').value;
        const valNpm = document.getElementById('npm').value;
        const valEmail = document.getElementById('email').value;
        const valAngkatan = document.getElementById('angkatan').value;
        const valTujuan = inputTujuan.value;
        const valAlat = inputAlat.value;
        const valTanggal = inputTanggal.value;
        const valJamMulai = inputJamMulai.value;
        const valJamSelesai = inputJamSelesai.value;

        const now = new Date();
        const optionsDate = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        const formatTanggal = now.toLocaleDateString('id-ID', optionsDate);
        const formatJam = now.toLocaleTimeString('id-ID');

        fetch(scriptURL, { method: 'POST', body: formData })
            .then(response => response.text()) // Tambahan: Membaca teks respons dari Google Script
            .then(result => {
                // Mengecek apakah respons dari server adalah "Success"
                if (result === "Success") {
                    document.getElementById('sumJenis').textContent = valJenis;
                    document.getElementById('sumNama').textContent = valNama;
                    document.getElementById('sumNpm').textContent = valNpm;
                    document.getElementById('sumEmail').textContent = valEmail;
                    document.getElementById('sumAngkatan').textContent = valAngkatan;
                    document.getElementById('sumTujuan').textContent = valTujuan;

                    if (valAlat !== '') {
                        document.getElementById('sumAlatContainer').style.display = 'block';
                        document.getElementById('sumAlat').textContent = valAlat;
                    }
                    
                    if (valTanggal === '') {
                        document.getElementById('sumTanggal').textContent = formatTanggal;
                        document.getElementById('sumWaktu').textContent = formatJam;
                    } else {
                        document.getElementById('sumTanggal').textContent = valTanggal;
                        document.getElementById('sumWaktu').textContent = valJamMulai + ' - ' + valJamSelesai;
                    }
                    
                    document.getElementById('waktuSubmitText').textContent = 'Dikirim pada: ' + formatTanggal + ' pukul ' + formatJam;

                    mainFormBox.style.display = 'none';
                    summaryBox.style.display = 'block';
                    
                    turnstile.reset();
                    peminjamanForm.reset();
                    formDetails.style.display = 'none';
                    
                    submitButton.textContent = 'Kirim Pengajuan';
                    submitButton.disabled = false;
				} else {
                    // Memunculkan pesan pop-up jika server menolak data
                    alert('Gagal menyimpan data ke Spreadsheet: ' + result);
                    submitButton.textContent = 'Kirim Pengajuan';
                    submitButton.disabled = false;
                    
                    // TAMBAHAN: Reset CAPTCHA agar mendapat token baru setelah gagal
                    if (typeof turnstile !== 'undefined') turnstile.reset();
                }
            })
            .catch(error => {
                console.error('Error!', error.message);
                alert('Terjadi kesalahan koneksi saat mengirim data.');
                submitButton.textContent = 'Kirim Pengajuan';
                submitButton.disabled = false;
                
                // TAMBAHAN: Reset CAPTCHA jika koneksi internet terputus
                if (typeof turnstile !== 'undefined') turnstile.reset();
            });
    });

    btnSelesai.addEventListener('click', function() {
        summaryBox.style.display = 'none';
        mainFormBox.style.display = 'block';
    });
});