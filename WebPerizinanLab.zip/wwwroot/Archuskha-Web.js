document.addEventListener('DOMContentLoaded', function() {
    // Variabel Kotak Antarmuka
    const rulesBox = document.getElementById('rulesBox');
    const mainFormBox = document.getElementById('mainFormBox');
    const summaryBox = document.getElementById('summaryBox');
    
    // Variabel Tombol
    const btnMengerti = document.getElementById('btnMengerti');
    const btnSelesai = document.getElementById('btnSelesai');

    // Variabel Formulir
    const jenisPeminjaman = document.getElementById('jenisPeminjaman');
    const formDetails = document.getElementById('formDetails');
    const labelTujuan = document.getElementById('labelTujuan');
    const peminjamanForm = document.getElementById('peminjamanForm');
    
    // Elemen grup waktu
    const waktuManualGroup = document.getElementById('waktuManualGroup');
    const inputTanggal = document.getElementById('tanggal');
    const inputJamMulai = document.getElementById('jamMulai');
    const inputJamSelesai = document.getElementById('jamSelesai');

    // GANTI DENGAN URL DEPLOYMENT BARU ANDA
    const scriptURL = 'https://script.google.com/macros/s/AKfycbxt5dWcR_bp6zyXeY_kK_XXXFja3BvjXfPlm6ny80R-Kvd3btof8hjPbsM5kss22ESL/exec';

    // Aksi untuk tombol "Saya Mengerti"
    btnMengerti.addEventListener('click', function() {
        rulesBox.style.display = 'none';      // Sembunyikan aturan
        mainFormBox.style.display = 'block';  // Tampilkan form utama
    });

    jenisPeminjaman.addEventListener('change', function() {
        formDetails.style.display = 'block';

        if (this.value === 'lab' || this.value === 'lemari') {
            waktuManualGroup.style.display = 'block';
            inputTanggal.required = true;
            inputJamMulai.required = true;
            inputJamSelesai.required = true;

            if (this.value === 'lab') {
                labelTujuan.textContent = 'Tujuan untuk meminjam lab:';
            } else {
                labelTujuan.textContent = 'Tujuan untuk meminjam kunci lemari:';
            }
        } else if (this.value === 'pinjamAlat' || this.value === 'kembaliAlat') {
            waktuManualGroup.style.display = 'none';
            inputTanggal.required = false;
            inputJamMulai.required = false;
            inputJamSelesai.required = false;
            
            inputTanggal.value = '';
            inputJamMulai.value = '';
            inputJamSelesai.value = '';

            if (this.value === 'pinjamAlat') {
                labelTujuan.textContent = 'Tujuan meminjam alat lab (sebutkan nama alat):';
            } else {
                labelTujuan.textContent = 'Kondisi alat saat dikembalikan (sebutkan nama alat):';
            }
        }
    });

    peminjamanForm.addEventListener('submit', function(e) {
        e.preventDefault(); 

        const submitButton = peminjamanForm.querySelector('button[type="submit"]');
        submitButton.textContent = 'Mengirim Data...';
        submitButton.disabled = true;

        const valJenis = jenisPeminjaman.options[jenisPeminjaman.selectedIndex].text;
        const valNama = document.getElementById('nama').value;
        const valNpm = document.getElementById('npm').value;
        const valEmail = document.getElementById('email').value;
        const valAngkatan = document.getElementById('angkatan').value;
        const valTujuan = document.getElementById('tujuan').value;
        const valTanggal = inputTanggal.value;
        const valJamMulai = inputJamMulai.value;
        const valJamSelesai = inputJamSelesai.value;

        const now = new Date();
        const optionsDate = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        const formatTanggal = now.toLocaleDateString('id-ID', optionsDate);
        const formatJam = now.toLocaleTimeString('id-ID');

        const formData = new FormData(peminjamanForm);

        fetch(scriptURL, { method: 'POST', body: formData })
            .then(response => {
                document.getElementById('sumJenis').textContent = valJenis;
                document.getElementById('sumNama').textContent = valNama;
                document.getElementById('sumNpm').textContent = valNpm;
                document.getElementById('sumEmail').textContent = valEmail;
                document.getElementById('sumAngkatan').textContent = valAngkatan;
                document.getElementById('sumTujuan').textContent = valTujuan;
                
                if (valTanggal === '') {
                    document.getElementById('sumTanggal').textContent = formatTanggal;
                    document.getElementById('sumWaktu').textContent = formatJam;
                } else {
                    document.getElementById('sumTanggal').textContent = valTanggal;
                    document.getElementById('sumWaktu').textContent = valJamMulai + ' - ' + valJamSelesai;
                }
                
                document.getElementById('waktuSubmitText').textContent = 'Dikirim pada: ' + formatTanggal + ' pukul ' + formatJam;

                mainFormBox.style.display = 'none';
                summaryBox.style.display = 'block';
                
                peminjamanForm.reset();
                formDetails.style.display = 'none';
                
                submitButton.textContent = 'Kirim Pengajuan';
                submitButton.disabled = false;
            })
            .catch(error => {
                console.error('Error!', error.message);
                alert('Terjadi kesalahan saat mengirim data.');
                
                submitButton.textContent = 'Kirim Pengajuan';
                submitButton.disabled = false;
            });
    });

    // Kembali ke form utama agar pengguna dapat mengisi kembali jika dibutuhkan
    btnSelesai.addEventListener('click', function() {
        summaryBox.style.display = 'none';
        mainFormBox.style.display = 'block';
    });
});